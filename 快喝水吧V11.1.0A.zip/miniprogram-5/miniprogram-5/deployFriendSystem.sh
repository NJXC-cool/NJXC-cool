#!/bin/bash

# 部署好友系统云函数
echo "🚀 开始部署好友系统云函数..."

# 进入云函数目录
cd cloudfunctions/friendSystem

# 安装依赖
echo "📦 安装依赖..."
npm install

# 部署云函数
echo "☁️ 部署云函数..."
wx cloud functions deploy friendSystem --env $(wx cloud env list | grep -o '[a-zA-Z0-9-]*' | head -1)

echo "✅ 好友系统云函数部署完成！"
echo "💡 提示：现在可以使用邀请码功能了"
echo "🧪 测试邀请码：TEST1234" 