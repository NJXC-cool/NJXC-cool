// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const announcements = db.collection('announcements')

// 云函数入口函数
exports.main = async (event, context) => {
  const { action, data } = event
  
  try {
    switch (action) {
      case 'getAll':
        // 获取所有公告
        const result = await announcements
          .orderBy('createTime', 'desc')
          .get()
        return {
          success: true,
          data: result.data
        }
        
      case 'add':
        // 添加新公告
        const { title, content, password } = data
        
        // 验证密码
        if (password !== '556600') {
          return {
            success: false,
            error: '密码错误'
          }
        }
        
        // 获取发布者的openid
        const { openid } = cloud.getWXContext()
        
        const newAnnouncement = {
          title,
          content,
          createTime: new Date(),
          isRead: false,
          publisherOpenid: openid, // 记录发布者的openid
          readCount: 0 // 记录阅读次数
        }
        
        const addResult = await announcements.add({
          data: newAnnouncement
        })
        
                 return {
           success: true,
           data: addResult
         }
         
       case 'delete':
         // 删除公告
         const { id: deleteId, password: deletePassword } = data
         
         // 验证密码
         if (deletePassword !== '556600') {
           return {
             success: false,
             error: '密码错误'
           }
         }
         
         // 删除公告
         await announcements.doc(deleteId).remove()
         
         return {
           success: true
         }
        
      case 'markAsRead':
        // 标记公告为已读
        const { id } = data
        
        // 先获取公告信息
        const announcementDoc = await announcements.doc(id).get()
        if (!announcementDoc.data) {
          return {
            success: false,
            error: '公告不存在'
          }
        }
        
        const announcement = announcementDoc.data
        
        // 标记为已读并更新阅读次数
        await announcements.doc(id).update({
          data: {
            isRead: true,
            readCount: (announcement.readCount || 0) + 1
          }
        })
        
                 // 给发布者发送提醒
         try {
           console.log('准备发送订阅消息给发布者:', announcement.publisherOpenid);
           
           // 发送订阅消息给发布者（使用服务状态提醒模板）
           const subscribeResult = await cloud.openapi.subscribeMessage.send({
             touser: announcement.publisherOpenid,
             templateId: '-G_pTPVTHRIVYw424X5ER4qX90g0ESYPyyvMV0fzHL8',
             page: 'pages/announcement/announcement',
             data: {
               thing1: { value: announcement.title }, // 服务名称（公告标题）
               phrase3: { value: '已被用户阅读' }, // 当前状态
               time9: { value: new Date().toLocaleString() } // 服务时间
             }
           })
           console.log('已读提醒发送成功:', subscribeResult);
         } catch (error) {
           console.error('发送提醒失败:', error);
           console.error('错误详情:', error.message || error);
           // 即使发送提醒失败，也不影响标记已读的功能
         }
        
        return {
          success: true
        }
        
      case 'getUnread':
        // 获取未读公告
        const unreadResult = await announcements
          .where({
            isRead: false
          })
          .orderBy('createTime', 'desc')
          .get()
        
        return {
          success: true,
          data: unreadResult.data
        }
        
      default:
        return {
          success: false,
          error: '未知操作'
        }
    }
  } catch (error) {
    console.error('公告操作失败:', error)
    return {
      success: false,
      error: error.message
    }
  }
} 