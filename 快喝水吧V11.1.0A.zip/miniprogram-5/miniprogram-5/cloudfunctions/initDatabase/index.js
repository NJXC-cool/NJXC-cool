// 数据库初始化云函数
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

exports.main = async (event, context) => {
  const { action } = event;
  
  try {
    switch (action) {
      case 'initCollections':
        return await initCollections();
      case 'checkCollections':
        return await checkCollections();
      default:
        return {
          success: false,
          error: '未知操作'
        };
    }
  } catch (error) {
    console.error('数据库初始化错误:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// 初始化所有必要的集合
async function initCollections() {
  const collections = [
    'announcements',    // 公告集合
    'userProfiles',     // 用户资料集合
    'friends',          // 好友关系集合
    'badges',           // 徽章集合
    'waterRecords',     // 饮水记录集合
    'achievements',     // 成就集合
    'reminderSettings'  // 提醒设置集合
  ];
  
  const results = [];
  
  for (const collectionName of collections) {
    try {
      // 尝试创建集合（如果不存在）
      await db.createCollection(collectionName);
      results.push({
        collection: collectionName,
        status: 'created',
        success: true
      });
    } catch (error) {
      // 如果集合已存在，会抛出错误，这是正常的
      if (error.message.includes('collection already exists')) {
        results.push({
          collection: collectionName,
          status: 'exists',
          success: true
        });
      } else {
        results.push({
          collection: collectionName,
          status: 'error',
          success: false,
          error: error.message
        });
      }
    }
  }
  
  return {
    success: true,
    results
  };
}

// 检查集合是否存在
async function checkCollections() {
  const collections = [
    'announcements',
    'userProfiles', 
    'friends',
    'badges',
    'waterRecords',
    'achievements',
    'reminderSettings'
  ];
  
  const results = [];
  
  for (const collectionName of collections) {
    try {
      // 尝试获取集合信息
      const collection = db.collection(collectionName);
      const count = await collection.count();
      
      results.push({
        collection: collectionName,
        exists: true,
        count: count.total
      });
    } catch (error) {
      results.push({
        collection: collectionName,
        exists: false,
        error: error.message
      });
    }
  }
  
  return {
    success: true,
    results
  };
} 