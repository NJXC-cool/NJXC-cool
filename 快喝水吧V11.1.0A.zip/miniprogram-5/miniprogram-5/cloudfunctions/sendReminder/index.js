// 云函数入口文件
const cloud = require('wx-server-sdk')

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
  traceUser: true // 记录用户访问记录
})

const db = cloud.database()

// 订阅消息模板ID
const TEMPLATE_ID = 'gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const wxContext = cloud.getWXContext()
    const openid = wxContext.OPENID
    
    console.log('云函数上下文:', wxContext)
    console.log('获取到的openid:', openid)
    
    const { time, enabled, reminderInterval, startTime, endTime, remindTitle, remindContent, action, message, userInfo } = event

  // 处理测试模式
  if (action === 'test') {
    try {
      // 发送测试订阅消息
      const result = await cloud.openapi.subscribeMessage.send({
        touser: openid,
        templateId: TEMPLATE_ID,
        page: 'pages/index/index',
        data: {
          thing1: { value: '开发者模式测试' }, // 提醒标题
          thing2: { value: message || '这是一条测试通知' }, // 提醒内容
          time3: { value: new Date().toLocaleString() }, // 提醒时间
          thing4: { value: '测试成功' } // 状态
        }
      })
      
      return { 
        code: 0, 
        msg: '测试通知发送成功', 
        result: result,
        testInfo: {
          openid: openid,
          message: message,
          timestamp: new Date().toISOString()
        }
      }
    } catch (error) {
      return { 
        code: 3, 
        msg: '测试通知发送失败', 
        error: error.message,
        testInfo: {
          openid: openid,
          message: message,
          timestamp: new Date().toISOString()
        }
      }
    }
  }

  // 处理用户信息保存
  if (action === 'saveUserInfo') {
    try {
      const userInfo = event.userInfo;
      
      // 保存用户信息到数据库
      const res = await db.collection('userProfiles').where({ openid }).get();
      if (res.data.length > 0) {
        // 更新记录
        await db.collection('userProfiles').where({ openid }).update({
          data: { 
            ...userInfo,
            updatedAt: new Date()
          }
        });
      } else {
        // 新建记录
        await db.collection('userProfiles').add({
          data: { 
            openid,
            ...userInfo,
            createdAt: new Date(),
            updatedAt: new Date()
          }
        });
      }
      
      return { 
        code: 0, 
        msg: '用户信息保存成功',
        userInfo: userInfo
      }
    } catch (error) {
      return { 
        code: 4, 
        msg: '用户信息保存失败', 
        error: error.message
      }
    }
  }

  if (!openid) {
    return { code: 1, msg: '未获取到openid' }
  }

  try {
    const res = await db.collection('reminderSettings').where({ openid }).get()
    if (res.data.length > 0) {
      // 更新记录
      await db.collection('reminderSettings').where({ openid }).update({
        data: { 
          time, 
          enabled,
          reminderInterval: reminderInterval || 60,
          startTime: startTime || '08:00',
          endTime: endTime || '22:00',
          remindTitle: remindTitle || '喝水提醒',
          remindContent: remindContent || '该喝水啦，保持健康！',
          cloudReminderEnabled: enabled,
          updatedAt: new Date()
        }
      })
    } else {
      // 新建记录
      await db.collection('reminderSettings').add({
        data: { 
          openid, 
          time, 
          enabled,
          reminderInterval: reminderInterval || 60,
          startTime: startTime || '08:00',
          endTime: endTime || '22:00',
          remindTitle: remindTitle || '喝水提醒',
          remindContent: remindContent || '该喝水啦，保持健康！',
          cloudReminderEnabled: enabled,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      })
    }
    return { code: 0, msg: '设置成功' }
  } catch (e) {
    return { code: 2, msg: '数据库操作失败', error: e }
  }
  } catch (error) {
    console.error('云函数执行错误:', error)
    return { 
      code: 4, 
      msg: '云函数执行失败', 
      error: error.message,
      context: {
        openid: openid,
        hasOpenid: !!openid,
        wxContext: wxContext
      }
    }
  }
} 