// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

// 订阅消息模板ID
const TEMPLATE_ID = 'gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'

// 云函数入口函数
exports.main = async (event, context) => {
  const { openid } = event.userInfo || cloud.getWXContext()
  const { message, testType } = event

  if (!openid) {
    return { 
      code: 1, 
      msg: '未获取到openid',
      error: 'openid is required'
    }
  }

  try {
    // 测试数据库连接
    const dbTest = await db.collection('reminderSettings').limit(1).get()
    
    // 发送测试订阅消息
    const messageResult = await cloud.openapi.subscribeMessage.send({
      touser: openid,
      templateId: TEMPLATE_ID,
      page: 'pages/index/index',
      data: {
        thing1: { value: '开发者模式测试' }, // 提醒标题
        thing2: { value: message || '这是一条测试通知' }, // 提醒内容
        time3: { value: new Date().toLocaleString() }, // 提醒时间
        thing4: { value: '测试成功' } // 状态
      }
    })

    // 记录测试日志
    await db.collection('testLogs').add({
      data: {
        openid: openid,
        testType: testType || 'developer_test',
        message: message,
        result: messageResult,
        timestamp: new Date(),
        success: true
      }
    })

    return { 
      code: 0, 
      msg: '云通知测试成功', 
      data: {
        openid: openid,
        message: message,
        testType: testType,
        timestamp: new Date().toISOString(),
        messageResult: messageResult,
        dbTest: dbTest.data.length
      }
    }
  } catch (error) {
    // 记录错误日志
    try {
      await db.collection('testLogs').add({
        data: {
          openid: openid,
          testType: testType || 'developer_test',
          message: message,
          error: error.message,
          timestamp: new Date(),
          success: false
        }
      })
    } catch (logError) {
      console.error('记录错误日志失败:', logError)
    }

    return { 
      code: 2, 
      msg: '云通知测试失败', 
      error: error.message,
      data: {
        openid: openid,
        message: message,
        testType: testType,
        timestamp: new Date().toISOString(),
        errorDetails: {
          name: error.name,
          message: error.message,
          stack: error.stack
        }
      }
    }
  }
} 