// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { audioUrl, filePath, action = 'SentenceRecognition' } = event
    
    // 支持两种参数名：audioUrl 和 filePath
    const audioFileUrl = audioUrl || filePath
    
    if (!audioFileUrl) {
      return {
        success: false,
        error: '缺少音频文件URL'
      }
    }
    
    // 简化版本：直接返回模拟的语音识别结果
    // 在实际部署时，您需要配置正确的腾讯云API调用
    console.log('收到语音识别请求:', { audioFileUrl, action })
    
    // 模拟语音识别结果
    const mockResults = [
      '你好水宝',
      '我想喝水',
      '今天天气怎么样',
      '谢谢水宝',
      '再见'
    ]
    
    const randomResult = mockResults[Math.floor(Math.random() * mockResults.length)]
    
    // 返回水宝助手期望的格式
    return {
      success: true,
      text: randomResult,
      data: {
        Response: {
          RequestId: 'mock-request-id-' + Date.now(),
          Result: randomResult,
          Status: 'SUCCESS'
        }
      }
    }
    
  } catch (error) {
    console.error('语音识别失败:', error)
    return {
      success: false,
      error: error.message || '语音识别服务暂时不可用'
    }
  }
} 