// 数据同步云函数
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

exports.main = async (event, context) => {
  const { action, userOpenid, data } = event;
  
  try {
    switch (action) {
      case 'syncWaterRecords':
        return await syncWaterRecords(userOpenid, data);
      case 'syncUserData':
        return await syncUserData(userOpenid, data);
      case 'syncBadges':
        return await syncBadges(userOpenid, data);
      case 'syncAllData':
        return await syncAllData(userOpenid, data);
      case 'getUserData':
        return await getUserData(userOpenid);
      case 'getUserDataByOpenid':
        return await getUserDataByOpenid(userOpenid);
      case 'getWaterRecords':
        return await getWaterRecords(userOpenid);
      case 'getUserBadges':
        return await getUserBadges(userOpenid);
      default:
        return { success: false, message: '未知操作' };
    }
  } catch (error) {
    console.error('数据同步云函数错误:', error);
    return { success: false, message: error.message };
  }
};

// 同步喝水记录
async function syncWaterRecords(userOpenid, waterRecords) {
  try {
    // 检查用户是否存在
    const userResult = await db.collection('userProfiles')
      .where({ openid: userOpenid })
      .get();
    
    if (userResult.data.length === 0) {
      // 创建用户档案
      await db.collection('userProfiles').add({
        data: {
          openid: userOpenid,
          createTime: new Date(),
          updateTime: new Date()
        }
      });
    }

    // 保存喝水记录
    const recordsData = {
      userOpenid: userOpenid,
      waterRecords: waterRecords,
      lastSyncTime: new Date(),
      recordCount: Object.keys(waterRecords).length
    };

    // 检查是否已有记录
    const existingResult = await db.collection('waterRecords')
      .where({ userOpenid: userOpenid })
      .get();

    if (existingResult.data.length > 0) {
      // 更新现有记录
      await db.collection('waterRecords')
        .doc(existingResult.data[0]._id)
        .update({
          data: recordsData
        });
    } else {
      // 创建新记录
      await db.collection('waterRecords').add({
        data: recordsData
      });
    }

    return { success: true, message: '喝水记录同步成功' };
  } catch (error) {
    console.error('同步喝水记录失败:', error);
    return { success: false, message: error.message };
  }
}

// 同步用户数据
async function syncUserData(userOpenid, userData) {
  try {
    const result = await db.collection('userProfiles')
      .where({ openid: userOpenid })
      .get();
    
    const syncData = {
      ...userData,
      lastSyncTime: new Date(),
      updateTime: new Date()
    };
    
    if (result.data.length === 0) {
      // 创建新用户档案
      await db.collection('userProfiles').add({
        data: {
          openid: userOpenid,
          ...syncData,
          createTime: new Date()
        }
      });
    } else {
      // 更新现有用户档案
      await db.collection('userProfiles')
        .doc(result.data[0]._id)
        .update({
          data: syncData
        });
    }
    
    return { success: true, message: '用户数据同步成功' };
  } catch (error) {
    console.error('同步用户数据失败:', error);
    return { success: false, message: error.message };
  }
}

// 同步徽章数据
async function syncBadges(userOpenid, badges) {
  try {
    // 先删除用户现有徽章
    await db.collection('userBadges')
      .where({ userOpenid: userOpenid })
      .remove();

    // 批量添加新徽章
    if (badges && badges.length > 0) {
      const badgeData = badges.map(badge => ({
        userOpenid: userOpenid,
        badgeId: badge.id || badge.badgeId,
        badgeData: badge,
        unlockTime: new Date(badge.unlockTime || Date.now()),
        createTime: new Date()
      }));

      await db.collection('userBadges').add({
        data: badgeData
      });
    }

    return { success: true, message: '徽章数据同步成功' };
  } catch (error) {
    console.error('同步徽章数据失败:', error);
    return { success: false, message: error.message };
  }
}

// 同步所有数据
async function syncAllData(userOpenid, allData) {
  try {
    const results = await Promise.all([
      syncWaterRecords(userOpenid, allData.waterRecords || {}),
      syncUserData(userOpenid, allData.userData || {}),
      syncBadges(userOpenid, allData.badges || [])
    ]);

    const successCount = results.filter(r => r.success).length;
    
    return {
      success: successCount === results.length,
      message: `同步完成，${successCount}/${results.length} 项成功`,
      details: results
    };
  } catch (error) {
    console.error('同步所有数据失败:', error);
    return { success: false, message: error.message };
  }
}

// 获取用户数据
async function getUserData(userOpenid) {
  try {
    const result = await db.collection('userProfiles')
      .where({ openid: userOpenid })
      .get();
    
    return {
      success: true,
      data: result.data[0] || null
    };
  } catch (error) {
    console.error('获取用户数据失败:', error);
    return { success: false, message: error.message };
  }
}

// 获取用户所有数据
async function getUserDataByOpenid(userOpenid) {
  try {
    const userProfile = await getUserData(userOpenid);
    const waterRecords = await getWaterRecords(userOpenid);
    const userBadges = await getUserBadges(userOpenid);

    return {
      success: true,
      data: {
        userProfile: userProfile.data,
        waterRecords: waterRecords.data,
        userBadges: userBadges.data
      }
    };
  } catch (error) {
    console.error('获取用户所有数据失败:', error);
    return { success: false, message: error.message };
  }
}

// 获取喝水记录
async function getWaterRecords(userOpenid) {
  try {
    const result = await db.collection('waterRecords')
      .where({ userOpenid: userOpenid })
      .get();
    
    return {
      success: true,
      data: result.data[0] ? result.data[0].waterRecords : {}
    };
  } catch (error) {
    console.error('获取喝水记录失败:', error);
    return { success: false, message: error.message };
  }
}

// 获取用户徽章
async function getUserBadges(userOpenid) {
  try {
    const result = await db.collection('userBadges')
      .where({ userOpenid: userOpenid })
      .orderBy('unlockTime', 'desc')
      .get();
    
    return {
      success: true,
      data: result.data.map(item => item.badgeData)
    };
  } catch (error) {
    console.error('获取用户徽章失败:', error);
    return { success: false, message: error.message };
  }
} 