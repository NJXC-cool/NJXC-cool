const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const { content, nickname, avatarUrl } = event
  if (!content) {
    return { code: 1, msg: '内容不能为空' }
  }
  const data = {
    content,
    createdAt: new Date(),
    openid: wxContext.OPENID,
    nickname: nickname || '',
    avatarUrl: avatarUrl || ''
  }
  await db.collection('wishes').add({ data })
  return { code: 0, msg: '发布成功' }
}