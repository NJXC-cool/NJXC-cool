#!/bin/bash

echo "开始部署徽章系统云函数..."

# 进入徽章系统云函数目录
cd cloudfunctions/badgeSystem

# 安装依赖
echo "安装依赖..."
npm install

# 部署云函数
echo "部署徽章系统云函数..."
wx cloud functions deploy badgeSystem --env cloud1-8g0g5g5g5g5g5g

echo "徽章系统云函数部署完成！" 