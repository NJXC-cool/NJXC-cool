#!/bin/bash

echo "🔧 部署语音识别云函数..."

# 检查是否在正确的目录
if [ ! -d "cloudfunctions/speechRecognition" ]; then
    echo "❌ 错误：找不到 cloudfunctions/speechRecognition 目录"
    echo "请确保在项目根目录下运行此脚本"
    exit 1
fi

# 进入云函数目录
cd cloudfunctions/speechRecognition

echo "📦 安装依赖..."
npm install

echo "🚀 部署云函数..."
# 使用微信开发者工具的命令行工具部署
# 如果没有安装，请手动在微信开发者工具中右键点击云函数选择"上传并部署"

echo "✅ 部署完成！"
echo ""
echo "📝 注意事项："
echo "1. 如果使用微信开发者工具，请右键点击 cloudfunctions/speechRecognition"
echo "2. 选择'上传并部署：云端安装依赖'"
echo "3. 等待部署完成"
echo ""
echo "🔍 测试方法："
echo "1. 进入水宝助手页面"
echo "2. 切换到'打电话'模式"
echo "3. 按住麦克风按钮说话"
echo "4. 松开按钮查看识别结果"
echo ""
echo "🐛 如果仍有问题："
echo "1. 检查云开发环境是否正确配置"
echo "2. 确认云函数已成功部署"
echo "3. 查看控制台错误信息" 