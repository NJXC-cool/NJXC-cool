// 邀请码调试测试脚本
const crypto = require('crypto');

// 模拟简单的哈希函数（与客户端和云端保持一致）
function simpleHash(str) {
  let hash = 0;
  if (str.length === 0) return hash;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

// 模拟生成邀请码
function generateInviteCode(openid) {
  const hash = simpleHash(openid);
  return hash.toString(36).substr(0, 6).toUpperCase();
}

// 测试不同的openid生成邀请码
const testOpenids = [
  'test_user_1',
  'test_user_2', 
  'oWx123456789abcdef',
  'oWy987654321fedcba',
  'mock_openid_123'
];

console.log('=== 邀请码生成测试 ===');
testOpenids.forEach(openid => {
  const inviteCode = generateInviteCode(openid);
  console.log(`OpenID: ${openid} -> 邀请码: ${inviteCode}`);
});

console.log('\n=== 问题分析 ===');
console.log('可能的问题：');
console.log('1. 用户A的邀请码是本地生成的，没有同步到云端');
console.log('2. 用户B尝试添加用户A时，云端找不到对应的邀请码');
console.log('3. 需要确保所有邀请码都存储在云端的userProfiles集合中');

console.log('\n=== 解决方案 ===');
console.log('1. 修改generateInviteCode函数，确保总是同步到云端');
console.log('2. 在syncUserDataToCloud中包含邀请码同步');
console.log('3. 添加邀请码验证机制'); 