#!/bin/bash

echo "开始部署数据同步云函数..."

# 进入数据同步云函数目录
cd cloudfunctions/dataSync

# 安装依赖
echo "安装依赖..."
npm install

# 部署云函数
echo "部署数据同步云函数..."
wx cloud functions deploy dataSync --env cloud1-8g0g5g5g5g5g5g # 请替换为你的环境ID

echo "数据同步云函数部署完成！" 