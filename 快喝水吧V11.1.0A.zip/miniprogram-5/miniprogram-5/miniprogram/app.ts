// app.ts
import { getCurrentTheme } from './utils/theme'

App<IAppOption>({
  globalData: {},
  onLaunch() {
    if (wx.cloud) {
      wx.cloud.init({
        env: 'cloud1-4gxzckdha9c667e8' // 云开发环境ID
      })
    }
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        console.log(res.code)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      },
    })
    
    console.log('快喝水小程序启动成功');
    
    // 应用主题
    this.applyTheme();
  },
  
  onShow() {
    // 应用显示时的逻辑
  },
  
  onHide() {
    // 应用隐藏时的逻辑
  },

  // 应用主题
  applyTheme() {
    const theme = getCurrentTheme();
    // 设置全局主题数据
    this.globalData.theme = theme;
  }
})