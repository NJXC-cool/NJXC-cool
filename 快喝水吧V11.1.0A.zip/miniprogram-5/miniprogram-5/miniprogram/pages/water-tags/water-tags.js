const { getCurrentTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 心情标签
    moodTags: [
      { id: 'happy', emoji: '😊', label: '开心' },
      { id: 'tired', emoji: '😴', label: '疲惫' },
      { id: 'excited', emoji: '🤩', label: '兴奋' },
      { id: 'stressed', emoji: '😰', label: '压力' },
      { id: 'relaxed', emoji: '😌', label: '放松' },
      { id: 'energetic', emoji: '💪', label: '精力充沛' },
      { id: 'sad', emoji: '😢', label: '难过' },
      { id: 'focused', emoji: '🎯', label: '专注' },
      { id: 'normal', emoji: '😐', label: '一般' }
    ],
    
    // 场景标签
    sceneTags: [
      { id: 'work', emoji: '💼', label: '工作' },
      { id: 'exercise', emoji: '🏃', label: '运动' },
      { id: 'study', emoji: '📚', label: '学习' },
      { id: 'sleep', emoji: '😴', label: '睡前' },
      { id: 'wake', emoji: '🌅', label: '起床' },
      { id: 'meal', emoji: '🍽️', label: '餐后' },
      { id: 'meeting', emoji: '👥', label: '会议' },
      { id: 'travel', emoji: '✈️', label: '出行' },
      { id: 'other', emoji: '📍', label: '其他' }
    ],
    
    // 水温标签
    temperatureTags: [
      { id: 'hot', emoji: '🔥', label: '热水' },
      { id: 'warm', emoji: '☕', label: '温水' },
      { id: 'cold', emoji: '🧊', label: '冷水' },
      { id: 'room', emoji: '🌡️', label: '常温' }
    ],
    
    // 选中的标签
    selectedMood: '',
    selectedScene: '',
    selectedTemperature: '',
    customTag: '',
    
    // 预览数据
    hasSelectedTags: false,
    selectedTagsList: [],
    
    // 主题
    pageStyle: ''
  },

  onLoad: function (options) {
    this.applyCurrentTheme();
    
    // 如果有传入的标签数据，进行初始化
    if (options.tags) {
      try {
        const tags = JSON.parse(decodeURIComponent(options.tags));
        this.setData({
          selectedMood: tags.mood || '',
          selectedScene: tags.scene || '',
          selectedTemperature: tags.temperature || '',
          customTag: tags.custom || ''
        });
        this.updateSelectedTags();
      } catch (e) {
        console.error('解析标签数据失败:', e);
      }
    }
  },

  onShow: function () {
    this.applyCurrentTheme();
  },

  applyCurrentTheme: function () {
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  // 选择心情标签
  selectMood: function (e) {
    const moodId = e.currentTarget.dataset.id;
    this.setData({
      selectedMood: this.data.selectedMood === moodId ? '' : moodId
    });
    this.updateSelectedTags();
  },

  // 选择场景标签
  selectScene: function (e) {
    const sceneId = e.currentTarget.dataset.id;
    this.setData({
      selectedScene: this.data.selectedScene === sceneId ? '' : sceneId
    });
    this.updateSelectedTags();
  },

  // 选择水温标签
  selectTemperature: function (e) {
    const tempId = e.currentTarget.dataset.id;
    this.setData({
      selectedTemperature: this.data.selectedTemperature === tempId ? '' : tempId
    });
    this.updateSelectedTags();
  },

  // 自定义标签输入
  onCustomTagInput: function (e) {
    this.setData({
      customTag: e.detail.value
    });
    this.updateSelectedTags();
  },

  // 更新选中的标签列表
  updateSelectedTags: function () {
    const tags = [];
    
    // 添加心情标签
    if (this.data.selectedMood) {
      const moodTag = this.data.moodTags.find(tag => tag.id === this.data.selectedMood);
      if (moodTag) {
        tags.push(moodTag.emoji + ' ' + moodTag.label);
      }
    }
    
    // 添加场景标签
    if (this.data.selectedScene) {
      const sceneTag = this.data.sceneTags.find(tag => tag.id === this.data.selectedScene);
      if (sceneTag) {
        tags.push(sceneTag.emoji + ' ' + sceneTag.label);
      }
    }
    
    // 添加水温标签
    if (this.data.selectedTemperature) {
      const tempTag = this.data.temperatureTags.find(tag => tag.id === this.data.selectedTemperature);
      if (tempTag) {
        tags.push(tempTag.emoji + ' ' + tempTag.label);
      }
    }
    
    // 添加自定义标签
    if (this.data.customTag.trim()) {
      tags.push('✏️ ' + this.data.customTag.trim());
    }
    
    this.setData({
      selectedTagsList: tags,
      hasSelectedTags: tags.length > 0
    });
  },

  // 取消标签选择
  cancelTags: function () {
    wx.navigateBack();
  },

  // 确认标签选择
  confirmTags: function () {
    const tags = {
      mood: this.data.selectedMood,
      scene: this.data.selectedScene,
      temperature: this.data.selectedTemperature,
      custom: this.data.customTag.trim()
    };
    
    // 将标签数据传递给上一页
    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2];
    
    if (prevPage && prevPage.setWaterTags) {
      prevPage.setWaterTags(tags);
    }
    
    wx.navigateBack();
  },

  // 分享功能
  onShareAppMessage: function () {
    return {
      title: '快喝水 - 添加喝水标签',
      desc: '让每次喝水都更有意义',
      path: '/pages/water-tags/water-tags'
    };
  },

  onShareTimeline: function () {
    return {
      title: '快喝水 - 添加喝水标签',
      query: '',
      imageUrl: ''
    };
  }
}); 