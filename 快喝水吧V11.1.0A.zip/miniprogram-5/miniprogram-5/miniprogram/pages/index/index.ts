// index.ts
// 获取应用实例
const app = getApp<IAppOption>()
import { getCurrentTheme } from '../../utils/theme'
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

interface WaterRecord {
  id: string;
  amount: number;
  timestamp: number;
  time: string;
  tags?: string[];
}

interface CupOption {
  value: number;
  label: string;
}

Page({
  data: {
    today: '',
    dailyTarget: 2000,
    todayDrunk: 0,
    remaining: 2000,
    todayCups: 0,
    progressPercent: 0,
    progressAngle: 0,
    selectedCup: 250,
    manualInput: '',
    encouragement: '',
    todayRecords: [] as WaterRecord[],
    nickname: '',
    avatarUrl: '',
    defaultAvatarUrl: defaultAvatarUrl,

    showAnnouncementPopup: false,
    currentAnnouncement: {},
    cupOptions: [
      { value: 200, label: '小杯' },
      { value: 250, label: '标准' },
      { value: 300, label: '大杯' },
      { value: 350, label: '超大' },
      { value: 500, label: '水瓶' }
    ] as CupOption[],
    encouragements: [
      '保持水分，保持健康！',
      '喝水是身体最好的朋友',
      '每一滴水都是对身体的关爱',
      '保持水分，皮肤更水润',
      '喝水有助于新陈代谢',
      '健康生活从喝水开始',
      '保持水分，头脑更清醒',
      '喝水是减肥的好帮手'
    ],
    pendingManualAmount: undefined as number | undefined
  },

  onLoad() {
    this.initData();
    this.loadTodayData();
    this.loadUserInfo();
    this.applyCurrentTheme();
    this.checkAnnouncements();
  },

  onShow() {
    this.loadTodayData();
    this.loadUserInfo(); // 重新加载用户信息，确保从个人中心返回时能同步
    this.applyCurrentTheme();
    // 每次显示页面时都检查公告
    this.checkAnnouncements();
  },

  onShareAppMessage() {
    return {
      title: '快来快喝水小程序，健康喝水每一天！',
      path: '/pages/index/index'
    }
  },

  onShareTimeline() {
    return {
      title: '快来快喝水小程序，健康喝水每一天！',
      path: '/pages/index/index'
    }
  },

  // 初始化数据
  initData() {
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
    const defaultCupIndex = wx.getStorageSync('defaultCupIndex') || 0;
    const cupOptions = this.data.cupOptions;
    const selectedCup = cupOptions[defaultCupIndex] ? cupOptions[defaultCupIndex].value : 250;
    
    this.setData({
      dailyTarget,
      selectedCup
    });
  },

  // 加载今日数据
  loadTodayData() {
    const today = this.formatDate(new Date());
    const records = wx.getStorageSync('waterRecords') || {};
    const todayRecords = records[today] || [];
    
    const todayDrunk = todayRecords.reduce((sum: number, record: WaterRecord) => sum + record.amount, 0);
    const remaining = Math.max(0, this.data.dailyTarget - todayDrunk);
    const progressPercent = Math.min(100, Math.round((todayDrunk / this.data.dailyTarget) * 100));
    const progressAngle = (progressPercent / 100) * 360;

    this.setData({
      today,
      todayDrunk,
      remaining,
      todayCups: todayRecords.length,
      progressPercent,
      progressAngle,
      todayRecords: todayRecords.slice(-10).reverse() // 显示最近10条记录
    });
  },

  // 加载用户信息
  loadUserInfo() {
    // 优先从个人中心获取用户信息（支持新版个人中心数据结构）
    const userInfo = wx.getStorageSync('userInfo') || {};
    
    // 新版个人中心可能使用nickName/avatarUrl，也兼容旧版
    const nickname = userInfo.nickName || userInfo.nickname || wx.getStorageSync('nickname') || '';
    const avatarUrl = userInfo.avatarUrl || userInfo.avatar || wx.getStorageSync('avatarUrl') || '';
    
    this.setData({ 
      nickname, 
      avatarUrl 
    });
    
    console.log('用户信息同步状态:', { 
      nickname, 
      avatarUrl, 
      source: userInfo.nickName ? '个人中心' : '本地存储'
    });
  },

  // 跳转到个人中心设置信息
  goToProfileCenter() {
    console.log('跳转到个人中心设置信息');
    wx.switchTab({
      url: '/pages/profile/profile',
      success: () => {
        wx.showToast({
          title: '请在个人中心设置头像和昵称',
          icon: 'none',
          duration: 2500
        });
      }
    });
  },

  // 阻止事件冒泡
  stopPropagation() {
    // 阻止点击事件冒泡到父级
  },

  // @deprecated 已弃用：旧版getUserProfile方法
  // 新版本请使用 onChooseAvatar + onInputNickname
  getBasicUserProfile() {
    wx.getUserProfile({
      desc: '用于显示用户昵称和头像',
      success: (res) => {
        const { nickName, avatarUrl } = res.userInfo;
        this.setData({ nickname: nickName, avatarUrl });
        wx.setStorageSync('nickname', nickName);
        wx.setStorageSync('avatarUrl', avatarUrl);
        
        // 基础用户数据
        const userData = wx.getStorageSync('userData') || {};
        userData.nickname = nickName;
        userData.avatarUrl = avatarUrl;
        userData.days = userData.days || 0;
        userData.lastCheckDate = userData.lastCheckDate || '';
        userData.totalVolume = userData.totalVolume || 0;
        userData.checkTimes = userData.checkTimes || [];
        wx.setStorageSync('userData', userData);

        wx.showToast({
          title: '基础信息获取成功',
          icon: 'success'
        });
      },
      fail: (err) => {
        console.error('获取用户信息失败:', err);
        
        // 如果是隐私协议错误，提供解决方案
        if ((err as any).errno === 112 || err.errMsg?.includes('privacy agreement')) {
          wx.showModal({
            title: '隐私授权配置提示',
            content: '需要在小程序后台配置用户隐私保护指引：\n\n1. 登录小程序管理后台\n2. 设置-服务内容声明-用户隐私保护指引\n3. 添加"用户信息"收集类型\n4. 5分钟后生效\n\n暂时将使用默认用户信息',
            showCancel: false,
            confirmText: '知道了',
            success: () => {
              // 使用默认用户信息
              this.useDefaultUserInfo();
            }
          });
        } else {
          wx.showToast({
            title: '获取信息失败',
            icon: 'error'
          });
        }
      }
    });
  },

  // 使用默认用户信息
  useDefaultUserInfo() {
    const defaultNickname = '快喝水用户';
    const defaultAvatarUrl = '../../images/icons/avatar.png';
    
    this.setData({ 
      nickname: defaultNickname, 
      avatarUrl: defaultAvatarUrl 
    });
    wx.setStorageSync('nickname', defaultNickname);
    wx.setStorageSync('avatarUrl', defaultAvatarUrl);
    
    // 基础用户数据
    const userData = wx.getStorageSync('userData') || {};
    userData.nickname = defaultNickname;
    userData.avatarUrl = defaultAvatarUrl;
    userData.days = userData.days || 0;
    userData.lastCheckDate = userData.lastCheckDate || '';
    userData.totalVolume = userData.totalVolume || 0;
    userData.checkTimes = userData.checkTimes || [];
    wx.setStorageSync('userData', userData);

    wx.showToast({
      title: '已设置默认信息',
      icon: 'success'
    });
  },

  // 完整用户信息获取
  getFullUserProfile() {
    wx.getUserProfile({
      desc: '用于完善用户资料和个性化服务',
      success: (res) => {
        const { nickName, avatarUrl, gender, country, province, city, language } = res.userInfo;
        this.setData({ nickname: nickName, avatarUrl });
        wx.setStorageSync('nickname', nickName);
        wx.setStorageSync('avatarUrl', avatarUrl);
        
        // 完整用户数据
        const userData = wx.getStorageSync('userData') || {};
        userData.nickname = nickName;
        userData.avatarUrl = avatarUrl;
        userData.gender = gender;
        userData.country = country;
        userData.province = province;
        userData.city = city;
        userData.language = language;
        userData.days = userData.days || 0;
        userData.lastCheckDate = userData.lastCheckDate || '';
        userData.totalVolume = userData.totalVolume || 0;
        userData.checkTimes = userData.checkTimes || [];
        userData.profileComplete = true;
        wx.setStorageSync('userData', userData);

        wx.showToast({
          title: '完整信息获取成功',
          icon: 'success'
        });

        // 可以在这里调用云函数保存用户信息
        this.saveUserInfoToCloud(userData);
      },
      fail: (err) => {
        console.error('完整获取用户信息失败:', err);
        
        // 如果是隐私协议错误，提供解决方案
        if ((err as any).errno === 112 || err.errMsg?.includes('privacy agreement')) {
          wx.showModal({
            title: '隐私授权配置提示',
            content: '需要在小程序后台配置用户隐私保护指引：\n\n1. 登录小程序管理后台\n2. 设置-服务内容声明-用户隐私保护指引\n3. 添加"用户信息"收集类型\n4. 5分钟后生效\n\n暂时将使用默认用户信息',
            showCancel: false,
            confirmText: '知道了',
            success: () => {
              // 使用默认用户信息
              this.useDefaultUserInfo();
            }
          });
        } else {
          wx.showModal({
            title: '获取用户信息失败',
            content: '❌ 无法获取用户信息！\n\n可能原因：\n1. 用户拒绝授权\n2. 网络连接问题\n3. 微信版本不支持\n\n建议尝试基础获取模式。',
            confirmText: '尝试基础获取',
            cancelText: '取消',
            success: (modalRes) => {
              if (modalRes.confirm) {
                this.getBasicUserProfile();
              }
            }
          });
        }
      }
    });
  },

  // 保存用户信息到云端
  saveUserInfoToCloud(userData: any) {
    wx.cloud.callFunction({
      name: 'sendReminder',
      data: {
        action: 'saveUserInfo',
        userInfo: userData
      },
      success: (res: any) => {
        console.log('用户信息保存到云端成功:', res);
      },
      fail: (err) => {
        console.error('保存用户信息到云端失败:', err);
      }
    });
  },

  // 选择杯子容量
  selectCup(e: any) {
    const value = e.currentTarget.dataset.value;
    this.setData({ selectedCup: value });
    
    // 保存默认杯子设置
    const cupOptions = this.data.cupOptions;
    const defaultCupIndex = cupOptions.findIndex(cup => cup.value === value);
    if (defaultCupIndex !== -1) {
      wx.setStorageSync('defaultCupIndex', defaultCupIndex);
    }
  },

  // 记录喝水
  recordDrink() {
    // 询问是否添加标签
    wx.showModal({
      title: '添加标签',
      content: '是否要为这次喝水添加标签？',
      confirmText: '添加标签',
      cancelText: '直接记录',
      success: (res) => {
        if (res.confirm) {
          // 跳转到标签选择页面
          wx.navigateTo({
            url: '/pages/water-tags/water-tags'
          });
        } else {
          // 直接记录，不添加标签
          this.addWaterRecord(this.data.selectedCup);
        }
      }
    });
  },

  // 手动输入处理
  onManualInput(e: any) {
    this.setData({ manualInput: e.detail.value });
  },

  // 添加手动输入的水量
  addManualDrink() {
    const amount = parseInt(this.data.manualInput);
    if (amount && amount > 0) {
      // 询问是否添加标签
      wx.showModal({
        title: '添加标签',
        content: '是否要为这次喝水添加标签？',
        confirmText: '添加标签',
        cancelText: '直接记录',
        success: (res) => {
          if (res.confirm) {
            // 保存水量，跳转到标签选择页面
            this.setData({ 
              manualInput: '',
              pendingManualAmount: amount 
            });
            wx.navigateTo({
              url: '/pages/water-tags/water-tags'
            });
          } else {
            // 直接记录，不添加标签
            this.addWaterRecord(amount);
            this.setData({ manualInput: '' });
          }
        }
      });
    } else {
      wx.showToast({
        title: '请输入有效的水量',
        icon: 'none'
      });
    }
  },

  // 添加喝水记录
  addWaterRecord(amount: number, tags?: any) {
    const now = new Date();
    const today = this.formatDate(now);
    
    // 处理标签
    let tagList: string[] = [];
    if (tags) {
      if (tags.mood) {
        const moodEmojis: { [key: string]: string } = {
          'happy': '😊', 'tired': '😴', 'excited': '🤩', 'stressed': '😰',
          'relaxed': '😌', 'energetic': '💪', 'sad': '😢', 'focused': '🎯', 'normal': '😐'
        };
        const moodLabels: { [key: string]: string } = {
          'happy': '开心', 'tired': '疲惫', 'excited': '兴奋', 'stressed': '压力',
          'relaxed': '放松', 'energetic': '精力充沛', 'sad': '难过', 'focused': '专注', 'normal': '一般'
        };
        tagList.push(moodEmojis[tags.mood] + ' ' + moodLabels[tags.mood]);
      }
      
      if (tags.scene) {
        const sceneEmojis: { [key: string]: string } = {
          'work': '💼', 'exercise': '🏃', 'study': '📚', 'sleep': '😴',
          'wake': '🌅', 'meal': '🍽️', 'meeting': '👥', 'travel': '✈️', 'other': '📍'
        };
        const sceneLabels: { [key: string]: string } = {
          'work': '工作', 'exercise': '运动', 'study': '学习', 'sleep': '睡前',
          'wake': '起床', 'meal': '餐后', 'meeting': '会议', 'travel': '出行', 'other': '其他'
        };
        tagList.push(sceneEmojis[tags.scene] + ' ' + sceneLabels[tags.scene]);
      }
      
      if (tags.temperature) {
        const tempEmojis: { [key: string]: string } = {
          'hot': '🔥', 'warm': '☕', 'cold': '🧊', 'room': '🌡️'
        };
        const tempLabels: { [key: string]: string } = {
          'hot': '热水', 'warm': '温水', 'cold': '冷水', 'room': '常温'
        };
        tagList.push(tempEmojis[tags.temperature] + ' ' + tempLabels[tags.temperature]);
      }
      
      if (tags.custom && tags.custom.trim()) {
        tagList.push('✏️ ' + tags.custom.trim());
      }
    }
    
    const record: WaterRecord = {
      id: Date.now().toString(),
      amount,
      timestamp: now.getTime(),
      time: this.formatTime(now),
      tags: tagList.length > 0 ? tagList : undefined
    };

    // 获取现有记录
    const records = wx.getStorageSync('waterRecords') || {};
    const todayRecords = records[today] || [];
    todayRecords.push(record);
    records[today] = todayRecords;

    // 保存记录
    wx.setStorageSync('waterRecords', records);

    // 更新显示
    this.loadTodayData();

    // 显示鼓励语句
    this.showEncouragement();

    // 震动反馈
    wx.vibrateShort({ type: 'light' });

    // 显示成功提示
    wx.showToast({
      title: `已记录 ${amount}ml`,
      icon: 'success'
    });

    // --- 云数据库写入/更新排行榜数据 ---
    const userData = wx.getStorageSync('userData') || {};
    const todayStr = today;
    let days = userData.days || 0;
    let lastCheckDate = userData.lastCheckDate || '';
    let totalVolume = userData.totalVolume || 0;
    let checkTimes = userData.checkTimes || [];
    // 连续打卡天数逻辑
    if (lastCheckDate !== todayStr) {
      days += 1;
      lastCheckDate = todayStr;
    }
    // 添加当前日期到打卡记录中
    if (!checkTimes.includes(todayStr)) {
      checkTimes.push(todayStr);
    }
    userData.days = days;
    userData.lastCheckDate = lastCheckDate;
    userData.totalVolume = totalVolume + amount;
    userData.checkTimes = checkTimes;
    wx.setStorageSync('userData', userData);

    // 自动同步数据到云端
    this.autoSyncData();
  },

  // 设置喝水标签（从标签页面返回时调用）
  setWaterTags(tags: any) {
    // 如果有待处理的手动输入水量，使用它；否则使用选中的杯量
    const amount = this.data.pendingManualAmount || this.data.selectedCup;
    this.addWaterRecord(amount, tags);
    // 清除待处理的水量
    this.setData({ pendingManualAmount: undefined });
  },

  // 自动同步数据
  autoSyncData() {
    const DataSync = require('../../utils/dataSync.js');
    
    // 延迟同步，避免频繁调用
    setTimeout(() => {
      DataSync.syncWaterRecords().then(() => {
        console.log('喝水记录自动同步成功');
      }).catch((err: any) => {
        console.log('喝水记录自动同步失败:', err);
      });
    }, 1000);
  },

  // 显示鼓励语句
  showEncouragement() {
    const encouragements = this.data.encouragements;
    const randomIndex = Math.floor(Math.random() * encouragements.length);
    const encouragement = encouragements[randomIndex];
    
    this.setData({ encouragement });
    
    // 3秒后隐藏
    setTimeout(() => {
      this.setData({ encouragement: '' });
    }, 3000);
  },

  // 格式化日期
  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  // 格式化时间
  formatTime(date: Date): string {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
  },

  // 应用当前主题
  applyCurrentTheme() {
    const theme = getCurrentTheme();
    this.setData({
      theme: theme,
      pageStyle: `background: ${theme.backgroundColor};`
    });
  },

  // 检查公告
  checkAnnouncements() {
    // 检查云开发是否初始化
    if (!wx.cloud) {
      return;
    }
    
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'getAll'
      },
      success: (res: any) => {
        if (res.result && res.result.success && res.result.data && res.result.data.length > 0) {
          // 筛选未读公告
          const unreadAnnouncements = res.result.data.filter((item: any) => !item.isRead);
          
          if (unreadAnnouncements.length > 0) {
            const announcement = unreadAnnouncements[0];
            announcement.createTimeStr = this.formatAnnouncementTime(announcement.createTime);
            this.setData({
              showAnnouncementPopup: true,
              currentAnnouncement: announcement
            });
          }
        }
      },
      fail: (err: any) => {
        console.error('检查公告失败:', err);
      }
    });
  },

  // 格式化公告时间
  formatAnnouncementTime(date: Date): string {
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    
    if (diff < 60000) {
      return '刚刚';
    } else if (diff < 3600000) {
      return Math.floor(diff / 60000) + '分钟前';
    } else if (diff < 86400000) {
      return Math.floor(diff / 3600000) + '小时前';
    } else {
      return d.toLocaleDateString();
    }
  },

  // 公告弹窗关闭
  onAnnouncementPopupClose() {
    this.setData({ showAnnouncementPopup: false });
  },

  // 标记公告已读
  onAnnouncementMarkAsRead(e: any) {
    const { id } = e.detail;
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'markAsRead',
        data: { id }
      },
      success: (res: any) => {
        if (res.result.success) {
          this.setData({ showAnnouncementPopup: false });
          
          // 显示已读提示
          wx.showToast({
            title: '已读+1！',
            icon: 'success',
            duration: 1500
          });
        }
      }
    });
  },

  // 查看更多公告
  onAnnouncementViewMore() {
    this.setData({ showAnnouncementPopup: false });
    wx.navigateTo({
      url: '/pages/announcement/announcement'
    });
  },

  // 跳转到个人中心
  goToProfile() {
    wx.switchTab({
      url: '/pages/profile/profile'
    });
  }
});
