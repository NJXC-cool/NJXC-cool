Page({
  goHome() {
    wx.reLaunch({ url: '/pages/index/index' });
  }
}); 