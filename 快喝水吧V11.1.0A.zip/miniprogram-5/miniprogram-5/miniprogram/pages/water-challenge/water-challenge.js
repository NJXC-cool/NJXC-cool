const { getCurrentTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 挑战数据
    ongoingChallenges: [],
    continuousChallenges: [],
    festivalChallenges: [],
    solarTermChallenges: [],
    memorialChallenges: [],
    completedChallenges: [],
    
    // 统计数据
    totalChallenges: 0,
    completedCount: 0,
    successRate: 0,
    totalRewards: 0,
    
    // 主题
    pageStyle: ''
  },

  onLoad: function (options) {
    this.applyCurrentTheme();
    
    // 测试日期计算
    const today = new Date();
    console.log('当前日期:', today.toISOString().split('T')[0]);
    console.log('当前年份:', today.getFullYear());
    
    this.loadChallenges();
    this.checkDailyProgress();
  },

  onShow: function () {
    this.applyCurrentTheme();
    this.loadChallenges();
    this.checkDailyProgress();
  },

  applyCurrentTheme: function () {
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  // 加载挑战数据
  loadChallenges: function () {
    const challenges = wx.getStorageSync('waterChallenges') || [];
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
    
    // 生成可用的挑战
    this.generateAvailableChallenges(dailyTarget);
    
    // 分类挑战
    this.categorizeChallenges(challenges);
    
    // 计算统计数据
    this.calculateStats(challenges);
  },

  // 生成可用的挑战
  generateAvailableChallenges: function (dailyTarget) {
    const currentYear = new Date().getFullYear();
    const existingChallenges = wx.getStorageSync('waterChallenges') || [];
    
    // 连续挑战
    const continuousChallenges = [
      {
        id: 'continuous_7',
        type: 'continuous',
        name: '7天连续挑战',
        description: '连续7天达到每日目标',
        icon: '🎯',
        totalDays: 7,
        targetAmount: dailyTarget,
        reward: '🏆 坚持达人',
        available: !existingChallenges.some(c => c.id === 'continuous_7' && c.status === 'ongoing')
      },
      {
        id: 'continuous_30',
        type: 'continuous',
        name: '30天连续挑战',
        description: '连续30天达到每日目标',
        icon: '🔥',
        totalDays: 30,
        targetAmount: dailyTarget,
        reward: '👑 喝水王者',
        available: !existingChallenges.some(c => c.id === 'continuous_30' && c.status === 'ongoing')
      }
    ];

    // 节日挑战
    const festivalChallenges = this.getFestivalChallenges(currentYear, dailyTarget, existingChallenges);

    // 24节气挑战
    const solarTermChallenges = this.getSolarTermChallenges(currentYear, dailyTarget, existingChallenges);

    // 纪念日挑战
    const memorialChallenges = this.getMemorialChallenges(currentYear, dailyTarget, existingChallenges);

    console.log('生成的挑战数据:', {
      continuousChallenges: continuousChallenges.length,
      festivalChallenges: festivalChallenges.length,
      solarTermChallenges: solarTermChallenges.length,
      memorialChallenges: memorialChallenges.length
    });

    console.log('24节气详细数据:', solarTermChallenges);

    this.setData({
      continuousChallenges: continuousChallenges || [],
      festivalChallenges: festivalChallenges || [],
      solarTermChallenges: solarTermChallenges || [],
      memorialChallenges: memorialChallenges || []
    });

    console.log('setData完成，当前数据:', {
      continuousChallenges: this.data.continuousChallenges.length,
      festivalChallenges: this.data.festivalChallenges.length,
      solarTermChallenges: this.data.solarTermChallenges.length,
      memorialChallenges: this.data.memorialChallenges.length
    });
  },

  // 获取节日挑战
  getFestivalChallenges: function (year, dailyTarget) {
    const festivals = [
      {
        id: 'spring_festival',
        name: '春节挑战',
        description: '在春节当天完成喝水目标',
        icon: '🧨',
        date: `${year}-02-10`, // 春节日期需要根据农历计算
        targetAmount: dailyTarget,
        reward: '🧧 新春祝福',
        type: 'festival',
        totalDays: 1
      },
      {
        id: 'national_day',
        name: '国庆挑战',
        description: '在国庆节完成喝水目标',
        icon: '🇨🇳',
        date: `${year}-10-01`,
        targetAmount: dailyTarget,
        reward: '🎊 爱国之星',
        type: 'festival',
        totalDays: 1
      },
      {
        id: 'mid_autumn',
        name: '中秋挑战',
        description: '在中秋节完成喝水目标',
        icon: '🌕',
        date: `${year}-09-29`, // 需要根据农历计算
        targetAmount: dailyTarget,
        reward: '🥮 团圆之星',
        type: 'festival',
        totalDays: 1
      }
    ];

    return festivals.filter(festival => {
      const festivalDate = new Date(festival.date);
      const today = new Date();
      const diffTime = festivalDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      // 只显示未来30天内的节日
      return diffDays >= -1 && diffDays <= 30;
    });
  },

  // 获取24节气挑战 - 使用正确的农历日期
  getSolarTermChallenges: function (year, dailyTarget) {
    // 2024年的24节气日期（农历）
    const solarTerms2024 = [
      // 春季
      { id: 'lichun', name: '立春', description: '春季第一个节气，万物开始复苏', icon: '🌱', date: '2024-02-04', targetAmount: dailyTarget, reward: '🌱 春之始', type: 'solar_term', totalDays: 1 },
      { id: 'yushui', name: '雨水', description: '雨水增多，草木萌动', icon: '🌧️', date: '2024-02-19', targetAmount: dailyTarget, reward: '🌧️ 雨润万物', type: 'solar_term', totalDays: 1 },
      { id: 'jingzhe', name: '惊蛰', description: '春雷始鸣，惊醒蛰伏的动物', icon: '⚡', date: '2024-03-05', targetAmount: dailyTarget, reward: '⚡ 春雷惊蛰', type: 'solar_term', totalDays: 1 },
      { id: 'chunfen', name: '春分', description: '昼夜平分，春意正浓', icon: '🌸', date: '2024-03-20', targetAmount: dailyTarget, reward: '🌸 春意盎然', type: 'solar_term', totalDays: 1 },
      { id: 'qingming', name: '清明', description: '天气清爽明朗，适合踏青', icon: '🌿', date: '2024-04-04', targetAmount: dailyTarget, reward: '🌿 清明时节', type: 'solar_term', totalDays: 1 },
      { id: 'guyu', name: '谷雨', description: '雨生百谷，播种的好时节', icon: '🌾', date: '2024-04-20', targetAmount: dailyTarget, reward: '🌾 谷雨润物', type: 'solar_term', totalDays: 1 },
      // 夏季
      { id: 'lixia', name: '立夏', description: '夏季开始，万物生长', icon: '🌞', date: '2024-05-05', targetAmount: dailyTarget, reward: '🌞 夏之始', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoman', name: '小满', description: '夏熟作物籽粒开始饱满', icon: '🌻', date: '2024-05-21', targetAmount: dailyTarget, reward: '🌻 小满盈满', type: 'solar_term', totalDays: 1 },
      { id: 'mangzhong', name: '芒种', description: '有芒的麦子快收，有芒的稻子可种', icon: '🌾', date: '2024-06-05', targetAmount: dailyTarget, reward: '🌾 芒种忙种', type: 'solar_term', totalDays: 1 },
      { id: 'xiazhi', name: '夏至', description: '一年中白昼最长的一天', icon: '☀️', date: '2024-06-21', targetAmount: dailyTarget, reward: '☀️ 夏日骄阳', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoshu', name: '小暑', description: '天气开始炎热', icon: '🔥', date: '2024-07-06', targetAmount: dailyTarget, reward: '🔥 小暑炎热', type: 'solar_term', totalDays: 1 },
      { id: 'dashu', name: '大暑', description: '一年中最炎热的时节', icon: '🌡️', date: '2024-07-22', targetAmount: dailyTarget, reward: '🌡️ 大暑酷热', type: 'solar_term', totalDays: 1 },
      // 秋季
      { id: 'liqiu', name: '立秋', description: '秋季开始，暑去凉来', icon: '🍂', date: '2024-08-07', targetAmount: dailyTarget, reward: '🍂 秋之始', type: 'solar_term', totalDays: 1 },
      { id: 'chushu', name: '处暑', description: '暑气开始消退', icon: '🍃', date: '2024-08-23', targetAmount: dailyTarget, reward: '🍃 处暑凉来', type: 'solar_term', totalDays: 1 },
      { id: 'bailu', name: '白露', description: '天气转凉，露水凝结', icon: '💧', date: '2024-09-07', targetAmount: dailyTarget, reward: '💧 白露为霜', type: 'solar_term', totalDays: 1 },
      { id: 'qiufen', name: '秋分', description: '昼夜平分，秋意正浓', icon: '🍁', date: '2024-09-23', targetAmount: dailyTarget, reward: '🍁 秋意浓浓', type: 'solar_term', totalDays: 1 },
      { id: 'hanlu', name: '寒露', description: '露水将要结冰', icon: '❄️', date: '2024-10-08', targetAmount: dailyTarget, reward: '❄️ 寒露凝霜', type: 'solar_term', totalDays: 1 },
      { id: 'shuangjiang', name: '霜降', description: '开始降霜，天气渐冷', icon: '🌨️', date: '2024-10-23', targetAmount: dailyTarget, reward: '🌨️ 霜降寒来', type: 'solar_term', totalDays: 1 },
      // 冬季
      { id: 'lidong', name: '立冬', description: '冬季开始，万物收藏', icon: '❄️', date: '2024-11-07', targetAmount: dailyTarget, reward: '❄️ 冬之始', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoxue', name: '小雪', description: '开始下雪，天气寒冷', icon: '🌨️', date: '2024-11-22', targetAmount: dailyTarget, reward: '🌨️ 小雪纷飞', type: 'solar_term', totalDays: 1 },
      { id: 'daxue', name: '大雪', description: '降雪量增多，地面可能积雪', icon: '⛄', date: '2024-12-07', targetAmount: dailyTarget, reward: '⛄ 大雪纷飞', type: 'solar_term', totalDays: 1 },
      { id: 'dongzhi', name: '冬至', description: '一年中白昼最短的一天', icon: '🌨️', date: '2024-12-21', targetAmount: dailyTarget, reward: '🌨️ 冬日暖阳', type: 'solar_term', totalDays: 1 },
      { id: 'xiaohan', name: '小寒', description: '天气寒冷，但还未到最冷', icon: '🧊', date: '2024-01-06', targetAmount: dailyTarget, reward: '🧊 小寒料峭', type: 'solar_term', totalDays: 1 },
      { id: 'dahan', name: '大寒', description: '一年中最寒冷的时节', icon: '🥶', date: '2024-01-20', targetAmount: dailyTarget, reward: '🥶 大寒极冷', type: 'solar_term', totalDays: 1 }
    ];

    // 2025年的24节气日期（农历）
    const solarTerms2025 = [
      // 春季
      { id: 'lichun_2025', name: '立春', description: '春季第一个节气，万物开始复苏', icon: '🌱', date: '2025-02-03', targetAmount: dailyTarget, reward: '🌱 春之始', type: 'solar_term', totalDays: 1 },
      { id: 'yushui_2025', name: '雨水', description: '雨水增多，草木萌动', icon: '🌧️', date: '2025-02-18', targetAmount: dailyTarget, reward: '🌧️ 雨润万物', type: 'solar_term', totalDays: 1 },
      { id: 'jingzhe_2025', name: '惊蛰', description: '春雷始鸣，惊醒蛰伏的动物', icon: '⚡', date: '2025-03-05', targetAmount: dailyTarget, reward: '⚡ 春雷惊蛰', type: 'solar_term', totalDays: 1 },
      { id: 'chunfen_2025', name: '春分', description: '昼夜平分，春意正浓', icon: '🌸', date: '2025-03-20', targetAmount: dailyTarget, reward: '🌸 春意盎然', type: 'solar_term', totalDays: 1 },
      { id: 'qingming_2025', name: '清明', description: '天气清爽明朗，适合踏青', icon: '🌿', date: '2025-04-04', targetAmount: dailyTarget, reward: '🌿 清明时节', type: 'solar_term', totalDays: 1 },
      { id: 'guyu_2025', name: '谷雨', description: '雨生百谷，播种的好时节', icon: '🌾', date: '2025-04-20', targetAmount: dailyTarget, reward: '🌾 谷雨润物', type: 'solar_term', totalDays: 1 },
      // 夏季
      { id: 'lixia_2025', name: '立夏', description: '夏季开始，万物生长', icon: '🌞', date: '2025-05-05', targetAmount: dailyTarget, reward: '🌞 夏之始', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoman_2025', name: '小满', description: '夏熟作物籽粒开始饱满', icon: '🌻', date: '2025-05-21', targetAmount: dailyTarget, reward: '🌻 小满盈满', type: 'solar_term', totalDays: 1 },
      { id: 'mangzhong_2025', name: '芒种', description: '有芒的麦子快收，有芒的稻子可种', icon: '🌾', date: '2025-06-05', targetAmount: dailyTarget, reward: '🌾 芒种忙种', type: 'solar_term', totalDays: 1 },
      { id: 'xiazhi_2025', name: '夏至', description: '一年中白昼最长的一天', icon: '☀️', date: '2025-06-21', targetAmount: dailyTarget, reward: '☀️ 夏日骄阳', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoshu_2025', name: '小暑', description: '天气开始炎热', icon: '🔥', date: '2025-07-07', targetAmount: dailyTarget, reward: '🔥 小暑炎热', type: 'solar_term', totalDays: 1 },
      { id: 'dashu_2025', name: '大暑', description: '一年中最炎热的时节', icon: '🌡️', date: '2025-07-22', targetAmount: dailyTarget, reward: '🌡️ 大暑酷热', type: 'solar_term', totalDays: 1 },
      // 秋季
      { id: 'liqiu_2025', name: '立秋', description: '秋季开始，暑去凉来', icon: '🍂', date: '2025-08-07', targetAmount: dailyTarget, reward: '🍂 秋之始', type: 'solar_term', totalDays: 1 },
      { id: 'chushu_2025', name: '处暑', description: '暑气开始消退', icon: '🍃', date: '2025-08-23', targetAmount: dailyTarget, reward: '🍃 处暑凉来', type: 'solar_term', totalDays: 1 },
      { id: 'bailu_2025', name: '白露', description: '天气转凉，露水凝结', icon: '💧', date: '2025-09-07', targetAmount: dailyTarget, reward: '💧 白露为霜', type: 'solar_term', totalDays: 1 },
      { id: 'qiufen_2025', name: '秋分', description: '昼夜平分，秋意正浓', icon: '🍁', date: '2025-09-23', targetAmount: dailyTarget, reward: '🍁 秋意浓浓', type: 'solar_term', totalDays: 1 },
      { id: 'hanlu_2025', name: '寒露', description: '露水将要结冰', icon: '❄️', date: '2025-10-08', targetAmount: dailyTarget, reward: '❄️ 寒露凝霜', type: 'solar_term', totalDays: 1 },
      { id: 'shuangjiang_2025', name: '霜降', description: '开始降霜，天气渐冷', icon: '🌨️', date: '2025-10-23', targetAmount: dailyTarget, reward: '🌨️ 霜降寒来', type: 'solar_term', totalDays: 1 },
      // 冬季
      { id: 'lidong_2025', name: '立冬', description: '冬季开始，万物收藏', icon: '❄️', date: '2025-11-07', targetAmount: dailyTarget, reward: '❄️ 冬之始', type: 'solar_term', totalDays: 1 },
      { id: 'xiaoxue_2025', name: '小雪', description: '开始下雪，天气寒冷', icon: '🌨️', date: '2025-11-22', targetAmount: dailyTarget, reward: '🌨️ 小雪纷飞', type: 'solar_term', totalDays: 1 },
      { id: 'daxue_2025', name: '大雪', description: '降雪量增多，地面可能积雪', icon: '⛄', date: '2025-12-07', targetAmount: dailyTarget, reward: '⛄ 大雪纷飞', type: 'solar_term', totalDays: 1 },
      { id: 'dongzhi_2025', name: '冬至', description: '一年中白昼最短的一天', icon: '🌨️', date: '2025-12-21', targetAmount: dailyTarget, reward: '🌨️ 冬日暖阳', type: 'solar_term', totalDays: 1 },
      { id: 'xiaohan_2025', name: '小寒', description: '天气寒冷，但还未到最冷', icon: '🧊', date: '2025-01-05', targetAmount: dailyTarget, reward: '🧊 小寒料峭', type: 'solar_term', totalDays: 1 },
      { id: 'dahan_2025', name: '大寒', description: '一年中最寒冷的时节', icon: '🥶', date: '2025-01-20', targetAmount: dailyTarget, reward: '🥶 大寒极冷', type: 'solar_term', totalDays: 1 }
    ];

    // 合并两年的节气数据
    const allSolarTerms = [...solarTerms2024, ...solarTerms2025];
    
    console.log('所有节气数据:', allSolarTerms.length, '个');
    console.log('当前日期:', new Date().toISOString().split('T')[0]);

    const filteredTerms = allSolarTerms.filter(term => {
      const termDate = new Date(term.date);
      const today = new Date();
      const diffTime = termDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      console.log(`节气 ${term.name} (${term.date}): 距离今天 ${diffDays} 天`);
      
      // 临时：显示更多节气以便测试，包括过去7天和未来60天
      return diffDays >= -7 && diffDays <= 60;
    });

    console.log('过滤后的节气:', filteredTerms.length, '个');
    return filteredTerms;
  },

  // 获取纪念日挑战
  getMemorialChallenges: function (year, dailyTarget) {
    const memorials = [
      {
        id: 'nanking_massacre',
        name: '南京大屠杀纪念日',
        description: '铭记历史，珍爱和平',
        icon: '🕊️',
        date: `${year}-12-13`,
        targetAmount: dailyTarget,
        reward: '🕊️ 和平使者',
        type: 'memorial',
        totalDays: 1
      },
      {
        id: 'japan_surrender',
        name: '日本投降纪念日',
        description: '铭记胜利，珍惜和平',
        icon: '✌️',
        date: `${year}-08-15`,
        targetAmount: dailyTarget,
        reward: '✌️ 胜利之星',
        type: 'memorial',
        totalDays: 1
      }
    ];

    return memorials.filter(memorial => {
      const memorialDate = new Date(memorial.date);
      const today = new Date();
      const diffTime = memorialDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      // 只显示未来30天内的纪念日
      return diffDays >= -1 && diffDays <= 30;
    });
  },

  // 分类挑战
  categorizeChallenges: function (challenges) {
    const ongoing = [];
    const completed = [];

    challenges.forEach(challenge => {
      if (challenge.status === 'ongoing') {
        // 计算进度
        const progress = this.calculateChallengeProgress(challenge);
        challenge.currentDay = progress.currentDay;
        challenge.progressPercent = progress.progressPercent;
        challenge.progressAngle = progress.progressAngle;
        ongoing.push(challenge);
      } else if (challenge.status === 'completed') {
        challenge.completionDate = this.formatDate(new Date(challenge.completionTime));
        completed.push(challenge);
      }
    });

    this.setData({
      ongoingChallenges: ongoing,
      completedChallenges: completed
    });
  },

  // 计算挑战进度
  calculateChallengeProgress: function (challenge) {
    // 对于节日、纪念日和节气挑战，使用完成天数作为进度
    if (challenge.type === 'festival' || challenge.type === 'memorial' || challenge.type === 'solar_term') {
      const progressPercent = Math.min(100, Math.round((challenge.completedDays / challenge.totalDays) * 100));
      const progressAngle = (progressPercent / 100) * 360;
      
      return {
        currentDay: challenge.completedDays,
        progressPercent,
        progressAngle
      };
    }
    
    // 对于连续挑战，使用天数计算
    const today = new Date();
    const startDate = new Date(challenge.startTime);
    const diffTime = today.getTime() - startDate.getTime();
    const currentDay = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1;
    
    let progressPercent = Math.min(100, Math.round((currentDay / challenge.totalDays) * 100));
    let progressAngle = (progressPercent / 100) * 360;

    return {
      currentDay: Math.min(currentDay, challenge.totalDays),
      progressPercent,
      progressAngle
    };
  },

  // 计算统计数据
  calculateStats: function (challenges) {
    const totalChallenges = challenges.length;
    const completedCount = challenges.filter(c => c.status === 'completed').length;
    const successRate = totalChallenges > 0 ? Math.round((completedCount / totalChallenges) * 100) : 0;
    const totalRewards = completedCount;

    this.setData({
      totalChallenges,
      completedCount,
      successRate,
      totalRewards
    });
  },

  // 开始挑战
  startChallenge: function (e) {
    const challengeId = e.currentTarget.dataset.id;
    
    // 查找挑战信息
    let challenge = null;
    if (this.data.continuousChallenges.find(c => c.id === challengeId)) {
      challenge = this.data.continuousChallenges.find(c => c.id === challengeId);
    } else if (this.data.festivalChallenges.find(c => c.id === challengeId)) {
      challenge = this.data.festivalChallenges.find(c => c.id === challengeId);
    } else if (this.data.solarTermChallenges.find(c => c.id === challengeId)) {
      challenge = this.data.solarTermChallenges.find(c => c.id === challengeId);
    } else if (this.data.memorialChallenges.find(c => c.id === challengeId)) {
      challenge = this.data.memorialChallenges.find(c => c.id === challengeId);
    }

    if (!challenge) {
      wx.showToast({
        title: '挑战信息不存在',
        icon: 'none'
      });
      return;
    }

    // 检查是否已经在进行中
    const existingChallenges = wx.getStorageSync('waterChallenges') || [];
    const isAlreadyStarted = existingChallenges.find(c => c.id === challengeId && c.status === 'ongoing');
    
    if (isAlreadyStarted) {
      wx.showToast({
        title: '挑战已在进行中',
        icon: 'none'
      });
      return;
    }

    // 创建新挑战
    const newChallenge = {
      ...challenge,
      startTime: new Date().getTime(),
      status: 'ongoing',
      completedDays: 0,
      lastCheckDate: null
    };

    // 保存挑战
    existingChallenges.push(newChallenge);
    wx.setStorageSync('waterChallenges', existingChallenges);

    wx.showToast({
      title: '挑战已开始！',
      icon: 'success'
    });

    // 重新加载数据
    this.loadChallenges();
  },

  // 查看挑战详情
  viewChallengeDetail: function (e) {
    const challengeId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/challenge-detail/challenge-detail?id=${challengeId}`
    });
  },

  // 查看证书
  viewCertificate: function (e) {
    const challengeId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/challenge-certificate/challenge-certificate?id=${challengeId}`
    });
  },

  // 检查每日进度
  checkDailyProgress: function () {
    const challenges = wx.getStorageSync('waterChallenges') || [];
    const today = this.formatDate(new Date());
    const waterRecords = wx.getStorageSync('waterRecords') || {};
    const todayRecords = waterRecords[today] || [];
    const todayWater = todayRecords.reduce((sum, record) => sum + record.amount, 0);
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;

    let hasUpdates = false;

    challenges.forEach(challenge => {
      if (challenge.status === 'ongoing') {
        const lastCheckDate = challenge.lastCheckDate;
        
        // 如果今天还没检查过
        if (lastCheckDate !== today) {
          if (todayWater >= challenge.targetAmount) {
            // 完成今天的目标
            challenge.completedDays += 1;
            challenge.lastCheckDate = today;
            
            // 检查是否完成整个挑战
            if (challenge.completedDays >= challenge.totalDays) {
              challenge.status = 'completed';
              challenge.completionTime = new Date().getTime();
              
              // 显示完成提示
              wx.showToast({
                title: `恭喜完成${challenge.name}！`,
                icon: 'success',
                duration: 3000
              });
            }
            
            hasUpdates = true;
          } else {
            // 检查是否中断（连续挑战）
            if (challenge.type === 'continuous' && lastCheckDate && lastCheckDate !== today) {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              const yesterdayStr = this.formatDate(yesterday);
              
              if (lastCheckDate !== yesterdayStr) {
                // 中断了，挑战失败
                challenge.status = 'failed';
                challenge.failTime = new Date().getTime();
                hasUpdates = true;
              }
            }
            
            // 对于节日、纪念日和节气挑战，如果当天没完成就失败
            if ((challenge.type === 'festival' || challenge.type === 'memorial' || challenge.type === 'solar_term') && 
                challenge.date === today && todayWater < challenge.targetAmount) {
              challenge.status = 'failed';
              challenge.failTime = new Date().getTime();
              hasUpdates = true;
            }
          }
        }
      }
    });

    if (hasUpdates) {
      wx.setStorageSync('waterChallenges', challenges);
      this.loadChallenges();
    }
  },

  // 格式化日期
  formatDate: function (date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  // 分享功能
  onShareAppMessage: function () {
    return {
      title: '快喝水 - 喝水挑战',
      desc: '挑战自我，养成健康喝水习惯',
      path: '/pages/water-challenge/water-challenge'
    };
  },

  onShareTimeline: function () {
    return {
      title: '快喝水 - 喝水挑战',
      query: '',
      imageUrl: ''
    };
  }
}); 