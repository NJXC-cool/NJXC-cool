const { getCurrentTheme, themes, switchTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 页面数据
    tapCount: 0,
    lastTapTime: 0,
    developerMode: false
  },

  onLoad: function () {
    // 页面加载时的逻辑
    this.applyCurrentTheme();
  },

  onShow: function () {
    // 页面显示时的逻辑
    this.applyCurrentTheme();
  },

  // 跳转到成就页面
  goToAchievement: function () {
    wx.navigateTo({
      url: '/pages/achievement/achievement'
    });
  },

  // 跳转到健康知识问答
  goToQuiz: function () {
    wx.navigateTo({
      url: '/pages/games/quiz/quiz'
    });
  },

  // 跳转到喝水挑战
  goToDrop: function () {
    wx.navigateTo({
      url: '/pages/games/drop/drop'
    });
  },

  // 跳转到喝水记忆
  goToMemory: function () {
    wx.navigateTo({
      url: '/pages/games/memory/memory'
    });
  },

  // 跳转到公益寻人
  goToLostChild: function () {
    wx.navigateTo({
      url: '/pages/lost-child/lost-child'
    });
  },

  // 跳转到健康资讯（预留功能）
  goToHealthNews: function () {
    wx.showToast({
      title: '功能开发中',
      icon: 'none',
      duration: 2000
    });
  },

  // 关于信息点击处理
  onAboutTap: function () {
    var now = Date.now();
    var timeDiff = now - this.data.lastTapTime;
    
    // 如果距离上次点击超过3秒，重置计数
    if (timeDiff > 3000) {
      this.setData({
        tapCount: 1,
        lastTapTime: now
      });
    } else {
      // 连续点击
      var newCount = this.data.tapCount + 1;
      this.setData({
        tapCount: newCount,
        lastTapTime: now
      });
      
      // 连续点击7次触发开发者模式
      if (newCount >= 7) {
        this.activateDeveloperMode();
      }
    }
  },

  // 激活开发者模式
  activateDeveloperMode: function () {
    this.setData({
      developerMode: true,
      tapCount: 0
    });
    
    wx.showModal({
      title: '开发者模式',
      content: '开发者模式已激活！\n\n连续点击关于信息7次即可进入开发者模式。',
      showCancel: false,
      confirmText: '确定',
      success: function () {
        // 跳转到开发者页面
        wx.navigateTo({
          url: '/pages/developer/developer'
        });
      }
    });
  },

  // 应用当前主题
  applyCurrentTheme: function () {
    var theme = getCurrentTheme();
    this.setData({
      theme: theme,
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  // 处理客服消息
  handleContact: function (e) {
    console.log('客服消息回调:', e.detail);
    
    // 如果用户从客服会话返回，并且有指定的页面路径
    if (e.detail.path) {
      console.log('用户点击的消息页面路径:', e.detail.path);
      console.log('消息参数:', e.detail.query);
      
      // 可以根据 path 和 query 进行页面跳转
      // 例如：如果客服发送了特定页面的链接
      if (e.detail.path.startsWith('/pages/')) {
        wx.navigateTo({
          url: e.detail.path + (e.detail.query ? '?' + this.buildQueryString(e.detail.query) : ''),
          fail: function () {
            wx.showToast({
              title: '页面跳转失败',
              icon: 'none'
            });
          }
        });
      }
    }
  },

  // 构建查询字符串
  buildQueryString: function (query) {
    if (!query || typeof query !== 'object') return '';
    
    var params = [];
    for (var key in query) {
      if (query.hasOwnProperty(key)) {
        params.push(key + '=' + encodeURIComponent(query[key]));
      }
    }
    return params.join('&');
  }
}); 