Page({
  data: {
    tapCount: 0,
    lastTapTime: 0
  },

  onLoad() {
    this.applyCurrentTheme();
  },

  onShow() {
    this.applyCurrentTheme();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor};`
    });
  },

  // 成就系统
  goToAchievement() {
    wx.navigateTo({ url: '/pages/achievement/achievement' });
  },

  // 分享战报
  goToShareReport() {
    wx.navigateTo({ url: '/pages/share-report/share-report' });
  },

  // 喝水标签
  goToWaterTags() {
    wx.navigateTo({ url: '/pages/water-tags/water-tags' });
  },

  // 健康知识问答
  goToQuiz() {
    wx.navigateTo({ url: '/pages/games/quiz/quiz' });
  },

  // 接住水滴
  goToDrop() {
    wx.navigateTo({ url: '/pages/games/drop/drop' });
  },

  // 喝水挑战
  goToWaterChallenge() {
    wx.navigateTo({ url: '/pages/water-challenge/water-challenge' });
  },

  // 喝水记忆
  goToMemory() {
    wx.navigateTo({ url: '/pages/games/memory/memory' });
  },

  // 公益寻人
  goToLostChild() {
    wx.navigateTo({ url: '/pages/lost-child/lost-child' });
  },

  // 心愿墙
  goWishWall() {
    wx.navigateTo({ url: '/pages/wishwall/wishwall' });
  },

  // 开发者模式
  goToDeveloper() {
    wx.navigateTo({ url: '/pages/developer/developer' });
  },

  // 健康小贴士
  goToHealthTips() {
    wx.navigateTo({ url: '/pages/health-tips/health-tips' });
  },

  // 主题设置
  goToThemeDemo() {
    wx.navigateTo({ url: '/pages/theme-demo/theme-demo' });
  },

  // 公告中心
  goToAnnouncement() {
    wx.navigateTo({
      url: '/pages/announcement/announcement'
    });
  },

  // 健康新闻
  goToHealthNews() {
    wx.showToast({ title: '敬请期待', icon: 'none' });
  },

  // 关于点击处理
  onAboutTap() {
    const now = Date.now();
    const timeDiff = now - this.data.lastTapTime;
    if (timeDiff > 3000) {
      this.setData({ tapCount: 1, lastTapTime: now });
    } else {
      const newCount = this.data.tapCount + 1;
      this.setData({ tapCount: newCount, lastTapTime: now });
      if (newCount >= 7) {
        wx.showModal({
          title: '开发者模式',
          content: '是否进入开发者模式？',
          success: (res) => {
            if (res.confirm) {
              wx.navigateTo({ url: '/pages/developer/developer' });
            }
          }
        });
        this.setData({ tapCount: 0 });
      }
    }
  },

  // 客服联系
  handleContact(e: any) {
    console.log('用户联系客服', e);
  },

  // 打开官网
  openWebsite() {
    wx.showModal({
      title: '打开官网',
      content: '是否在浏览器中打开官网？',
      success: (res) => {
        if (res.confirm) {
          // 复制官网地址到剪贴板
          wx.setClipboardData({
            data: 'http://drink.njxc.xyz',
            success: () => {
              wx.showToast({
                title: '官网地址已复制',
                icon: 'success'
              });
            }
          });
        }
      }
    });
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: '发现更多有趣功能，快来体验快喝水小程序！',
      path: '/pages/more/more'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '发现更多有趣功能，快来体验快喝水小程序！',
      path: '/pages/more/more'
    }
  }
}); 