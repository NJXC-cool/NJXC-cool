const { getCurrentTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 页面样式
    pageStyle: '',
    
    // 用户信息
    userInfo: {
      nickName: '快喝水用户',
      avatarUrl: ''
    },
    
    // 今日数据
    todayDate: '',
    todayWater: 0,
    todayCount: 0,
    progressPercent: 0,
    
    // 连续记录
    streakDays: 0,
    
    // 历史统计
    totalWater: 0,
    joinDays: 0,
    avgDaily: 0,
    
    // 成就数据
    achievements: [],
    
    // 健康建议
    healthTip: '',
    
         // 分享预览
     showPreview: false,
     
     // 分享图片路径
     shareImagePath: '',
     
     // 是否为分享人的报告
     isSharedReport: false
  },

  onLoad: function (options) {
    console.log('分享报告页面参数:', options);
    this.applyCurrentTheme();
    
    // 检查是否有分享人的openid参数
    if (options.shareOpenid) {
      // 显示分享人的报告
      this.loadSharedUserData(options.shareOpenid);
      this.setData({ isSharedReport: true });
    } else {
      // 显示当前用户的报告
      this.loadUserData();
      this.syncAndLoadData();
      this.setData({ isSharedReport: false });
    }
  },

  onShow: function () {
    this.applyCurrentTheme();
  },

  // 应用当前主题
  applyCurrentTheme: function() {
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 加载用户数据
  loadUserData: function() {
    const userInfo = wx.getStorageSync('userInfo') || {};
    const userData = wx.getStorageSync('userData') || {};
    
    this.setData({
      userInfo: {
        nickName: userInfo.nickName || userData.nickname || '快喝水用户',
        avatarUrl: userInfo.avatarUrl || userData.avatarUrl || ''
      },
      todayDate: this.formatDate(new Date())
    });
  },

  // 加载分享人的用户数据
  loadSharedUserData: function(shareOpenid) {
    console.log('加载分享人的用户数据，openid:', shareOpenid);
    wx.showLoading({ title: '加载中...' });

    // 从云端获取分享人的数据
    wx.cloud.callFunction({
      name: 'dataSync',
      data: {
        action: 'getUserDataByOpenid',
        userOpenid: shareOpenid
      },
      success: (res) => {
        if (res.result && res.result.success) {
          const cloudData = res.result.data;
          
          // 设置用户信息
          const userProfile = cloudData.userProfile || {};
          this.setData({
            userInfo: {
              nickName: userProfile.nickname || userProfile.nickName || '分享用户',
              avatarUrl: userProfile.avatarUrl || ''
            },
            todayDate: this.formatDate(new Date())
          });
          
          // 临时保存分享人的数据到本地存储
          if (cloudData.waterRecords) {
            wx.setStorageSync('tempWaterRecords', cloudData.waterRecords);
          }
          if (cloudData.userProfile) {
            wx.setStorageSync('tempUserData', cloudData.userProfile);
          }
          
          // 计算战报数据
          this.calculateSharedReportData(cloudData);
          this.generateHealthTip();
          wx.hideLoading();
        } else {
          wx.hideLoading();
          wx.showToast({
            title: '加载分享数据失败',
            icon: 'none'
          });
          console.error('加载分享数据失败:', res.result.message);
        }
      },
      fail: (err) => {
        wx.hideLoading();
        wx.showToast({
          title: '加载分享数据失败',
          icon: 'none'
        });
        console.error('加载分享数据失败:', err);
      }
    });
  },

  // 计算分享人的战报数据
  calculateSharedReportData: function(cloudData) {
    const waterRecords = cloudData.waterRecords || {};
    const dailyTarget = 2000; // 默认目标
    const achievements = cloudData.userBadges || [];
    
    // 将waterRecords对象转换为数组格式
    let allRecords = [];
    if (typeof waterRecords === 'object' && waterRecords !== null) {
      // 如果是对象格式（按日期分组），转换为数组
      Object.keys(waterRecords).forEach(date => {
        const dayRecords = waterRecords[date];
        if (Array.isArray(dayRecords)) {
          allRecords = allRecords.concat(dayRecords);
        }
      });
    } else if (Array.isArray(waterRecords)) {
      // 如果已经是数组格式，直接使用
      allRecords = waterRecords;
    }
    
    // 确保records是数组
    const records = Array.isArray(allRecords) ? allRecords : [];
    
    // 计算今日数据
    const today = new Date().toDateString();
    const todayRecords = records.filter(record => 
      record && record.timestamp && new Date(record.timestamp).toDateString() === today
    );
    const todayWater = todayRecords.reduce((sum, record) => sum + (record.amount || 0), 0);
    const todayCount = todayRecords.length;
    const progressPercent = Math.min(Math.round((todayWater / dailyTarget) * 100), 100);
    
    // 计算连续天数
    const streakDays = this.calculateStreakDays(records, dailyTarget);
    
    // 计算历史统计
    const totalWater = records.reduce((sum, record) => sum + (record.amount || 0), 0);
    const joinDays = this.calculateJoinDays(records);
    const avgDaily = joinDays > 0 ? Math.round(totalWater / joinDays) : 0;
    
    // 获取成就数据
    const userAchievements = this.getUserAchievements(achievements);
    
    this.setData({
      todayWater,
      todayCount,
      progressPercent,
      streakDays,
      totalWater,
      joinDays,
      avgDaily,
      achievements: userAchievements
    });
  },

  // 同步并加载数据
  syncAndLoadData: function() {
    wx.showLoading({ title: '同步数据中...' });
    
    // 尝试从云端同步数据
    this.syncDataFromCloud().then(() => {
      // 同步成功后计算战报数据
      this.calculateReportData();
      this.generateHealthTip();
      wx.hideLoading();
    }).catch((err) => {
      console.log('数据同步失败，使用本地数据:', err);
      // 同步失败时使用本地数据
      this.calculateReportData();
      this.generateHealthTip();
      wx.hideLoading();
    });
  },

  // 从云端同步数据
  syncDataFromCloud: function() {
    return new Promise((resolve, reject) => {
      const openid = wx.getStorageSync('openid');
      if (!openid) {
        reject('没有openid');
        return;
      }

      // 获取云端数据
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'getUserData',
          userOpenid: openid
        },
        success: (res) => {
          if (res.result && res.result.success) {
            const cloudData = res.result.data;
            
            // 合并云端数据到本地
            if (cloudData.waterRecords) {
              const localRecords = wx.getStorageSync('waterRecords') || {};
              const mergedRecords = { ...localRecords, ...cloudData.waterRecords };
              wx.setStorageSync('waterRecords', mergedRecords);
            }
            
            if (cloudData.userData) {
              const localUserData = wx.getStorageSync('userData') || {};
              const mergedUserData = { ...localUserData, ...cloudData.userData };
              wx.setStorageSync('userData', mergedUserData);
            }
            
            resolve();
          } else {
            reject(res.result.message || '获取云端数据失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 计算战报数据
  calculateReportData: function() {
    const waterRecords = wx.getStorageSync('waterRecords') || {};
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
    const achievements = wx.getStorageSync('achievements') || [];
    
    // 将waterRecords对象转换为数组格式
    let allRecords = [];
    if (typeof waterRecords === 'object' && waterRecords !== null) {
      // 如果是对象格式（按日期分组），转换为数组
      Object.keys(waterRecords).forEach(date => {
        const dayRecords = waterRecords[date];
        if (Array.isArray(dayRecords)) {
          allRecords = allRecords.concat(dayRecords);
        }
      });
    } else if (Array.isArray(waterRecords)) {
      // 如果已经是数组格式，直接使用
      allRecords = waterRecords;
    }
    
    // 确保records是数组
    const records = Array.isArray(allRecords) ? allRecords : [];
    
    // 计算今日数据
    const today = new Date().toDateString();
    const todayRecords = records.filter(record => 
      record && record.timestamp && new Date(record.timestamp).toDateString() === today
    );
    const todayWater = todayRecords.reduce((sum, record) => sum + (record.amount || 0), 0);
    const todayCount = todayRecords.length;
    const progressPercent = Math.min(Math.round((todayWater / dailyTarget) * 100), 100);
    
    // 计算连续天数
    const streakDays = this.calculateStreakDays(records, dailyTarget);
    
    // 计算历史统计
    const totalWater = records.reduce((sum, record) => sum + (record.amount || 0), 0);
    const joinDays = this.calculateJoinDays(records);
    const avgDaily = joinDays > 0 ? Math.round(totalWater / joinDays) : 0;
    
    // 获取成就数据
    const userAchievements = this.getUserAchievements(achievements);
    
    this.setData({
      todayWater,
      todayCount,
      progressPercent,
      streakDays,
      totalWater,
      joinDays,
      avgDaily,
      achievements: userAchievements
    });
  },

  // 计算连续天数
  calculateStreakDays: function(records, target) {
    if (!Array.isArray(records) || records.length === 0) {
      return 0;
    }
    
    const dates = {};
    records.forEach(record => {
      if (record && record.timestamp) {
        const date = new Date(record.timestamp).toDateString();
        dates[date] = (dates[date] || 0) + (record.amount || 0);
      }
    });

    let streak = 0;
    let currentDate = new Date();
    
    while (streak < 365) {
      const dateStr = currentDate.toDateString();
      if (dates[dateStr] && dates[dateStr] >= target) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    return streak;
  },

  // 计算加入天数
  calculateJoinDays: function(records) {
    if (!Array.isArray(records) || records.length === 0) return 0;
    
    const firstRecord = records.find(record => record && record.timestamp);
    if (!firstRecord) return 0;
    
    const firstDate = new Date(firstRecord.timestamp);
    const today = new Date();
    const diffTime = Math.abs(today - firstDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return Math.max(diffDays, 1);
  },

  // 获取用户成就
  getUserAchievements: function(allAchievements) {
    const userAchievements = [];
    
    // 模拟一些成就数据
    if (this.data.streakDays >= 7) {
      userAchievements.push({
        id: 'streak_7',
        name: '坚持一周',
        emoji: '🔥'
      });
    }
    
    if (this.data.streakDays >= 30) {
      userAchievements.push({
        id: 'streak_30',
        name: '坚持一月',
        emoji: '💪'
      });
    }
    
    if (this.data.totalWater >= 100000) {
      userAchievements.push({
        id: 'water_100k',
        name: '饮水达人',
        emoji: '💧'
      });
    }
    
    if (this.data.progressPercent >= 100) {
      userAchievements.push({
        id: 'target_complete',
        name: '目标达成',
        emoji: '🎯'
      });
    }
    
    return userAchievements;
  },

  // 生成健康建议
  generateHealthTip: function() {
    const tips = [
      '记得每小时喝一次水，保持身体水分充足！',
      '起床后先喝一杯温水，帮助身体唤醒！',
      '运动前后要适量补充水分，但不要过量！',
      '睡前1小时停止大量饮水，避免影响睡眠！',
      '多吃水果蔬菜，它们也含有丰富的水分！',
      '保持规律的喝水习惯，让健康成为生活方式！',
      '今天的目标完成得很好，继续保持！',
      '连续达标很不容易，你真的很棒！'
    ];
    
    const randomTip = tips[Math.floor(Math.random() * tips.length)];
    this.setData({ healthTip: randomTip });
  },

  // 格式化日期
  formatDate: function(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}年${month}月${day}日`;
  },

  // 分享给好友
  shareToFriend: function() {
    console.log('点击分享给好友');
    // 生成战报图片用于分享
    this.generateShareImageForSharing();
  },

  // 保存到相册
  saveToAlbum: function() {
    console.log('点击保存到相册');
    // 如果已经有生成的图片，直接保存
    if (this.data.shareImagePath) {
      this.saveImageToAlbum(this.data.shareImagePath);
    } else {
      // 否则先生成图片再保存
      this.generateShareImage(true);
    }
  },

  // 手动同步数据
  manualSync: function() {
    wx.showLoading({ title: '同步数据中...' });
    
    this.syncDataFromCloud().then(() => {
      // 重新计算战报数据
      this.calculateReportData();
      this.generateHealthTip();
      wx.hideLoading();
      wx.showToast({
        title: '数据同步成功',
        icon: 'success'
      });
    }).catch((err) => {
      wx.hideLoading();
      wx.showToast({
        title: '同步失败，请重试',
        icon: 'none'
      });
      console.error('手动同步失败:', err);
    });
  },

  // 生成分享图片用于分享
  generateShareImageForSharing: function() {
    console.log('开始生成分享图片');
    wx.showLoading({ title: '生成战报中...' });
    
    try {
      // 使用微信小程序标准Canvas API
      const ctx = wx.createCanvasContext('shareCanvas', this);
      
      // 设置画布尺寸（增大尺寸提高清晰度）
      const canvasWidth = 600;
      const canvasHeight = 800;
      
      console.log('Canvas尺寸:', canvasWidth, 'x', canvasHeight);
      
      // 绘制分享图片
      this.drawShareImage(ctx, canvasWidth, canvasHeight);
      
      // 绘制完成后导出图片
      ctx.draw(true, () => {
        console.log('Canvas绘制完成，开始导出图片');
        
        // 增加延迟时间，确保绘制完全完成
        setTimeout(() => {
          wx.canvasToTempFilePath({
            canvasId: 'shareCanvas',
            width: canvasWidth,
            height: canvasHeight,
            destWidth: canvasWidth * 2, // 提高分辨率
            destHeight: canvasHeight * 2,
            fileType: 'png',
            quality: 1,
            success: (res) => {
              console.log('分享图片生成成功:', res.tempFilePath);
              wx.hideLoading();
              
              // 保存生成的图片路径用于分享
              this.setData({
                shareImagePath: res.tempFilePath
              });
              
              // 显示分享预览
              this.showSharePreview(res.tempFilePath);
            },
            fail: (err) => {
              console.error('生成分享图片失败:', err);
              wx.hideLoading();
              
              // 尝试使用备用方法
              this.tryAlternativeImageGeneration();
            }
          }, this);
        }, 500); // 增加延迟时间到500ms，确保绘制完成
      });
    } catch (error) {
      console.error('Canvas创建失败:', error);
      wx.hideLoading();
      
      // 尝试使用备用方法
      this.tryAlternativeImageGeneration();
    }
  },

  // 备用图片生成方法
  tryAlternativeImageGeneration: function() {
    console.log('尝试备用图片生成方法');
    
    // 使用静态图片作为备用
    const fallbackImage = '/images/share/report-share.png';
    
    this.setData({
      shareImagePath: fallbackImage
    });
    
    // 显示分享预览
    this.showSharePreview(fallbackImage);
    
    wx.showToast({
      title: '使用备用图片',
      icon: 'none',
      duration: 2000
    });
  },

  // 生成分享图片
  generateShareImage: function(saveToAlbum = false) {
    console.log('开始生成分享图片, saveToAlbum:', saveToAlbum);
    wx.showLoading({ title: '生成图片中...' });
    
    try {
      // 使用微信小程序标准Canvas API
      const ctx = wx.createCanvasContext('shareCanvas', this);
      
      // 设置画布尺寸（增大尺寸提高清晰度）
      const canvasWidth = 600;
      const canvasHeight = 800;
      
      console.log('Canvas尺寸:', canvasWidth, 'x', canvasHeight);
      
      // 绘制分享图片
      this.drawShareImage(ctx, canvasWidth, canvasHeight);
      
      // 绘制完成后导出图片
      ctx.draw(true, () => {
        console.log('Canvas绘制完成，开始导出图片');
        
        // 增加延迟时间，确保绘制完全完成
        setTimeout(() => {
          wx.canvasToTempFilePath({
            canvasId: 'shareCanvas',
            width: canvasWidth,
            height: canvasHeight,
            destWidth: canvasWidth * 2, // 提高分辨率
            destHeight: canvasHeight * 2,
            fileType: 'png',
            quality: 1,
            success: (res) => {
              console.log('图片生成成功:', res.tempFilePath);
              wx.hideLoading();
              
              if (saveToAlbum) {
                this.saveImageToAlbum(res.tempFilePath);
              } else {
                this.showSharePreview(res.tempFilePath);
              }
            },
            fail: (err) => {
              console.error('生成图片失败:', err);
              wx.hideLoading();
              
              let errorMsg = '生成图片失败';
              if (err.errMsg) {
                if (err.errMsg.includes('canvas')) {
                  errorMsg = 'Canvas绘制失败，请重试';
                } else if (err.errMsg.includes('fail')) {
                  errorMsg = '图片生成失败，请重试';
                }
              }
              
              wx.showToast({
                title: errorMsg,
                icon: 'none',
                duration: 3000
              });
            }
          }, this);
        }, 500); // 增加延迟时间到500ms，确保绘制完成
      });
    } catch (error) {
      console.error('Canvas创建失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: 'Canvas创建失败',
        icon: 'none',
        duration: 3000
      });
    }
  },

  // 绘制分享图片
  drawShareImage: function(ctx, width, height) {
    console.log('开始绘制分享图片:', width, 'x', height);
    console.log('用户数据:', this.data.userInfo);
    console.log('战报数据:', {
      todayWater: this.data.todayWater,
      progressPercent: this.data.progressPercent,
      todayCount: this.data.todayCount,
      streakDays: this.data.streakDays,
      totalWater: this.data.totalWater,
      joinDays: this.data.joinDays,
      avgDaily: this.data.avgDaily,
      healthTip: this.data.healthTip
    });
    
    // 清空画布
    ctx.clearRect(0, 0, width, height);
    
    // 背景
    ctx.setFillStyle('#ffffff');
    ctx.fillRect(0, 0, width, height);
    
    // 顶部背景
    ctx.setFillStyle('#4CAF50');
    ctx.fillRect(0, 0, width, 160);
    
    // 标题
    ctx.setFillStyle('#ffffff');
    ctx.setFontSize(28);
    ctx.setTextAlign('center');
    ctx.fillText('💧 喝水战报', width / 2, 50);
    
    ctx.setFontSize(18);
    // 处理用户名过长的情况
    let nickName = this.data.userInfo.nickName || '快喝水用户';
    if (nickName.length > 10) {
      nickName = nickName.substring(0, 10) + '...';
    }
    ctx.fillText(nickName, width / 2, 90);
    ctx.fillText(this.data.todayDate, width / 2, 120);
    
    // 今日数据
    ctx.setFillStyle('#333333');
    ctx.setFontSize(22);
    ctx.setTextAlign('left');
    ctx.fillText('📅 今日战绩', 30, 200);
    
    // 数据网格 - 调整间距避免超出
    const stats = [
      { label: '饮水', value: `${this.data.todayWater || 0}ml` },
      { label: '完成', value: `${this.data.progressPercent || 0}%` },
      { label: '次数', value: `${this.data.todayCount || 0}次` }
    ];
    
    const itemWidth = (width - 60) / 3; // 减去左右边距，平均分配
    stats.forEach((stat, index) => {
      const x = 30 + (index * itemWidth);
      const y = 240;
      
      ctx.setFillStyle('#4CAF50');
      ctx.setFontSize(24);
      ctx.setTextAlign('center');
      ctx.fillText(stat.value, x + itemWidth/2, y);
      
      ctx.setFillStyle('#666666');
      ctx.setFontSize(14);
      ctx.fillText(stat.label, x + itemWidth/2, y + 25);
    });
    
    // 连续记录
    ctx.setFillStyle('#333333');
    ctx.setFontSize(22);
    ctx.setTextAlign('left');
    ctx.fillText('🔥 连续记录', 30, 300);
    
    ctx.setFillStyle('#FF6B35');
    ctx.setFontSize(36);
    ctx.setTextAlign('center');
    ctx.fillText((this.data.streakDays || 0).toString(), width / 2, 350);
    
    ctx.setFillStyle('#666666');
    ctx.setFontSize(18);
    ctx.fillText('天连续达标', width / 2, 380);
    
    // 历史统计
    ctx.setFillStyle('#333333');
    ctx.setFontSize(22);
    ctx.setTextAlign('left');
    ctx.fillText('📈 历史统计', 30, 440);
    
    const historyStats = [
      { label: '总饮水量', value: `${this.data.totalWater || 0}ml` },
      { label: '加入天数', value: `${this.data.joinDays || 0}天` },
      { label: '平均每日', value: `${this.data.avgDaily || 0}ml` }
    ];
    
    historyStats.forEach((stat, index) => {
      const y = 480 + (index * 36);
      
      ctx.setFillStyle('#666666');
      ctx.setFontSize(18);
      ctx.setTextAlign('left');
      ctx.fillText(stat.label, 30, y);
      
      ctx.setFillStyle('#333333');
      ctx.setFontSize(18);
      ctx.setTextAlign('right');
      // 处理数值过长的情况
      let value = stat.value;
      if (value.length > 12) {
        value = value.substring(0, 12) + '...';
      }
      ctx.fillText(value, width - 30, y);
    });
    
    // 健康建议
    ctx.setFillStyle('#333333');
    ctx.setFontSize(22);
    ctx.setTextAlign('left');
    ctx.fillText('💡 健康建议', 30, 600);
    
    ctx.setFillStyle('#666666');
    ctx.setFontSize(14);
    // 处理长文本换行
    const tip = this.data.healthTip || '记得多喝水，保持健康！';
    const maxWidth = width - 60;
    const maxLines = 3; // 最多显示3行
    const lineHeight = 25;
    let y = 640;
    let lineCount = 0;
    
    // 简单的文本换行处理
    const words = tip.split('');
    let line = '';
    
    for (let i = 0; i < words.length && lineCount < maxLines; i++) {
      const testLine = line + words[i];
      if (testLine.length * 10 > maxWidth) { // 调整字符宽度估算
        if (line) {
          ctx.fillText(line, 30, y);
          y += lineHeight;
          lineCount++;
        }
        line = words[i];
      } else {
        line = testLine;
      }
    }
    
    // 绘制最后一行
    if (line && lineCount < maxLines) {
      ctx.fillText(line, 30, y);
    }
    
    // 底部信息
    ctx.setFillStyle('#999999');
    ctx.setFontSize(10);
    ctx.setTextAlign('center');
    ctx.fillText('快喝水 - 让健康成为习惯', width / 2, height - 25);
    
    // 官网信息
    ctx.setFillStyle('#4CAF50');
    ctx.setFontSize(12);
    ctx.fillText('官网：drink.njxc.xyz', width / 2, height - 10);
    
    console.log('分享图片绘制完成');
  },

  // 显示分享预览
  showSharePreview: function(imagePath) {
    this.setData({
      showPreview: true,
      previewImage: imagePath
    });
  },

  // 隐藏分享预览
  hidePreview: function() {
    this.setData({ showPreview: false });
  },

  // 保存图片到相册
  saveImageToAlbum: function(imagePath) {
    console.log('开始保存图片:', imagePath);
    
    // 检查图片路径是否有效
    if (!imagePath) {
      wx.showToast({
        title: '图片生成失败',
        icon: 'none'
      });
      return;
    }

    // 直接尝试保存，让微信自动处理权限
    this.doSaveImage(imagePath);
  },

  // 检查权限并保存
  checkPermissionAndSave: function(imagePath) {
    wx.getSetting({
      success: (res) => {
        console.log('权限检查结果:', res.authSetting);
        
        if (res.authSetting['scope.writePhotosAlbum'] === false) {
          // 用户之前拒绝了权限
          wx.showModal({
            title: '需要相册权限',
            content: '保存图片需要相册权限，请在设置中开启',
            confirmText: '去设置',
            cancelText: '取消',
            success: (modalRes) => {
              if (modalRes.confirm) {
                wx.openSetting({
                  success: (settingRes) => {
                    if (settingRes.authSetting['scope.writePhotosAlbum']) {
                      this.doSaveImage(imagePath);
                    }
                  }
                });
              }
            }
          });
        } else if (res.authSetting['scope.writePhotosAlbum'] === true) {
          // 已有权限，直接保存
          this.doSaveImage(imagePath);
        } else {
          // 首次使用，申请权限
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => {
              console.log('权限申请成功');
              this.doSaveImage(imagePath);
            },
            fail: (authErr) => {
              console.error('权限申请失败:', authErr);
              wx.showModal({
                title: '权限被拒绝',
                content: '需要相册权限才能保存图片，请在设置中手动开启',
                confirmText: '去设置',
                cancelText: '取消',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    wx.openSetting();
                  }
                }
              });
            }
          });
        }
      },
      fail: (err) => {
        console.error('权限检查失败:', err);
        // 权限检查失败，直接尝试保存
        this.doSaveImage(imagePath);
      }
    });
  },

  // 执行保存图片
  doSaveImage: function(imagePath) {
    console.log('执行保存图片:', imagePath);
    
    // 检查图片路径
    if (!imagePath) {
      wx.showToast({
        title: '图片路径无效',
        icon: 'none'
      });
      return;
    }
    
    wx.saveImageToPhotosAlbum({
      filePath: imagePath,
      success: (res) => {
        console.log('保存成功:', res);
        wx.showToast({
          title: '保存成功',
          icon: 'success',
          duration: 2000
        });
      },
      fail: (err) => {
        console.error('保存图片失败:', err);
        
        // 根据错误类型给出不同提示
        let errorMsg = '保存失败';
        if (err.errMsg) {
          if (err.errMsg.includes('auth deny') || err.errMsg.includes('permission')) {
            errorMsg = '需要相册权限，请在设置中开启';
            // 引导用户去设置
            wx.showModal({
              title: '需要权限',
              content: '保存图片需要相册权限，请在设置中开启',
              confirmText: '去设置',
              cancelText: '取消',
              success: (modalRes) => {
                if (modalRes.confirm) {
                  wx.openSetting();
                }
              }
            });
            return;
          } else if (err.errMsg.includes('fail')) {
            errorMsg = '保存失败，请重试';
          } else if (err.errMsg.includes('file not exist')) {
            errorMsg = '图片文件不存在，请重新生成';
          }
        }
        
        wx.showToast({
          title: errorMsg,
          icon: 'none',
          duration: 3000
        });
      }
    });
  },

  // 返回我的战报
  goBack: function() {
    // 清除临时数据
    wx.removeStorageSync('tempWaterRecords');
    wx.removeStorageSync('tempUserData');
    
    // 重新加载当前用户的数据
    this.setData({ isSharedReport: false });
    this.loadUserData();
    this.syncAndLoadData();
  },

  // 分享到微信好友
  onShareAppMessage: function () {
    console.log('触发分享给好友');
    const currentOpenid = wx.getStorageSync('openid');
    return {
      title: `${this.data.userInfo.nickName || '快喝水用户'}的喝水战报 - 今日饮水${this.data.todayWater}ml`,
      path: `/pages/share-report/share-report?shareOpenid=${currentOpenid}`,
      imageUrl: this.data.shareImagePath || '/images/share/report-share.png',
      success: function(res) {
        console.log('分享成功:', res);
        wx.showToast({
          title: '分享成功',
          icon: 'success'
        });
      },
      fail: function(err) {
        console.error('分享失败:', err);
        wx.showToast({
          title: '分享失败',
          icon: 'none'
        });
      }
    };
  },

  // 分享到朋友圈
  onShareTimeline: function () {
    console.log('触发分享到朋友圈');
    const currentOpenid = wx.getStorageSync('openid');
    return {
      title: `${this.data.userInfo.nickName || '快喝水用户'}的喝水战报 - 连续${this.data.streakDays}天达标！`,
      path: `/pages/share-report/share-report?shareOpenid=${currentOpenid}`,
      imageUrl: this.data.shareImagePath || '/images/share/report-timeline.png',
      success: function(res) {
        console.log('分享到朋友圈成功:', res);
        wx.showToast({
          title: '分享成功',
          icon: 'success'
        });
      },
      fail: function(err) {
        console.error('分享到朋友圈失败:', err);
        wx.showToast({
          title: '分享失败',
          icon: 'none'
        });
      }
    };
  }
}); 