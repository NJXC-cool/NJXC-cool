import { apiService, type LostPerson } from '../../utils/api';

Page({
  data: {
    childInfo: {} as LostPerson,
    loading: true
  },

  onLoad(options: any) {
    const id = options.id;
    if (id) {
      this.loadChildDetail(id);
    }
  },

  // 加载儿童详情
  async loadChildDetail(id: string) {
    try {
      const response = await apiService.getLostPersonDetail(id);
      
      if (response.success && response.data) {
        this.setData({
          childInfo: response.data,
          loading: false
        });
      } else {
        wx.showToast({
          title: response.message || '未找到相关信息',
          icon: 'none'
        });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }

    } catch (error) {
      console.error('加载详情失败:', error);
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },

  // 预览图片
  previewImage(e: any) {
    const url = e.currentTarget.dataset.url;
    wx.previewImage({
      current: url,
      urls: this.data.childInfo.photos
    });
  },

  // 拨打电话
  callPhone() {
    const phone = this.data.childInfo.contactPhone;
    wx.showModal({
      title: '拨打电话',
      content: `是否拨打 ${phone}？`,
      success: (res) => {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: phone,
            fail: () => {
              wx.showToast({
                title: '拨打失败',
                icon: 'none'
              });
            }
          });
        }
      }
    });
  },

  // 分享信息
  shareInfo() {
    wx.showActionSheet({
      itemList: ['分享给朋友', '分享到朋友圈', '复制链接'],
      success: (res) => {
        switch (res.tapIndex) {
          case 0:
            this.shareToFriend();
            break;
          case 1:
            this.shareToMoments();
            break;
          case 2:
            this.copyLink();
            break;
        }
      }
    });
  },

  // 分享给朋友
  shareToFriend() {
    wx.showToast({
      title: '请点击右上角分享',
      icon: 'none'
    });
  },

  // 分享到朋友圈
  shareToMoments() {
    wx.showToast({
      title: '请点击右上角分享到朋友圈',
      icon: 'none'
    });
  },

  // 复制链接
  copyLink() {
    const link = `pages/child-detail/child-detail?id=${this.data.childInfo.id}`;
    wx.setClipboardData({
      data: link,
      success: () => {
        wx.showToast({
          title: '链接已复制',
          icon: 'success'
        });
      }
    });
  },

  // 分享
  onShareAppMessage() {
    const { childInfo } = this.data;
    return {
      title: `寻找走失儿童：${childInfo.name}，${childInfo.age}岁`,
      path: `/pages/child-detail/child-detail?id=${childInfo.id}`,
      imageUrl: childInfo.photos && childInfo.photos.length > 0 ? childInfo.photos[0] : ''
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    const { childInfo } = this.data;
    return {
      title: `寻找走失儿童：${childInfo.name}，${childInfo.age}岁`,
      imageUrl: childInfo.photos && childInfo.photos.length > 0 ? childInfo.photos[0] : ''
    };
  }
}); 