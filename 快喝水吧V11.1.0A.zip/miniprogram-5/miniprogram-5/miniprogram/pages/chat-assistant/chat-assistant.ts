// pages/chat-assistant/chat-assistant.ts
Page({
  data: {
    mode: 'text', // text 或 call
    messages: [] as any[],
    inputValue: '',
    callStatus: '你可以开始说话',
    isRecording: false
  },

  onLoad() {
    this.initChat();
    this.applyCurrentTheme();
  },

  onShow() {
    this.applyCurrentTheme();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: '快喝水 - 水宝助手',
      desc: '来和可爱的水宝聊天吧！',
      path: '/pages/chat-assistant/chat-assistant'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '快喝水 - 水宝助手',
      query: '',
      imageUrl: ''
    };
  },

  // 初始化聊天
  initChat() {
    const welcomeMsg = {
      id: Date.now(),
      role: 'assistant',
      content: '你好！我是水宝💧，你的专属喝水助手！有什么想和我聊的吗？'
    };
    this.setData({
      messages: [welcomeMsg]
    });
    this.drawAvatar(welcomeMsg);
    
    // 延迟初始化文字模式表情，确保canvas已准备好
    setTimeout(() => {
      this.drawTextModeFace('normal');
    }, 100);
  },

  // 切换模式
  switchMode(e: any) {
    const mode = e.currentTarget.dataset.mode;
    this.setData({ mode });
    
    if (mode === 'call') {
      this.drawCallFace('normal');
    } else if (mode === 'text') {
      this.drawTextModeFace('normal');
    }
  },

  // 输入框变化
  onInput(e: any) {
    this.setData({
      inputValue: e.detail.value
    });
  },

  // 发送消息
  sendMsg() {
    const content = this.data.inputValue.trim();
    if (!content) return;

    const userMsg = {
      id: Date.now(),
      role: 'user',
      content
    };

    this.setData({
      messages: [...this.data.messages, userMsg],
      inputValue: ''
    });

    this.sendToAI(content);
  },

  // 发送到AI
  sendToAI(content: string) {
    console.log('开始发送到AI:', content);
    
    if (this.data.mode === 'call') {
      this.setData({ callStatus: '水宝正在思考...' });
      this.animateExpression('thinking');
    } else if (this.data.mode === 'text') {
      this.animateTextModeExpression('thinking');
    }

    // 获取API密钥
    const apiKey = wx.getStorageSync('deepseek_api_key');
    console.log('API密钥状态:', apiKey ? '已配置' : '未配置');
    
    if (!apiKey) {
      wx.showToast({
        title: '请先配置API密钥',
        icon: 'none'
      });
      return;
    }

    // 检查网络状态
    wx.getNetworkType({
      success: (res) => {
        console.log('网络类型:', res.networkType);
        if (res.networkType === 'none') {
          wx.showToast({
            title: '网络连接失败',
            icon: 'none'
          });
          return;
        }
        this.makeAIRequest(content, apiKey);
      },
      fail: () => {
        console.log('网络检查失败，继续尝试请求');
        this.makeAIRequest(content, apiKey);
      }
    });
  },

  // 发起AI请求
  makeAIRequest(content: string, apiKey: string) {
    console.log('发起AI请求...');
    
    wx.request({
      url: 'https://api.deepseek.com/chat/completions',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      data: {
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: '你是一个可爱的喝水助手"水宝"，性格活泼、关心用户健康。请用简短、温暖、可爱的语气回复，鼓励用户多喝水。'
          },
          {
            role: 'user',
            content: content
          }
        ],
        max_tokens: 200,
        temperature: 0.7,
        stream: false
      },
      success: (res: any) => {
        console.log('AI请求成功:', res.statusCode, res.data);
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message && res.data.choices[0].message.content) {
          const aiContent = res.data.choices[0].message.content;
          console.log('AI回复内容:', aiContent);
          
          const assistantMsg = {
            id: Date.now(),
            role: 'assistant',
            content: aiContent
          };

          this.setData({
            messages: [...this.data.messages, assistantMsg]
          });

          this.drawAvatar(assistantMsg);
          
          if (this.data.mode === 'call') {
            const mood = this.analyzeMood(aiContent);
            console.log('分析出的心情:', mood);
            this.animateExpression(mood);
            this.setData({ callStatus: '你可以开始说话' });
          } else if (this.data.mode === 'text') {
            const mood = this.analyzeMood(aiContent);
            console.log('分析出的心情:', mood);
            this.animateTextModeExpression(mood);
          }
        } else {
          console.error('AI回复格式错误:', res);
          wx.showToast({
            title: 'AI回复异常',
            icon: 'none'
          });
          
          if (this.data.mode === 'call') {
            this.setData({ callStatus: '你可以开始说话' });
          }
        }
      },
      fail: (err: any) => {
        console.error('AI请求失败:', err);
        
        let errorMsg = '网络请求失败';
        if (err.errMsg) {
          if (err.errMsg.includes('timeout')) {
            errorMsg = '请求超时，请重试';
          } else if (err.errMsg.includes('fail')) {
            errorMsg = '网络连接失败';
          }
        }
        
        wx.showToast({
          title: errorMsg,
          icon: 'none'
        });
        
        if (this.data.mode === 'call') {
          this.setData({ callStatus: '你可以开始说话' });
        }
      }
    });
  },

  // 情感分析 - 更丰富的情感识别
  analyzeMood(text: string) {
    // 开心类表情
    if (/开心|高兴|棒|赞|好|可爱|喜欢|哈哈|😊|😄|😍|🥰|太棒|优秀|完美|棒棒|赞赞|好棒|太可爱|喜欢|爱|❤️|💕|💖|💗|💓|💝|😘|😗|😙|😚|🤗|🤩|🥳|😎|🤠|😇|🤗|🤭|🤫|🤔|🤨|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😺|😸|😹|😻|😼|😽|🙀|😿|😾/.test(text)) return 'happy';
    
    // 思考类表情
    if (/疑问|思考|为什么|怎么|什么|🤔|❓|？|嗯|唔|哦|啊|咦|奇怪|疑惑|不懂|不明白|不知道|不清楚|🤨|🤔|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|🤔|🤨|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲/.test(text)) return 'thinking';
    
    // 难过类表情
    if (/抱歉|难过|不开心|对不起|抱歉|😢|😭|😔|伤心|痛苦|难受|不舒服|不好|糟糕|😞|😟|😠|😡|🤬|🤯|😳|🥵|🥶|😱|😨|😰|😥|😓|🤗|🤔|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😿|😾/.test(text)) return 'sad';
    
    // 惊讶类表情
    if (/惊讶|哇|天哪|😱|😲|😯|哇塞|厉害|太厉害了|太强了|太棒了|太厉害了|太强了|太棒了|😱|😨|😰|😥|😓|🤗|🤔|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😺|😸|😹|😻|😼|😽|🙀|😿|😾/.test(text)) return 'surprised';
    
    // 生气类表情
    if (/生气|愤怒|讨厌|烦|😠|😡|🤬|🤯|😳|🥵|🥶|😱|😨|😰|😥|😓|🤗|🤔|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😾/.test(text)) return 'angry';
    
    // 害羞类表情
    if (/害羞|脸红|不好意思|😊|😳|🥵|🥶|😱|😨|😰|😥|😓|🤗|🤔|🤭|🤫|🤐|🤥|😶|😐|😑|😯|😦|😧|😮|😲|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😺|😸|😹|😻|😼|😽|🙀|😿|😾/.test(text)) return 'shy';
    
    // 困倦类表情
    if (/困|累|疲惫|想睡|😴|🤤|😪|😵|🤐|🥴|🤢|🤮|🤧|😷|🤒|🤕|🤑|🤠|💩|🤡|👹|👺|👻|👽|👾|🤖|😈|👿|👹|👺|💀|☠️|👻|👽|👾|🤖|😺|😸|😹|😻|😼|😽|🙀|😿|😾/.test(text)) return 'sleepy';
    
    // 默认普通表情
    return 'normal';
  },

  // 画头像
  drawAvatar(msg: any) {
    if (msg.role !== 'assistant') return;
    
    const query = wx.createSelectorQuery();
    query.select(`#avatar-${msg.id}`).fields({ node: true, size: true }).exec((res) => {
      if (res[0]) {
        try {
          const canvas = res[0].node;
          const ctx = canvas.getContext('2d');
          const dpr = wx.getSystemInfoSync().pixelRatio;
          canvas.width = 64 * dpr;
          canvas.height = 64 * dpr;
          ctx.scale(dpr, dpr);
          
          const mood = this.analyzeMood(msg.content);
          this.drawFace(ctx, mood, 64);
        } catch (error) {
          console.error('绘制头像失败:', error);
        }
      } else {
        console.log('未找到头像Canvas元素');
      }
    });
  },

  // 画通话表情
  drawCallFace(mood: string) {
    const query = wx.createSelectorQuery();
    query.select('#call-face').fields({ node: true, size: true }).exec((res) => {
      if (res[0]) {
        try {
          const canvas = res[0].node;
          const ctx = canvas.getContext('2d');
          const dpr = wx.getSystemInfoSync().pixelRatio;
          canvas.width = 240 * dpr;
          canvas.height = 240 * dpr;
          ctx.scale(dpr, dpr);
          
          this.drawFace(ctx, mood, 240);
        } catch (error) {
          console.error('绘制通话表情失败:', error);
        }
      } else {
        console.log('未找到通话表情Canvas元素');
      }
    });
  },

  // 画文字模式表情 - 显示表情但不显示圆框
  drawTextModeFace(mood: string) {
    // 文字模式下显示表情，但不显示圆框背景
    console.log('文字模式心情变化:', mood);
    
    // 创建一个隐藏的canvas来绘制表情
    const query = wx.createSelectorQuery();
    query.select('#text-mode-face').fields({ node: true, size: true }).exec((res) => {
      if (res[0]) {
        try {
          const canvas = res[0].node;
          const ctx = canvas.getContext('2d');
          const dpr = wx.getSystemInfoSync().pixelRatio;
          canvas.width = 120 * dpr;
          canvas.height = 120 * dpr;
          ctx.scale(dpr, dpr);
          
          // 绘制表情但不绘制黑色背景
          this.drawFaceWithoutBackground(ctx, mood, 120);
        } catch (error) {
          console.error('绘制文字模式表情失败:', error);
        }
      } else {
        console.log('未找到文字模式表情Canvas元素');
      }
    });
  },

  // 绘制表情但不绘制背景
  drawFaceWithoutBackground(ctx: any, mood: string, size: number) {
    try {
      const centerX = size / 2;
      const centerY = size / 2;
      
      // 清空画布
      ctx.clearRect(0, 0, size, size);
      
      // 不设置黑色背景，直接绘制白色形状
      ctx.fillStyle = '#FFFFFF';
      
      // 绘制眼睛：两个垂直白条
      const eyeWidth = size * 0.08;
      const eyeHeight = size * 0.3;
      const eyeY = centerY - size * 0.15;
      
      // 左眼
      ctx.fillRect(centerX - size * 0.2 - eyeWidth / 2, eyeY, eyeWidth, eyeHeight);
      
      // 右眼
      ctx.fillRect(centerX + size * 0.2 - eyeWidth / 2, eyeY, eyeWidth, eyeHeight);
      
             // 根据心情绘制嘴巴
       if (mood === 'happy') {
         this.drawHappyMouth(ctx, centerX, centerY, size);
       } else if (mood === 'thinking') {
         this.drawThinkingMouth(ctx, centerX, centerY, size);
       } else if (mood === 'sad') {
         this.drawSadMouth(ctx, centerX, centerY, size);
       } else if (mood === 'surprised') {
         this.drawSurprisedMouth(ctx, centerX, centerY, size);
       } else if (mood === 'angry') {
         this.drawAngryMouth(ctx, centerX, centerY, size);
       } else if (mood === 'shy') {
         this.drawShyMouth(ctx, centerX, centerY, size);
       } else if (mood === 'sleepy') {
         this.drawSleepyMouth(ctx, centerX, centerY, size);
       } else {
         this.drawNormalMouth(ctx, centerX, centerY, size);
       }
    } catch (error) {
      console.error('绘制表情失败:', error);
    }
  },

  // 画表情 - 严格按照设计图（黑背景，白形状）
  drawFace(ctx: any, mood: string, size: number) {
    try {
      const centerX = size / 2;
      const centerY = size / 2;
      
      // 清空画布
      ctx.clearRect(0, 0, size, size);
      
      // 设置黑背景
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, size, size);
      
      // 设置白色形状
      ctx.fillStyle = '#FFFFFF';
      
      // 绘制眼睛：两个垂直白条（严格按照设计图）
      const eyeWidth = size * 0.08;
      const eyeHeight = size * 0.3;
      const eyeY = centerY - size * 0.15;
      
      // 左眼
      ctx.fillRect(centerX - size * 0.2 - eyeWidth / 2, eyeY, eyeWidth, eyeHeight);
      
      // 右眼
      ctx.fillRect(centerX + size * 0.2 - eyeWidth / 2, eyeY, eyeWidth, eyeHeight);
      
             // 根据心情绘制嘴巴
       if (mood === 'happy') {
         // 开心：向上V ^
         this.drawHappyMouth(ctx, centerX, centerY, size);
       } else if (mood === 'thinking') {
         // 思考：小圆点 ·
         this.drawThinkingMouth(ctx, centerX, centerY, size);
       } else if (mood === 'sad') {
         // 难过：向下V V
         this.drawSadMouth(ctx, centerX, centerY, size);
       } else if (mood === 'surprised') {
         // 惊讶：小圆圈 O
         this.drawSurprisedMouth(ctx, centerX, centerY, size);
       } else if (mood === 'angry') {
         // 生气：倒V ∧
         this.drawAngryMouth(ctx, centerX, centerY, size);
       } else if (mood === 'shy') {
         // 害羞：小弧线
         this.drawShyMouth(ctx, centerX, centerY, size);
       } else if (mood === 'sleepy') {
         // 困倦：波浪线
         this.drawSleepyMouth(ctx, centerX, centerY, size);
       } else {
         // 普通：水平条 -
         this.drawNormalMouth(ctx, centerX, centerY, size);
       }
    } catch (error) {
      console.error('绘制表情失败:', error);
    }
  },

  // 绘制开心的嘴巴：向上V ^
  drawHappyMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.25;
    const mouthY = centerY + size * 0.2;
    
    ctx.beginPath();
    ctx.moveTo(centerX - mouthWidth / 2, mouthY + mouthWidth / 2);
    ctx.lineTo(centerX, mouthY);
    ctx.lineTo(centerX + mouthWidth / 2, mouthY + mouthWidth / 2);
    ctx.closePath();
    ctx.fill();
  },

  // 绘制思考的嘴巴：小圆点 ·
  drawThinkingMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthSize = size * 0.05;
    const mouthY = centerY + size * 0.25;
    
    ctx.beginPath();
    ctx.arc(centerX, mouthY, mouthSize, 0, 2 * Math.PI);
    ctx.fill();
  },

  // 绘制难过的嘴巴：向下V V (严格按照设计图)
  drawSadMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.25;
    const mouthY = centerY + size * 0.15;
    
    ctx.beginPath();
    ctx.moveTo(centerX - mouthWidth / 2, mouthY);
    ctx.lineTo(centerX, mouthY + mouthWidth / 2);
    ctx.lineTo(centerX + mouthWidth / 2, mouthY);
    ctx.closePath();
    ctx.fill();
  },

  // 绘制惊讶的嘴巴：小圆圈 O
  drawSurprisedMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthSize = size * 0.15;
    const mouthY = centerY + size * 0.25;
    
    ctx.beginPath();
    ctx.arc(centerX, mouthY, mouthSize, 0, 2 * Math.PI);
    ctx.fill();
  },

  // 绘制普通的嘴巴：水平条 -
  drawNormalMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.3;
    const mouthHeight = size * 0.06;
    const mouthY = centerY + size * 0.25;
    
    ctx.fillRect(centerX - mouthWidth / 2, mouthY - mouthHeight / 2, mouthWidth, mouthHeight);
  },

  // 绘制生气的嘴巴：倒V ∧
  drawAngryMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.25;
    const mouthY = centerY + size * 0.2;
    
    ctx.beginPath();
    ctx.moveTo(centerX - mouthWidth / 2, mouthY);
    ctx.lineTo(centerX, mouthY + mouthWidth / 2);
    ctx.lineTo(centerX + mouthWidth / 2, mouthY);
    ctx.closePath();
    ctx.fill();
  },

  // 绘制害羞的嘴巴：小弧线
  drawShyMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.2;
    const mouthY = centerY + size * 0.25;
    
    ctx.beginPath();
    ctx.arc(centerX, mouthY, mouthWidth / 2, 0, Math.PI, false);
    ctx.stroke();
  },

  // 绘制困倦的嘴巴：波浪线
  drawSleepyMouth(ctx: any, centerX: number, centerY: number, size: number) {
    const mouthWidth = size * 0.3;
    const mouthY = centerY + size * 0.25;
    
    ctx.beginPath();
    ctx.moveTo(centerX - mouthWidth / 2, mouthY);
    ctx.quadraticCurveTo(centerX - mouthWidth / 4, mouthY - size * 0.05, centerX, mouthY);
    ctx.quadraticCurveTo(centerX + mouthWidth / 4, mouthY + size * 0.05, centerX + mouthWidth / 2, mouthY);
    ctx.stroke();
  },

  // 动态表情变化效果 - 更生动的动画
  animateExpression(mood: string) {
    const moods = ['thinking', 'normal', mood];
    let index = 0;
    
    const animate = () => {
      if (index < moods.length) {
        this.drawCallFace(moods[index]);
        index++;
        setTimeout(animate, 600); // 更快的动画速度
      } else {
        this.drawCallFace(mood);
        // 添加最终表情的微动画
        setTimeout(() => {
          this.drawCallFace('normal');
          setTimeout(() => {
            this.drawCallFace(mood);
          }, 200);
        }, 300);
      }
    };
    
    animate();
  },

  // 文字模式动态表情变化效果 - 更生动的动画
  animateTextModeExpression(mood: string) {
    const moods = ['thinking', 'normal', mood];
    let index = 0;
    
    const animate = () => {
      if (index < moods.length) {
        this.drawTextModeFace(moods[index]);
        index++;
        setTimeout(animate, 600); // 更快的动画速度
      } else {
        this.drawTextModeFace(mood);
        // 添加最终表情的微动画
        setTimeout(() => {
          this.drawTextModeFace('normal');
          setTimeout(() => {
            this.drawTextModeFace(mood);
          }, 200);
        }, 300);
      }
    };
    
    animate();
  },

  // 开始录音 - 增强版
  startRecord() {
    if (this.data.isRecording) return;
    
    this.setData({ 
      isRecording: true, 
      callStatus: '正在聆听...' 
    });
    
    // 录音时表情动画
    this.animateRecordingFace();
    
    const recorderManager = wx.getRecorderManager();
    recorderManager.start({
      duration: 10000,
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 48000,
      format: 'mp3'
    });
  },

  // 停止录音 - 增强版
  stopRecord() {
    if (!this.data.isRecording) return;
    
    this.setData({ 
      isRecording: false, 
      callStatus: '正在识别语音...' 
    });
    
    // 停止录音动画
    this.drawCallFace('thinking');
    
    const recorderManager = wx.getRecorderManager();
    recorderManager.stop();
  },

  // 录音时的表情动画
  animateRecordingFace() {
    let count = 0;
    const animate = () => {
      if (this.data.isRecording) {
        if (count % 2 === 0) {
          this.drawCallFace('surprised');
        } else {
          this.drawCallFace('normal');
        }
        count++;
        setTimeout(animate, 500);
      }
    };
    animate();
  },

  // 录音结束 - 增强版
  onRecordEnd(e: any) {
    console.log('录音结束:', e);
    
    if (e.duration < 1000) {
      this.setData({ callStatus: '说话时间太短了，请重试' });
      this.drawCallFace('sad');
      setTimeout(() => {
        this.setData({ callStatus: '你可以开始说话' });
        this.drawCallFace('normal');
      }, 2000);
      return;
    }
    
    this.setData({ callStatus: '正在处理语音...' });
    this.drawCallFace('thinking');
    this.callTencentSpeechAPI(e.tempFilePath);
  },

  // 调用腾讯语音识别 - 增强版
  callTencentSpeechAPI(filePath: string) {
    wx.cloud.callFunction({
      name: 'speechRecognition',
      data: {
        filePath: filePath
      },
      success: (res: any) => {
        console.log('语音识别结果:', res);
        if (res.result && res.result.success) {
          const text = res.result.text;
          this.setData({ callStatus: `识别到: "${text}"` });
          this.drawCallFace('happy');
          setTimeout(() => {
            this.sendToAI(text);
          }, 1000);
        } else {
          this.setData({ callStatus: '识别失败，请重试' });
          this.drawCallFace('sad');
          setTimeout(() => {
            this.setData({ callStatus: '你可以开始说话' });
            this.drawCallFace('normal');
          }, 2000);
        }
      },
      fail: (err: any) => {
        console.error('语音识别失败:', err);
        this.setData({ callStatus: '网络错误，请重试' });
        this.drawCallFace('sad');
        setTimeout(() => {
          this.setData({ callStatus: '你可以开始说话' });
          this.drawCallFace('normal');
        }, 2000);
      }
    });
  },

  // 挂断电话 - 增强版
  hangupCall() {
    this.setData({ 
      mode: 'text',
      callStatus: '通话结束'
    });
    
    // 挂断时的表情动画
    this.drawCallFace('sad');
    setTimeout(() => {
      this.drawTextModeFace('normal');
    }, 500);
  },

  onReady() {
    // 监听录音结束事件
    const recorderManager = wx.getRecorderManager();
    recorderManager.onStop(this.onRecordEnd);
    
    // 确保表情正确显示
    setTimeout(() => {
      if (this.data.mode === 'text') {
        this.drawTextModeFace('normal');
      } else if (this.data.mode === 'call') {
        this.drawCallFace('normal');
      }
    }, 200);
  }
}); 