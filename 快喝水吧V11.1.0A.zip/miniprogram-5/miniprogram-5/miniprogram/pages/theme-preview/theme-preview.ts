import { themes, getCurrentTheme } from '../../utils/theme'

Page({
  data: {
    themes: themes,
    selectedTheme: 'default',
    pageStyle: ''
  },

  onLoad() {
    const currentTheme = getCurrentTheme();
    this.setData({
      selectedTheme: currentTheme.name,
      pageStyle: `background: ${currentTheme.backgroundColor};`
    });
  },

  onThemeSelect(e: any) {
    const themeName = e.currentTarget.dataset.theme;
    const theme = themes.find(t => t.name === themeName);
    if (theme) {
      this.setData({
        selectedTheme: themeName,
        pageStyle: `background: ${theme.backgroundColor};`
      });
    }
  },

  onCancel() {
    wx.navigateBack();
  },

  onConfirm() {
    const themeIndex = themes.findIndex(t => t.name === this.data.selectedTheme);
    if (themeIndex >= 0) {
      wx.setStorageSync('themeIndex', themeIndex);
      wx.showToast({
        title: '主题已应用',
        icon: 'success'
      });
      
      // 返回上一页并刷新
      const pages = getCurrentPages();
      if (pages.length > 1) {
        const prevPage = pages[pages.length - 2];
        if (prevPage && prevPage.applyCurrentTheme) {
          prevPage.applyCurrentTheme();
        }
      }
      
      wx.navigateBack();
    }
  }
}) 