Page({
  data: {
    tips: [
      '每天早晨起床后先喝一杯温水，有助于激活身体代谢。',
      '饮水要少量多次，避免一次性大量饮水。',
      '运动后及时补充水分，避免脱水。',
      '天气炎热时适当增加饮水量。',
      '饮水时避免喝过烫的水，保护口腔和食道。',
      '不要等口渴了才喝水，养成主动饮水习惯。',
      '睡前适量饮水，避免夜间口渴，但不要过量。',
      '多喝白开水，少喝含糖饮料。',
      '饮水有助于保持皮肤健康和身体排毒。',
      '饮水量可根据体重、运动量、气候等调整。',
      '饮水时保持心情愉悦，有助于身体吸收。',
      '定期更换水杯，保持饮水器具清洁。',
      '饮水时注意水温，温水最容易被身体吸收。',
      '饮水有助于缓解疲劳，提高工作效率。',
      '适量饮水有助于控制体重，促进新陈代谢。'
    ],
    healthNews: [
      {
        id: 1,
        title: '最新研究：科学饮水可预防多种疾病',
        summary: '哈佛大学最新研究表明，保持充足的水分摄入可以有效预防心血管疾病和肾脏疾病。',
        image: '/images/health-news-1.jpg',
        date: '2025-01-15',
        source: '健康时报'
      },
      {
        id: 2,
        title: '冬季饮水指南：如何科学补水',
        summary: '冬季虽然出汗少，但身体仍需要充足的水分。专家建议冬季每天至少饮水1.5升。',
        image: '/images/health-news-2.jpg',
        date: '2025-01-14',
        source: '医学前沿'
      },
      {
        id: 3,
        title: '运动饮水新发现：电解质补充的重要性',
        summary: '运动时不仅要补充水分，还要注意电解质的平衡，这对运动表现至关重要。',
        image: '/images/health-news-3.jpg',
        date: '2025-01-13',
        source: '运动医学'
      }
    ],
    personalAdvice: '根据您最近的喝水记录，建议您：1. 增加早晨的饮水量；2. 在运动前后及时补充水分；3. 保持规律的饮水习惯。'
  },

  onLoad() {
    this.applyCurrentTheme();
    this.generatePersonalAdvice();
  },

  onShow() {
    this.applyCurrentTheme();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 生成个性化建议
  generatePersonalAdvice() {
    try {
      const waterRecords = wx.getStorageSync('waterRecords') || [];
      const today = new Date().toDateString();
      const todayRecords = waterRecords.filter((record: any) => 
        new Date(record.timestamp).toDateString() === today
      );
      
      let advice = '根据您最近的喝水记录，建议您：';
      
      if (todayRecords.length === 0) {
        advice += '1. 开始记录您的饮水情况；2. 设定每日饮水目标；3. 养成定时喝水的习惯。';
      } else {
        const totalAmount = todayRecords.reduce((sum: number, record: any) => sum + (record.amount || 0), 0);
        
        if (totalAmount < 1500) {
          advice += '1. 增加饮水量，建议达到1.5-2升；2. 设置喝水提醒；3. 在办公桌上放水杯。';
        } else if (totalAmount > 3000) {
          advice += '1. 注意不要过量饮水；2. 分散饮水时间；3. 关注身体反应。';
        } else {
          advice += '1. 继续保持良好的饮水习惯；2. 注意饮水时间分布；3. 运动时适当增加饮水量。';
        }
      }
      
      this.setData({ personalAdvice: advice });
    } catch (error) {
      console.error('生成个性化建议失败:', error);
    }
  },

  // 刷新贴士
  onRefresh() {
    const tips = this.data.tips.slice().sort(() => Math.random() - 0.5);
    this.setData({ tips });
    wx.showToast({
      title: '已更新',
      icon: 'success',
      duration: 1000
    });
  },

  // 点击贴士
  onTipTap(e: any) {
    const { index } = e.currentTarget.dataset;
    const tip = this.data.tips[index];
    
    wx.showModal({
      title: '健康小贴士',
      content: tip,
      showCancel: false,
      confirmText: '知道了'
    });
  },

  // 点击新闻
  onNewsTap(e: any) {
    const { news } = e.currentTarget.dataset;
    
    wx.showModal({
      title: news.title,
      content: news.summary,
      showCancel: false,
      confirmText: '阅读更多',
      success: (res) => {
        if (res.confirm) {
          // 这里可以跳转到新闻详情页或外部链接
          wx.showToast({
            title: '功能开发中',
            icon: 'none'
          });
        }
      }
    });
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: '健康小贴士，科学喝水更健康！',
      path: '/pages/health-tips/health-tips'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '健康小贴士，科学喝水更健康！',
      path: '/pages/health-tips/health-tips'
    }
  }
}); 