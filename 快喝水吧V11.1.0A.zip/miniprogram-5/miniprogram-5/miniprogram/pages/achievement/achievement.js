Page({
  data: {
    achievements: [
      { id: 1, name: '第一杯水', desc: '成功记录第一杯水', unlocked: false },
      { id: 2, name: '坚持一周', desc: '连续打卡7天', unlocked: false },
      { id: 3, name: '健康达人', desc: '累计喝水10000ml', unlocked: false },
      { id: 4, name: '早起喝水', desc: '早晨7点前喝水', unlocked: false },
      { id: 5, name: '夜间补水', desc: '晚上10点后喝水', unlocked: false }
    ]
  },
  onLoad() {
    this.loadAchievements();
  },
  onShow() {
    this.loadAchievements();
  },
  loadAchievements() {
    const userData = wx.getStorageSync('userData') || {};
    let early = false, night = false;
    
    // 检查早起/夜间成就
    if (userData.checkTimes && userData.checkTimes.length > 0) {
      for (let dateStr of userData.checkTimes) {
        // 这里可以根据实际打卡时间数据结构调整
        // 假设 checkTimes 存储的是日期字符串，需要转换为时间判断
        const today = new Date();
        const hour = today.getHours();
        if (hour < 7) early = true;
        if (hour >= 22) night = true;
      }
    }
    
    const achievements = [
      { id: 1, name: '第一杯水', desc: '成功记录第一杯水', unlocked: userData.totalVolume >= 200 },
      { id: 2, name: '坚持一周', desc: '连续打卡7天', unlocked: userData.days >= 7 },
      { id: 3, name: '健康达人', desc: '累计喝水10000ml', unlocked: userData.totalVolume >= 10000 },
      { id: 4, name: '早起喝水', desc: '早晨7点前喝水', unlocked: early },
      { id: 5, name: '夜间补水', desc: '晚上10点后喝水', unlocked: night }
    ];
    this.setData({ achievements });
  }
}); 