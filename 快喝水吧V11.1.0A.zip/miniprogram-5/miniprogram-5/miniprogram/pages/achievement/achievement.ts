Page({
  data: {
    achievements: [
      { id: 1, name: '第一杯水', desc: '成功记录第一杯水', unlocked: true },
      { id: 2, name: '坚持一周', desc: '连续打卡7天', unlocked: false },
      { id: 3, name: '健康达人', desc: '累计喝水10000ml', unlocked: false },
      { id: 4, name: '早起喝水', desc: '早晨7点前喝水', unlocked: true },
      { id: 5, name: '夜间补水', desc: '晚上10点后喝水', unlocked: false }
    ]
  },
  onShareAppMessage() {
    return {
      title: '解锁喝水成就，快来挑战健康新高度！',
      path: '/pages/achievement/achievement'
    }
  },
  onShareTimeline() {
    return {
      title: '解锁喝水成就，快来挑战健康新高度！',
      path: '/pages/achievement/achievement'
    }
  }
}); 