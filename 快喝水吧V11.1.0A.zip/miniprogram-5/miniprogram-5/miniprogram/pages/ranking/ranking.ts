Page({
  data: {
    myOpenid: '',
    ranking: [
      { openid: 'user1', nickname: '小明', days: 12 },
      { openid: 'user2', nickname: '小红', days: 10 },
      { openid: 'user3', nickname: '小刚', days: 8 },
      { openid: 'user4', nickname: '小美', days: 7 },
      { openid: 'user5', nickname: '小宇', days: 5 }
    ]
  },
  onLoad() {
    // 获取本地 openid
    const myOpenid = wx.getStorageSync('openid') || '';
    this.setData({ myOpenid });
  },
  onRefresh() {
    // 模拟刷新，洗牌
    const ranking = this.data.ranking.slice().sort(() => Math.random() - 0.5);
    this.setData({ ranking });
  },
  onShareAppMessage() {
    return {
      title: '喝水排行榜，看看谁是健康达人！',
      path: '/pages/ranking/ranking'
    }
  },
  onShareTimeline() {
    return {
      title: '喝水排行榜，看看谁是健康达人！',
      path: '/pages/ranking/ranking'
    }
  }
}); 