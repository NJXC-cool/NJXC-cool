const { getCurrentTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 证书数据
    challenge: {},
    userInfo: {},
    completionDate: '',
    certificateId: '',
    issueDate: '',
    defaultAvatarUrl: '/images/default-avatar.svg',
    
    // 主题
    pageStyle: '',
    
    // 证书样式
    certificateStyle: 'classic', // classic, modern, elegant, festive
    certificateStyles: [
      { id: 'classic', name: '经典', icon: '🏆' },
      { id: 'modern', name: '现代', icon: '✨' },
      { id: 'elegant', name: '优雅', icon: '💎' },
      { id: 'festive', name: '节日', icon: '🎉' }
    ],
    
    // 状态
    isLoading: false,
    hasError: false,
    errorMessage: ''
  },

  onLoad: function (options) {
    this.applyCurrentTheme();
    this.loadCertificateData(options.id);
  },

  onShow: function () {
    this.applyCurrentTheme();
  },

  applyCurrentTheme: function () {
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  // 加载证书数据
  loadCertificateData: function (challengeId) {
    const challenges = wx.getStorageSync('waterChallenges') || [];
    const challenge = challenges.find(c => c.id === challengeId);
    
    if (!challenge) {
      wx.showToast({
        title: '挑战数据飞走了',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }

    const userInfo = wx.getStorageSync('userInfo') || {};
    
    // 修复日期处理逻辑
    let completionDate;
    if (challenge.completionTime) {
      // 如果有完成时间，使用完成时间
      completionDate = this.formatDate(new Date(challenge.completionTime));
    } else if (challenge.date) {
      // 如果是24节气等有固定日期的挑战，使用挑战日期
      completionDate = this.formatDate(new Date(challenge.date));
    } else {
      // 都没有的话，使用当前时间
      completionDate = this.formatDate(new Date());
    }
    
    const certificateId = this.generateCertificateId(challenge);
    const issueDate = this.formatDate(new Date());

    this.setData({
      challenge,
      userInfo,
      completionDate,
      certificateId,
      issueDate
    });
  },

  // 生成证书编号
  generateCertificateId: function (challenge) {
    let timestamp;
    if (challenge.completionTime) {
      timestamp = challenge.completionTime;
    } else if (challenge.date) {
      timestamp = new Date(challenge.date).getTime();
    } else {
      timestamp = Date.now();
    }
    const random = Math.floor(Math.random() * 1000);
    return `CERT-${timestamp}-${random}`;
  },

  // 格式化日期
  formatDate: function (date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}年${month}月${day}日 ❤`;
  },

  // 分享证书
  shareCertificate: function () {
    wx.showToast({
      title: '生成分享图片中...',
      icon: 'none',
      duration: 1000
    });
    // 生成分享图片
    this.generateCertificateImageForShare();
  },

  // 保存证书到相册
  saveCertificate: function () {
    wx.showModal({
      title: '保存证书',
      content: '是否要保存证书到相册？',
      success: (res) => {
        if (res.confirm) {
          this.generateCertificateImage();
        }
      }
    });
  },

  // 备用方案：上传到图床
  uploadToImageHost: function (filePath) {
    wx.showLoading({
      title: '上传图片中...',
      mask: true
    });

    // 使用Chevereto API上传图片
    wx.uploadFile({
      url: 'https://www.picgo.net/api/1/upload',
      filePath: filePath,
      name: 'source',
      header: {
        'X-API-Key': 'chv_Sw4tY_6ce56f40008efd79e4640bc73cf7f20f86946b36c1e2bb7a14e50af81259a5ab1d114ec3d4a264d3dfeb788c6ae0e03a6fea3046971657bcfe517b6da28659c0'
      },
      success: (res) => {
        wx.hideLoading();
        console.log('原始响应:', res);
        
        try {
          const data = JSON.parse(res.data);
          console.log('解析后的响应数据:', data);
          
          // 根据PicGo API文档检查响应格式
          let imageUrl = null;
          
          if (data.status_code === 200 && data.image && data.image.url) {
            // 标准PicGo API响应格式
            imageUrl = data.image.url;
          } else if (data.status_code === 200 && data.data && data.data.url) {
            // 备用格式
            imageUrl = data.data.url;
          } else if (data.success && data.image && data.image.url) {
            // 另一种可能的格式
            imageUrl = data.image.url;
          } else if (data.url) {
            // 直接返回URL的格式
            imageUrl = data.url;
          }
          
          if (imageUrl) {
            wx.showModal({
              title: '上传成功',
              content: `图片已上传到图床，链接：${imageUrl}`,
              confirmText: '复制链接',
              cancelText: '关闭',
              success: (modalRes) => {
                if (modalRes.confirm) {
                  wx.setClipboardData({
                    data: imageUrl,
                    success: () => {
                      wx.showToast({
                        title: '链接已复制',
                        icon: 'success'
                      });
                    }
                  });
                }
              }
            });
          } else {
            console.error('未找到图片链接，完整响应:', data);
            wx.showModal({
              title: '上传失败',
              content: `服务器响应格式异常，请检查日志。状态码: ${data.status_code || '未知'}`,
              showCancel: false
            });
          }
        } catch (e) {
          console.error('解析响应失败:', e, '原始数据:', res.data);
          wx.showModal({
            title: '上传失败',
            content: '服务器响应格式错误，请重试',
            showCancel: false
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('上传失败:', err);
        wx.showModal({
          title: '上传失败',
          content: `网络错误: ${err.errMsg || '未知错误'}`,
          showCancel: false
        });
      }
    });
  },

  // 修改保存函数，添加备用方案
  saveImageToAlbum: function () {
    wx.canvasToTempFilePath({
      canvasId: 'certificateCanvas',
      success: (res) => {
        // 更新加载提示
        wx.showLoading({
          title: '保存中...',
          mask: true
        });

        // 先检查权限
        wx.getSetting({
          success: (settingRes) => {
            if (settingRes.authSetting['scope.writePhotosAlbum'] === false) {
              // 用户之前拒绝了权限，引导用户去设置页面
              wx.hideLoading();
              wx.showModal({
                title: '需要相册权限',
                content: '保存证书需要相册权限，请在设置中开启',
                confirmText: '去设置',
                cancelText: '取消',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    wx.openSetting({
                      success: (openSettingRes) => {
                        if (openSettingRes.authSetting['scope.writePhotosAlbum']) {
                          // 用户在设置页面开启了权限，重新尝试保存
                          this.saveImageToAlbum();
                        }
                      }
                    });
                  } else {
                    // 用户取消，提供图床上传选项
                    this.uploadToImageHost(res.tempFilePath);
                  }
                }
              });
            } else {
              // 尝试保存到相册
              wx.saveImageToPhotosAlbum({
                filePath: res.tempFilePath,
                success: () => {
                  wx.hideLoading();
                  wx.showToast({
                    title: '证书已保存到相册',
                    icon: 'success',
                    duration: 2000
                  });
                  this.setData({
                    shareImagePath: res.tempFilePath
                  });
                },
                fail: (err) => {
                  wx.hideLoading();
                  console.error('保存失败:', err);
                  
                  // 检查是否是权限问题
                  if (err.errMsg && (err.errMsg.includes('auth deny') || err.errMsg.includes('permission'))) {
                    wx.showModal({
                      title: '权限被拒绝',
                      content: '相册权限被拒绝，是否尝试上传到图床？',
                      confirmText: '上传图床',
                      cancelText: '取消',
                      success: (modalRes) => {
                        if (modalRes.confirm) {
                          this.uploadToImageHost(res.tempFilePath);
                        }
                      }
                    });
                  } else {
                    // 其他错误，提供备用方案
                    wx.showModal({
                      title: '保存失败',
                      content: '无法保存到相册，是否尝试上传到图床？',
                      confirmText: '上传图床',
                      cancelText: '取消',
                      success: (modalRes) => {
                        if (modalRes.confirm) {
                          this.uploadToImageHost(res.tempFilePath);
                        }
                      }
                    });
                  }
                }
              });
            }
          },
          fail: () => {
            // 获取设置失败，直接尝试保存
            wx.saveImageToPhotosAlbum({
              filePath: res.tempFilePath,
              success: () => {
                wx.hideLoading();
                wx.showToast({
                  title: '证书已保存到相册',
                  icon: 'success',
                  duration: 2000
                });
                this.setData({
                  shareImagePath: res.tempFilePath
                });
              },
              fail: (err) => {
                wx.hideLoading();
                console.error('保存失败:', err);
                this.uploadToImageHost(res.tempFilePath);
              }
            });
          }
        });
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('生成图片失败:', err);
        wx.showToast({
          title: '生成证书失败',
          icon: 'none'
        });
      }
    });
  },

    // 生成证书图片
  generateCertificateImage: function () {
    // 显示加载提示
    wx.showLoading({
      title: '生成证书中...',
      mask: true
    });

    const ctx = wx.createCanvasContext('certificateCanvas');
    const canvasWidth = 600;
    const canvasHeight = 800;
    const style = this.data.certificateStyle;
    
    try {
      // 根据样式设置背景和颜色
      this.setCanvasStyle(ctx, style, canvasWidth, canvasHeight);
      
      // 绘制边框
      this.drawBorder(ctx, style, canvasWidth, canvasHeight);
      
      // 绘制标题
      this.drawTitle(ctx, style, canvasWidth);
      
      // 绘制用户信息
      this.drawUserInfo(ctx, style, canvasWidth);
      
      // 绘制挑战信息
      this.drawChallengeInfo(ctx, style, canvasWidth);
      
      // 绘制完成信息
      this.drawCompletionInfo(ctx, style, canvasWidth);
      
      // 绘制奖励信息
      this.drawRewardInfo(ctx, style, canvasWidth);
      
      // 绘制证书编号
      this.drawCertificateId(ctx, style, canvasWidth);
      
      // 绘制签名区域
      this.drawSignature(ctx, style, canvasWidth);
      
      // 绘制完成
      ctx.draw(false, () => {
        setTimeout(() => {
          this.saveImageToAlbum();
        }, 800); // 增加延迟确保绘制完成
      });
    } catch (error) {
      console.error('生成证书图片错误:', error);
      wx.hideLoading();
      wx.showToast({
        title: '生成证书失败',
        icon: 'none'
      });
    }
  },

  // 生成证书图片用于分享
  generateCertificateImageForShare: function () {
    // 显示加载提示
    wx.showLoading({
      title: '生成分享图片中...',
      mask: true
    });

    const ctx = wx.createCanvasContext('certificateCanvas');
    const canvasWidth = 600;
    const canvasHeight = 800;
    const style = this.data.certificateStyle;
    
    try {
      // 根据样式设置背景和颜色
      this.setCanvasStyle(ctx, style, canvasWidth, canvasHeight);
      
      // 绘制边框
      this.drawBorder(ctx, style, canvasWidth, canvasHeight);
      
      // 绘制标题
      this.drawTitle(ctx, style, canvasWidth);
      
      // 绘制用户信息
      this.drawUserInfo(ctx, style, canvasWidth);
      
      // 绘制挑战信息
      this.drawChallengeInfo(ctx, style, canvasWidth);
      
      // 绘制完成信息
      this.drawCompletionInfo(ctx, style, canvasWidth);
      
      // 绘制奖励信息
      this.drawRewardInfo(ctx, style, canvasWidth);
      
      // 绘制证书编号
      this.drawCertificateId(ctx, style, canvasWidth);
      
      // 绘制签名区域
      this.drawSignature(ctx, style, canvasWidth);
      
      // 绘制完成
      ctx.draw(false, () => {
        setTimeout(() => {
          this.generateImageForPreview();
        }, 800); // 增加延迟确保绘制完成
      });
    } catch (error) {
      console.error('生成证书图片错误:', error);
      wx.hideLoading();
      wx.showToast({
        title: '生成证书失败',
        icon: 'none'
      });
    }
  },

  // 设置画布样式
  setCanvasStyle: function (ctx, style, width, height) {
    switch (style) {
      case 'modern':
        // 现代风格 - 渐变背景
        const gradient = ctx.createLinearGradient(0, 0, width, height);
        gradient.addColorStop(0, '#667eea');
        gradient.addColorStop(1, '#764ba2');
        ctx.setFillStyle(gradient);
        ctx.fillRect(0, 0, width, height);
        break;
      case 'elegant':
        // 优雅风格 - 深色背景
        ctx.setFillStyle('#2c3e50');
        ctx.fillRect(0, 0, width, height);
        break;
      case 'festive':
        // 节日风格 - 彩色渐变
        const festiveGradient = ctx.createLinearGradient(0, 0, width, height);
        festiveGradient.addColorStop(0, '#FF6B6B');
        festiveGradient.addColorStop(0.5, '#FFE66D');
        festiveGradient.addColorStop(1, '#4ECDC4');
        ctx.setFillStyle(festiveGradient);
        ctx.fillRect(0, 0, width, height);
        break;
      default:
        // 经典风格 - 白色背景
        ctx.setFillStyle('#ffffff');
        ctx.fillRect(0, 0, width, height);
        break;
    }
  },

  // 绘制边框
  drawBorder: function (ctx, style, width, height) {
    let borderColor, borderWidth;
    switch (style) {
      case 'modern':
        borderColor = 'rgba(255, 255, 255, 0.3)';
        borderWidth = 6;
        break;
      case 'elegant':
        borderColor = '#27ae60';
        borderWidth = 8;
        break;
      case 'festive':
        borderColor = '#FFD700';
        borderWidth = 10;
        break;
      default:
        borderColor = '#4CAF50';
        borderWidth = 8;
        break;
    }
    
    ctx.setStrokeStyle(borderColor);
    ctx.setLineWidth(borderWidth);
    ctx.strokeRect(20, 20, width - 40, height - 40);
  },

  // 绘制标题
  drawTitle: function (ctx, style, width) {
    let titleText, titleColor, fontSize;
    switch (style) {
      case 'modern':
        titleText = '✨ 挑战完成证书 ✨';
        titleColor = '#ffffff';
        fontSize = 44;
        break;
      case 'elegant':
        titleText = '💎 挑战完成证书 💎';
        titleColor = '#27ae60';
        fontSize = 48;
        break;
      case 'festive':
        titleText = '🎉 挑战完成证书 🎉';
        titleColor = '#FFD700';
        fontSize = 46;
        break;
      default:
        titleText = '挑战完成证书';
        titleColor = '#4CAF50';
        fontSize = 48;
        break;
    }
    
    ctx.setFillStyle(titleColor);
    ctx.setFontSize(fontSize);
    ctx.setTextAlign('center');
    ctx.fillText(titleText, width / 2, 120);
    
    // 副标题
    ctx.setFillStyle(style === 'modern' ? 'rgba(255, 255, 255, 0.8)' : '#666666');
    ctx.setFontSize(24);
    ctx.fillText('Certificate of Achievement', width / 2, 160);
  },

  // 绘制用户信息
  drawUserInfo: function (ctx, style, width) {
    const textColor = style === 'modern' || style === 'elegant' || style === 'festive' ? '#ffffff' : '#333333';
    ctx.setFillStyle(textColor);
    ctx.setFontSize(32);
    ctx.fillText(this.data.userInfo.nickName || '快喝水用户', width / 2, 220);
  },

  // 绘制挑战信息
  drawChallengeInfo: function (ctx, style, width) {
    const textColor = style === 'modern' || style === 'elegant' || style === 'festive' ? '#ffffff' : '#333333';
    ctx.setFillStyle(textColor);
    ctx.setFontSize(28);
    ctx.fillText('成功完成', width / 2, 280);
    
    ctx.setFontSize(36);
    ctx.fillText(this.data.challenge.name, width / 2, 320);
    
    ctx.setFontSize(24);
    ctx.fillText(this.data.challenge.description, width / 2, 360);
  },

  // 绘制完成信息
  drawCompletionInfo: function (ctx, style, width) {
    const textColor = style === 'modern' || style === 'elegant' || style === 'festive' ? '#ffffff' : '#333333';
    ctx.setFillStyle(textColor);
    ctx.setFontSize(20);
    ctx.fillText(`完成时间: ${this.data.completionDate}`, width / 2, 420);
    ctx.fillText(`挑战天数: ${this.data.challenge.totalDays}天`, width / 2, 450);
    ctx.fillText(`目标水量: ${this.data.challenge.targetAmount}ml/天`, width / 2, 480);
  },

  // 绘制奖励信息
  drawRewardInfo: function (ctx, style, width) {
    let rewardColor;
    switch (style) {
      case 'modern':
        rewardColor = '#FFD700';
        break;
      case 'elegant':
        rewardColor = '#27ae60';
        break;
      case 'festive':
        rewardColor = '#FF6B6B';
        break;
      default:
        rewardColor = '#FFD700';
        break;
    }
    
    ctx.setFillStyle(rewardColor);
    ctx.setFontSize(28);
    ctx.fillText(`获得奖励: ${this.data.challenge.reward}`, width / 2, 530);
  },

  // 绘制证书编号
  drawCertificateId: function (ctx, style, width) {
    const textColor = style === 'modern' || style === 'elegant' || style === 'festive' ? 'rgba(255, 255, 255, 0.7)' : '#999999';
    ctx.setFillStyle(textColor);
    ctx.setFontSize(18);
    ctx.fillText(`证书编号: ${this.data.certificateId}`, width / 2, 580);
  },

  // 绘制签名
  drawSignature: function (ctx, style, width) {
    const textColor = style === 'modern' || style === 'elegant' || style === 'festive' ? '#ffffff' : '#333333';
    ctx.setFillStyle(textColor);
    ctx.setFontSize(20);
    ctx.fillText('快喝水团队', width / 2, 650);
    ctx.fillText(this.data.issueDate, width / 2, 680);
  },

  // 生成图片用于预览
  generateImageForPreview: function () {
    wx.canvasToTempFilePath({
      canvasId: 'certificateCanvas',
      success: (res) => {
        wx.hideLoading();
        this.setData({
          shareImagePath: res.tempFilePath
        });
        wx.showToast({
          title: '长按图片可分享',
          icon: 'none',
          duration: 2000
        });
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('生成图片失败:', err);
        wx.showToast({
          title: '生成证书失败',
          icon: 'none'
        });
      }
    });
  },

  // 长按图片分享
  onImageLongPress: function () {
    wx.showActionSheet({
      itemList: ['分享到朋友圈', '保存到相册'],
      success: (res) => {
        if (res.tapIndex === 0) {
          // 分享到朋友圈
          wx.showToast({
            title: '请点击右上角分享',
            icon: 'none'
          });
        } else if (res.tapIndex === 1) {
          // 保存到相册
          this.generateCertificateImage();
        }
      }
    });
  },

  // 返回上一页
  goBack: function () {
    wx.navigateBack({
      delta: 1
    });
  },

  // 切换证书样式
  switchCertificateStyle: function (e) {
    const style = e.currentTarget.dataset.style;
    this.setData({
      certificateStyle: style
    });
    
    wx.showToast({
      title: `已切换到${this.data.certificateStyles.find(s => s.id === style).name}样式`,
      icon: 'none'
    });
  },

  // 分享功能
  onShareAppMessage: function () {
    return {
      title: `我完成了${this.data.challenge.name}挑战！`,
      desc: '快来挑战自我，养成健康喝水习惯',
      path: '/pages/water-challenge/water-challenge'
    };
  },

  onShareTimeline: function () {
    return {
      title: `我完成了${this.data.challenge.name}挑战！`,
      query: '',
      imageUrl: this.data.shareImagePath || ''
    };
  }
});
