// pages/web-settings/web-settings.ts
import { getCurrentTheme } from '../../utils/theme'

Page({
  data: {
    reminderEnabled: false,
    reminderTime: '09:00',
    reminderIntervalIndex: 0,
    reminderIntervals: [30, 60, 90, 120, 180],
    startTime: '08:00',
    endTime: '22:00',
    cloudReminderEnabled: false,
    hasSubscribed: false,
    defaultCupIndex: 0,
    dailyTarget: 2000,
    targetIndex: 1,
    soundEnabled: true,
    vibrationEnabled: true,
    cupOptions: [
      { label: '小杯', value: 200 },
      { label: '中杯', value: 350 },
      { label: '大杯', value: 500 },
      { label: '超大杯', value: 750 }
    ],
    targetOptions: [
      { label: '1500ml', value: 1500 },
      { label: '2000ml', value: 2000 },
      { label: '2500ml', value: 2500 },
      { label: '3000ml', value: 3000 }
    ]
  },

  onLoad(options: any) {
    // 检查是否从网页版跳转过来
    if (options.fromWeb) {
      this.setData({ fromWeb: true });
      wx.showToast({
        title: '欢迎使用小程序设置',
        icon: 'success'
      });
    }
    
    this.loadSettings();
    this.applyCurrentTheme();
  },

  onShow() {
    this.loadSettings();
    this.applyCurrentTheme();
  },

  // 加载设置
  loadSettings() {
    const reminderEnabled = wx.getStorageSync('reminderEnabled') || false;
    const reminderTime = wx.getStorageSync('reminderTime') || '09:00';
    const reminderIntervalIndex = wx.getStorageSync('reminderIntervalIndex') || 0;
    const startTime = wx.getStorageSync('startTime') || '08:00';
    const endTime = wx.getStorageSync('endTime') || '22:00';
    const cloudReminderEnabled = wx.getStorageSync('cloudReminderEnabled') || false;
    const defaultCupIndex = wx.getStorageSync('defaultCupIndex') || 0;
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
    const soundEnabled = wx.getStorageSync('soundEnabled') !== false;
    const vibrationEnabled = wx.getStorageSync('vibrationEnabled') !== false;
    
    // 计算目标索引
    const targetIndex = this.data.targetOptions.findIndex(item => item.value === dailyTarget);
    
    this.setData({ 
      reminderEnabled, 
      reminderTime, 
      reminderIntervalIndex,
      startTime,
      endTime,
      cloudReminderEnabled,
      defaultCupIndex,
      dailyTarget,
      targetIndex: targetIndex >= 0 ? targetIndex : 1,
      soundEnabled,
      vibrationEnabled
    });
  },

  // 云提醒开关变化
  onCloudReminderChange(e: any) {
    this.setData({ cloudReminderEnabled: e.detail.value });
    this.saveSettings();
    
    if (e.detail.value) {
      // 请求订阅消息权限
      wx.requestSubscribeMessage({
        tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
        success: (res) => {
          if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
            wx.showToast({ title: '云提醒已开启', icon: 'success' });
            this.saveCloudSettings();
          } else {
            this.setData({ cloudReminderEnabled: false });
            wx.showToast({ title: '未授权订阅', icon: 'none' });
          }
        },
        fail: (err) => {
          this.setData({ cloudReminderEnabled: false });
          wx.showToast({ title: '请在设置中开启订阅消息权限', icon: 'none' });
        }
      });
    }
  },

  // 订阅云提醒
  subscribeCloudReminder() {
    wx.requestSubscribeMessage({
      tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
      success: (res) => {
        if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
          wx.showToast({ title: '订阅成功', icon: 'success' });
          this.setData({ hasSubscribed: true });
        } else {
          wx.showToast({ title: '订阅失败', icon: 'none' });
        }
      },
      fail: (err) => {
        wx.showToast({ title: '订阅失败', icon: 'none' });
      }
    });
  },

  // 时间选择变化
  onTimeChange(e: any) {
    this.setData({ reminderTime: e.detail.value });
    this.saveSettings();
  },

  // 提醒间隔变化
  onIntervalChange(e: any) {
    this.setData({ reminderIntervalIndex: e.detail.value });
    this.saveSettings();
  },

  // 开始时间变化
  onStartTimeChange(e: any) {
    this.setData({ startTime: e.detail.value });
    this.saveSettings();
  },

  // 结束时间变化
  onEndTimeChange(e: any) {
    this.setData({ endTime: e.detail.value });
    this.saveSettings();
  },

  // 默认杯子变化
  onDefaultCupChange(e: any) {
    this.setData({ defaultCupIndex: e.detail.value });
    this.saveSettings();
  },

  // 每日目标变化
  onDailyTargetChange(e: any) {
    this.setData({ 
      dailyTarget: this.data.targetOptions[e.detail.value].value,
      targetIndex: e.detail.value
    });
    this.saveSettings();
  },

  // 声音开关变化
  onSoundChange(e: any) {
    this.setData({ soundEnabled: e.detail.value });
    this.saveSettings();
  },

  // 震动开关变化
  onVibrationChange(e: any) {
    this.setData({ vibrationEnabled: e.detail.value });
    this.saveSettings();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const theme = getCurrentTheme();
    this.setData({
      theme: theme,
      pageStyle: `background: ${theme.backgroundColor};`
    });
  },

  // 保存设置
  saveSettings() {
    wx.setStorageSync('reminderEnabled', this.data.reminderEnabled);
    wx.setStorageSync('reminderTime', this.data.reminderTime);
    wx.setStorageSync('reminderIntervalIndex', this.data.reminderIntervalIndex);
    wx.setStorageSync('startTime', this.data.startTime);
    wx.setStorageSync('endTime', this.data.endTime);
    wx.setStorageSync('cloudReminderEnabled', this.data.cloudReminderEnabled);
    wx.setStorageSync('defaultCupIndex', this.data.defaultCupIndex);
    wx.setStorageSync('dailyTarget', this.data.dailyTarget);
    wx.setStorageSync('soundEnabled', this.data.soundEnabled);
    wx.setStorageSync('vibrationEnabled', this.data.vibrationEnabled);
    
    wx.showToast({ title: '设置已保存', icon: 'success' });
  },

  // 保存云设置
  saveCloudSettings() {
    wx.showLoading({ title: '保存中...' });
    
    wx.cloud.callFunction({
      name: 'sendReminder',
      data: {
        time: this.data.reminderTime,
        enabled: this.data.reminderEnabled,
        reminderInterval: this.data.reminderIntervals[this.data.reminderIntervalIndex],
        startTime: this.data.startTime,
        endTime: this.data.endTime,
        remindTitle: '喝水提醒',
        remindContent: '该喝水啦，保持健康！'
      },
      success: (res: any) => {
        wx.hideLoading();
        if (res.result && res.result.code === 0) {
          wx.showToast({ title: '云端设置已保存', icon: 'success' });
        } else {
          wx.showToast({ title: '云端保存失败', icon: 'none' });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('云函数调用失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      }
    });
  },

  // 返回网页版
  backToWeb() {
    wx.showModal({
      title: '返回网页版',
      content: '设置已完成，是否返回网页版？',
      success: (res) => {
        if (res.confirm) {
          // 可以在这里添加返回网页版的逻辑
          wx.showToast({
            title: '请返回网页版继续使用',
            icon: 'success'
          });
        }
      }
    });
  }
}); 