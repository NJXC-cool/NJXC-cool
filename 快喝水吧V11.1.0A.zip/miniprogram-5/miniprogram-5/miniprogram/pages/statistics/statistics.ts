import { getCurrentTheme } from '../../utils/theme'

interface ChartData {
  date: string;
  value: number;
  percentage: number;
  label: string;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  target: number;
  progress: number;
  unlocked: boolean;
}

interface DetailedRecord {
  id: string;
  date: string;
  day: string;
  totalAmount: number;
  cups: number;
  progressPercent: number;
}

interface TagStat {
  tag: string;
  emoji: string;
  label: string;
  count: number;
}

Page({
  data: {
    selectedTimeRange: 'week',
    timeRanges: [
      { value: 'week', label: '本周' },
      { value: 'month', label: '本月' },
      { value: 'year', label: '本年' }
    ],
    totalWater: 0,
    totalDays: 0,
    averageDaily: 0,
    completionRate: 0,
    chartData: [] as ChartData[],
    achievements: [] as Achievement[],
    detailedRecords: [] as DetailedRecord[],
    tagStats: [] as TagStat[],
    moodTagStats: [] as TagStat[],
    sceneTagStats: [] as TagStat[],
    temperatureTagStats: [] as TagStat[]
  },

  onLoad() {
    this.loadStatistics();
    this.applyCurrentTheme();
  },

  onShow() {
    this.loadStatistics();
    this.applyCurrentTheme();
  },

  // 选择时间范围
  selectTimeRange(e: any) {
    const value = e.currentTarget.dataset.value;
    this.setData({ selectedTimeRange: value });
    this.loadStatistics();
  },

  // 加载统计数据
  loadStatistics() {
    const records = wx.getStorageSync('waterRecords') || {};
    const settings = wx.getStorageSync('waterSettings') || {};
    const dailyTarget = settings.dailyTarget || 2000;

    const { startDate, endDate } = this.getDateRange();
    const filteredRecords = this.filterRecordsByDateRange(records, startDate, endDate);
    
    this.calculateOverview(filteredRecords, dailyTarget);
    this.generateChartData(filteredRecords);
    this.calculateAchievements(records);
    this.generateDetailedRecords(filteredRecords, dailyTarget);
    this.calculateTagStats(filteredRecords);
  },

  // 获取日期范围
  getDateRange() {
    const now = new Date();
    let startDate: Date;
    
    switch (this.data.selectedTimeRange) {
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }
    
    return { startDate, endDate: now };
  },

  // 过滤记录
  filterRecordsByDateRange(records: any, startDate: Date, endDate: Date) {
    const filtered: any = {};
    
    Object.keys(records).forEach(date => {
      const recordDate = new Date(date);
      if (recordDate >= startDate && recordDate <= endDate) {
        filtered[date] = records[date];
      }
    });
    
    return filtered;
  },

  // 计算总览数据
  calculateOverview(records: any, dailyTarget: number) {
    let totalWater = 0;
    let totalDays = 0;
    let completedDays = 0;
    
    Object.keys(records).forEach(date => {
      const dayRecords = records[date];
      const dayTotal = dayRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
      totalWater += dayTotal;
      totalDays++;
      
      if (dayTotal >= dailyTarget) {
        completedDays++;
      }
    });
    
    const averageDaily = totalDays > 0 ? Math.round(totalWater / totalDays) : 0;
    const completionRate = totalDays > 0 ? Math.round((completedDays / totalDays) * 100) : 0;
    
    this.setData({
      totalWater,
      totalDays,
      averageDaily,
      completionRate
    });
  },

  // 生成图表数据
  generateChartData(records: any) {
    const chartData: ChartData[] = [];
    const dates = Object.keys(records).sort();
    
    // 获取最近7天的数据
    const recentDates = dates.slice(-7);
    const maxValue = Math.max(...recentDates.map(date => {
      const dayRecords = records[date];
      return dayRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
    }));
    
    recentDates.forEach(date => {
      const dayRecords = records[date];
      const value = dayRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
      const percentage = maxValue > 0 ? Math.round((value / maxValue) * 100) : 0;
      const label = this.formatChartLabel(date);
      
      chartData.push({
        date,
        value,
        percentage,
        label
      });
    });
    
    this.setData({ chartData });
  },

  // 格式化图表标签
  formatChartLabel(dateStr: string): string {
    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
    
    if (this.isSameDay(date, today)) {
      return '今天';
    } else if (this.isSameDay(date, yesterday)) {
      return '昨天';
    } else {
      const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
      return `周${weekdays[date.getDay()]}`;
    }
  },

  // 判断是否为同一天
  isSameDay(date1: Date, date2: Date): boolean {
    return date1.getFullYear() === date2.getFullYear() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getDate() === date2.getDate();
  },

  // 计算成就
  calculateAchievements(records: any) {
    const achievements: Achievement[] = [
      {
        id: 'first_drink',
        name: '初次尝试',
        description: '记录第一次喝水',
        icon: '🥤',
        target: 1,
        progress: 0,
        unlocked: false
      },
      {
        id: 'daily_goal',
        name: '目标达成',
        description: '完成一次每日目标',
        icon: '🎯',
        target: 1,
        progress: 0,
        unlocked: false
      },
      {
        id: 'week_streak',
        name: '坚持一周',
        description: '连续记录7天',
        icon: '🔥',
        target: 7,
        progress: 0,
        unlocked: false
      },
      {
        id: 'month_streak',
        name: '月度达人',
        description: '连续记录30天',
        icon: '🏆',
        target: 30,
        progress: 0,
        unlocked: false
      },
      {
        id: 'water_master',
        name: '喝水大师',
        description: '累计喝水100升',
        icon: '💧',
        target: 100000,
        progress: 0,
        unlocked: false
      }
    ];

    // 计算各项成就进度
    const allRecords = Object.values(records).flat();
    const totalWater = allRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
    const totalDays = Object.keys(records).length;
    
    // 计算连续天数
    const consecutiveDays = this.calculateConsecutiveDays(records);
    
    // 计算完成目标的天数
    const settings = wx.getStorageSync('waterSettings') || {};
    const dailyTarget = settings.dailyTarget || 2000;
    const completedDays = Object.values(records).filter((dayRecords: any) => {
      const dayTotal = dayRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
      return dayTotal >= dailyTarget;
    }).length;

    // 更新成就进度
    achievements[0].progress = allRecords.length > 0 ? 1 : 0;
    achievements[0].unlocked = allRecords.length > 0;
    
    achievements[1].progress = completedDays;
    achievements[1].unlocked = completedDays >= 1;
    
    achievements[2].progress = consecutiveDays;
    achievements[2].unlocked = consecutiveDays >= 7;
    
    achievements[3].progress = consecutiveDays;
    achievements[3].unlocked = consecutiveDays >= 30;
    
    achievements[4].progress = totalWater;
    achievements[4].unlocked = totalWater >= 100000;

    this.setData({ achievements });
  },

  // 计算连续天数
  calculateConsecutiveDays(records: any): number {
    const dates = Object.keys(records).sort();
    if (dates.length === 0) return 0;
    
    let consecutiveDays = 1;
    let maxConsecutive = 1;
    
    for (let i = 1; i < dates.length; i++) {
      const prevDate = new Date(dates[i - 1]);
      const currDate = new Date(dates[i]);
      const diffDays = Math.floor((currDate.getTime() - prevDate.getTime()) / (24 * 60 * 60 * 1000));
      
      if (diffDays === 1) {
        consecutiveDays++;
        maxConsecutive = Math.max(maxConsecutive, consecutiveDays);
      } else {
        consecutiveDays = 1;
      }
    }
    
    return maxConsecutive;
  },

  // 生成详细记录
  generateDetailedRecords(records: any, dailyTarget: number) {
    const detailedRecords: DetailedRecord[] = [];
    const dates = Object.keys(records).sort().reverse();
    
    dates.forEach(date => {
      const dayRecords = records[date];
      const totalAmount = dayRecords.reduce((sum: number, record: any) => sum + record.amount, 0);
      const cups = dayRecords.length;
      const progressPercent = Math.min(100, Math.round((totalAmount / dailyTarget) * 100));
      
      const recordDate = new Date(date);
      const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
      
      detailedRecords.push({
        id: date,
        date: `${recordDate.getMonth() + 1}/${recordDate.getDate()}`,
        day: `周${weekdays[recordDate.getDay()]}`,
        totalAmount,
        cups,
        progressPercent
      });
    });
    
    this.setData({ detailedRecords });
  },

  // 计算标签统计
  calculateTagStats(records: any) {
    const moodStats: { [key: string]: number } = {};
    const sceneStats: { [key: string]: number } = {};
    const temperatureStats: { [key: string]: number } = {};
    
    // 遍历所有记录，统计标签
    Object.keys(records).forEach(date => {
      const dayRecords = records[date];
      dayRecords.forEach((record: any) => {
        if (record.tags && Array.isArray(record.tags)) {
          record.tags.forEach((tag: string) => {
            // 解析标签类型
            if (tag.includes('😊') || tag.includes('😴') || tag.includes('🤩') || tag.includes('😰') || 
                tag.includes('😌') || tag.includes('💪') || tag.includes('😢') || tag.includes('🎯') || tag.includes('😐')) {
              moodStats[tag] = (moodStats[tag] || 0) + 1;
            } else if (tag.includes('💼') || tag.includes('🏃') || tag.includes('📚') || tag.includes('😴') || 
                       tag.includes('🌅') || tag.includes('🍽️') || tag.includes('👥') || tag.includes('✈️') || tag.includes('📍')) {
              sceneStats[tag] = (sceneStats[tag] || 0) + 1;
            } else if (tag.includes('🔥') || tag.includes('☕') || tag.includes('🧊') || tag.includes('🌡️')) {
              temperatureStats[tag] = (temperatureStats[tag] || 0) + 1;
            }
          });
        }
      });
    });
    
    // 转换为数组格式
    const moodTagStats = Object.keys(moodStats).map(tag => ({
      tag,
      emoji: tag.split(' ')[0],
      label: tag.split(' ')[1],
      count: moodStats[tag]
    })).sort((a, b) => b.count - a.count);
    
    const sceneTagStats = Object.keys(sceneStats).map(tag => ({
      tag,
      emoji: tag.split(' ')[0],
      label: tag.split(' ')[1],
      count: sceneStats[tag]
    })).sort((a, b) => b.count - a.count);
    
    const temperatureTagStats = Object.keys(temperatureStats).map(tag => ({
      tag,
      emoji: tag.split(' ')[0],
      label: tag.split(' ')[1],
      count: temperatureStats[tag]
    })).sort((a, b) => b.count - a.count);
    
    this.setData({
      moodTagStats,
      sceneTagStats,
      temperatureTagStats,
      tagStats: [...moodTagStats, ...sceneTagStats, ...temperatureTagStats]
    });
  },

  // 应用当前主题
  applyCurrentTheme() {
    const theme = getCurrentTheme();
    this.setData({
      theme: theme,
      pageStyle: `background: ${theme.backgroundColor};`
    });
  },

  onShareAppMessage() {
    return {
      title: '查看我的喝水数据统计，快来快喝水小程序！',
      path: '/pages/statistics/statistics'
    }
  },

  onShareTimeline() {
    return {
      title: '查看我的喝水数据统计，快来快喝水小程序！',
      path: '/pages/statistics/statistics'
    }
  }
}); 