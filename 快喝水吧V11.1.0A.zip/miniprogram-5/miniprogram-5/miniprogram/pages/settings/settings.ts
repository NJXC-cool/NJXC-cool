// pages/settings/settings.ts
import { getCurrentTheme, themes, switchTheme } from '../../utils/theme'

Page({
  data: {
    reminderEnabled: false,
    reminderTime: '09:00',
    reminderIntervalIndex: 0,
    reminderIntervals: [30, 60, 90, 120, 180],
    startTime: '08:00',
    endTime: '22:00',
    cloudReminderEnabled: false,
    hasSubscribed: false,
    defaultCupIndex: 0,
    dailyTarget: 2000,
    targetIndex: 1,
    soundEnabled: true,
    vibrationEnabled: true,
    themeIndex: 0,
    cupOptions: [
      { label: '小杯', value: 200 },
      { label: '中杯', value: 350 },
      { label: '大杯', value: 500 },
      { label: '超大杯', value: 750 }
    ],
    themeOptions: themes.map(theme => ({ label: theme.label, value: theme.name })),
    targetOptions: [
      { label: '1500ml', value: 1500 },
      { label: '2000ml', value: 2000 },
      { label: '2500ml', value: 2500 },
      { label: '3000ml', value: 3000 }
    ]
  },

  onLoad() {
    this.loadSettings()
    this.applyCurrentTheme()
  },

  onShareAppMessage() {
    return {
      title: '自定义喝水目标和提醒，快来快喝水小程序！',
      path: '/pages/settings/settings'
    }
  },

  onShareTimeline() {
    return {
      title: '自定义喝水目标和提醒，快来快喝水小程序！',
      path: '/pages/settings/settings'
    }
  },

  // 加载所有设置
  loadSettings() {
    const reminderEnabled = wx.getStorageSync('reminderEnabled') || false
    const reminderTime = wx.getStorageSync('reminderTime') || '09:00'
    const reminderIntervalIndex = wx.getStorageSync('reminderIntervalIndex') || 0
    const startTime = wx.getStorageSync('startTime') || '08:00'
    const endTime = wx.getStorageSync('endTime') || '22:00'
    const cloudReminderEnabled = wx.getStorageSync('cloudReminderEnabled') || false
    const defaultCupIndex = wx.getStorageSync('defaultCupIndex') || 0
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000
    const soundEnabled = wx.getStorageSync('soundEnabled') !== false
    const vibrationEnabled = wx.getStorageSync('vibrationEnabled') !== false
    const themeIndex = wx.getStorageSync('themeIndex') || 0
    
    // 计算目标索引
    const targetIndex = this.data.targetOptions.findIndex(item => item.value === dailyTarget)
    
    this.setData({ 
      reminderEnabled, 
      reminderTime, 
      reminderIntervalIndex,
      startTime,
      endTime,
      cloudReminderEnabled,
      defaultCupIndex,
      dailyTarget,
      targetIndex: targetIndex >= 0 ? targetIndex : 1,
      soundEnabled,
      vibrationEnabled,
      themeIndex
    })
  },

  // 提醒开关变化
  onReminderSwitchChange(e: any) {
    const enabled = e.detail.value
    this.setData({ reminderEnabled: enabled })
    this.saveSettings()
  },

  // 时间选择变化
  onTimeChange(e: any) {
    this.setData({ reminderTime: e.detail.value })
    this.saveSettings()
  },

  // 提醒间隔变化
  onIntervalChange(e: any) {
    this.setData({ reminderIntervalIndex: e.detail.value })
    this.saveSettings()
  },

  // 开始时间变化
  onStartTimeChange(e: any) {
    this.setData({ startTime: e.detail.value })
    this.saveSettings()
  },

  // 结束时间变化
  onEndTimeChange(e: any) {
    this.setData({ endTime: e.detail.value })
    this.saveSettings()
  },

  // 云提醒开关变化
  onCloudReminderChange(e: any) {
    this.setData({ cloudReminderEnabled: e.detail.value });
    this.saveSettings();
    
    if (e.detail.value) {
      // 请求订阅消息权限
      wx.requestSubscribeMessage({
        tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
        success: (res) => {
          if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
            wx.showToast({ title: '云提醒已开启', icon: 'success' });
            // 调用云函数保存提醒设置
            this.saveCloudSettings();
          } else {
            this.setData({ cloudReminderEnabled: false });
            wx.showToast({ title: '未授权订阅', icon: 'none' });
          }
        },
        fail: (err) => {
          this.setData({ cloudReminderEnabled: false });
          wx.showToast({ title: '请在设置中开启订阅消息权限', icon: 'none' });
        }
      });
    }
  },

  // 默认杯子变化
  onDefaultCupChange(e: any) {
    this.setData({ defaultCupIndex: e.detail.value })
    this.saveSettings()
  },

  // 每日目标变化
  onDailyTargetChange(e: any) {
    this.setData({ 
      dailyTarget: this.data.targetOptions[e.detail.value].value,
      targetIndex: e.detail.value
    })
    this.saveSettings()
  },

  // 声音开关变化
  onSoundChange(e: any) {
    this.setData({ soundEnabled: e.detail.value })
    this.saveSettings()
  },

  // 震动开关变化
  onVibrationChange(e: any) {
    this.setData({ vibrationEnabled: e.detail.value })
    this.saveSettings()
  },



  // 主题变化
  onThemeChange(e: any) {
    const themeName = e.detail.theme;
    const themeIndex = this.data.themeOptions.findIndex((option: any) => option.value === themeName);
    const index = themeIndex >= 0 ? themeIndex : 0;
    this.setData({ themeIndex: index });
    this.saveSettings();
    switchTheme(index, this);
  },

  // 应用当前主题
  applyCurrentTheme() {
    const theme = getCurrentTheme()
    this.setData({
      theme: theme,
      pageStyle: `background: ${theme.backgroundColor};`
    })
  },

  // 预览主题
  previewTheme() {
    wx.navigateTo({
      url: '/pages/theme-preview/theme-preview'
    })
  },

  // 主题演示
  demoTheme() {
    wx.navigateTo({
      url: '/pages/theme-demo/theme-demo'
    })
  },

  // 保存所有设置
  saveSettings() {
    wx.setStorageSync('reminderEnabled', this.data.reminderEnabled)
    wx.setStorageSync('reminderTime', this.data.reminderTime)
    wx.setStorageSync('reminderIntervalIndex', this.data.reminderIntervalIndex)
    wx.setStorageSync('startTime', this.data.startTime)
    wx.setStorageSync('endTime', this.data.endTime)
    wx.setStorageSync('cloudReminderEnabled', this.data.cloudReminderEnabled)
    wx.setStorageSync('defaultCupIndex', this.data.defaultCupIndex)
    wx.setStorageSync('dailyTarget', this.data.dailyTarget)
    wx.setStorageSync('soundEnabled', this.data.soundEnabled)
    wx.setStorageSync('vibrationEnabled', this.data.vibrationEnabled)
    wx.setStorageSync('themeIndex', this.data.themeIndex)
    
    wx.showToast({ title: '设置已保存', icon: 'success' })
  },

  // 保存云设置
  saveCloudSettings() {
    // 让用户选择保存方式
    wx.showModal({
      title: '保存云设置',
      content: '请选择保存方式：\n\n1. 基础保存：仅保存设置到云端\n2. 完整保存：包含用户信息（需要授权）',
      confirmText: '基础保存',
      cancelText: '完整保存',
      success: (res) => {
        if (res.confirm) {
          // 基础保存
          this.saveBasicCloudSettings();
        } else {
          // 完整保存
          this.saveFullCloudSettings();
        }
      }
    })
  },

  // 基础云设置保存
  saveBasicCloudSettings() {
    wx.showLoading({ title: '保存中...' });
    
    wx.cloud.callFunction({
      name: 'sendReminder',
      data: {
        time: this.data.reminderTime,
        enabled: this.data.reminderEnabled,
        reminderInterval: this.data.reminderIntervals[this.data.reminderIntervalIndex],
        startTime: this.data.startTime,
        endTime: this.data.endTime,
        remindTitle: '喝水提醒',
        remindContent: '该喝水啦，保持健康！'
      },
      success: (res: any) => {
        wx.hideLoading();
        if (res.result && res.result.code === 0) {
          wx.showToast({ title: '云端设置已保存', icon: 'success' })
        } else {
          wx.showToast({ title: '云端保存失败', icon: 'none' })
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('云函数调用失败:', err)
        wx.showToast({ title: '网络错误', icon: 'none' })
      }
    })
  },

  // 完整云设置保存（包含用户信息）
  saveFullCloudSettings() {
    // 先获取用户信息
    wx.getUserProfile({
      desc: '用于云设置保存',
      success: (userRes) => {
        console.log('获取用户信息成功:', userRes);
        
        wx.showLoading({ title: '保存中...' });
        
        wx.cloud.callFunction({
          name: 'sendReminder',
          data: {
            time: this.data.reminderTime,
            enabled: this.data.reminderEnabled,
            reminderInterval: this.data.reminderIntervals[this.data.reminderIntervalIndex],
            startTime: this.data.startTime,
            endTime: this.data.endTime,
            remindTitle: '喝水提醒',
            remindContent: '该喝水啦，保持健康！',
            userInfo: userRes.userInfo
          },
          success: (res: any) => {
            wx.hideLoading();
            if (res.result && res.result.code === 0) {
              wx.showToast({ title: '云端设置已保存', icon: 'success' })
            } else {
              wx.showToast({ title: '云端保存失败', icon: 'none' })
            }
          },
          fail: (err) => {
            wx.hideLoading();
            console.error('云函数调用失败:', err)
            wx.showToast({ title: '网络错误', icon: 'none' })
          }
        })
      },
      fail: (userErr) => {
        console.error('获取用户信息失败:', userErr);
        wx.showModal({
          title: '获取用户信息失败',
          content: '❌ 无法获取用户信息！\n\n可能原因：\n1. 用户拒绝授权\n2. 网络连接问题\n3. 微信版本不支持\n\n建议尝试基础保存模式。',
          confirmText: '尝试基础保存',
          cancelText: '取消',
          success: (res) => {
            if (res.confirm) {
              this.saveBasicCloudSettings();
            }
          }
        });
      }
    })
  },

  // 订阅云提醒
  subscribeCloudReminder() {
    // 让用户选择订阅方式
    wx.showModal({
      title: '订阅云提醒',
      content: '请选择订阅方式：\n\n1. 基础订阅：仅订阅消息通知\n2. 完整订阅：包含用户信息（需要授权）',
      confirmText: '基础订阅',
      cancelText: '完整订阅',
      success: (res) => {
        if (res.confirm) {
          // 基础订阅
          this.subscribeBasicCloudReminder();
        } else {
          // 完整订阅
          this.subscribeFullCloudReminder();
        }
      }
    })
  },

  // 基础云提醒订阅
  subscribeBasicCloudReminder() {
    wx.requestSubscribeMessage({
      tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
      success: (res) => {
        if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
          wx.showToast({ title: '基础订阅成功', icon: 'success' });
        } else {
          wx.showToast({ title: '订阅失败', icon: 'none' });
        }
      },
      fail: (err) => {
        wx.showToast({ title: '订阅失败', icon: 'none' });
      }
    });
  },

  // 完整云提醒订阅（包含用户信息）
  subscribeFullCloudReminder() {
    // 先获取用户信息
    wx.getUserProfile({
      desc: '用于云提醒订阅',
      success: (userRes) => {
        console.log('获取用户信息成功:', userRes);
        
        // 然后订阅消息
        wx.requestSubscribeMessage({
          tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
          success: (res) => {
            if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
              wx.showToast({ title: '完整订阅成功', icon: 'success' });
              // 可以在这里保存用户信息到云端
              console.log('用户信息:', userRes.userInfo);
            } else {
              wx.showToast({ title: '订阅失败', icon: 'none' });
            }
          },
          fail: (err) => {
            wx.showToast({ title: '订阅失败', icon: 'none' });
          }
        });
      },
      fail: (userErr) => {
        console.error('获取用户信息失败:', userErr);
        wx.showModal({
          title: '获取用户信息失败',
          content: '❌ 无法获取用户信息！\n\n可能原因：\n1. 用户拒绝授权\n2. 网络连接问题\n3. 微信版本不支持\n\n建议尝试基础订阅模式。',
          confirmText: '尝试基础订阅',
          cancelText: '取消',
          success: (res) => {
            if (res.confirm) {
              this.subscribeBasicCloudReminder();
            }
          }
        });
      }
    })
  },

  // 导出数据
  exportData() {
    const data = {
      waterRecords: wx.getStorageSync('waterRecords') || {},
      settings: {
        reminderEnabled: this.data.reminderEnabled,
        reminderTime: this.data.reminderTime,
        dailyTarget: this.data.dailyTarget,
        defaultCupIndex: this.data.defaultCupIndex
      },
      userData: wx.getStorageSync('userData') || {},
      exportTime: new Date().toISOString()
    }
    
    const dataStr = JSON.stringify(data, null, 2)
    
    // 复制到剪贴板
    wx.setClipboardData({
      data: dataStr,
      success: () => {
        wx.showModal({
          title: '数据导出成功',
          content: '数据已复制到剪贴板，请保存到安全的地方',
          showCancel: false
        })
      }
    })
  },

  // 导入数据
  importData() {
    wx.showModal({
      title: '导入数据',
      content: '请将导出的数据粘贴到输入框中',
      editable: true,
      placeholderText: '请粘贴数据内容',
      success: (res) => {
        if (res.confirm && res.content) {
          try {
            const data = JSON.parse(res.content)
            if (data.waterRecords) {
              wx.setStorageSync('waterRecords', data.waterRecords)
            }
            if (data.userData) {
              wx.setStorageSync('userData', data.userData)
            }
            if (data.settings) {
              Object.keys(data.settings).forEach(key => {
                wx.setStorageSync(key, data.settings[key])
              })
            }
            this.loadSettings()
            wx.showToast({ title: '数据导入成功', icon: 'success' })
          } catch (e) {
            wx.showToast({ title: '数据格式错误', icon: 'none' })
          }
        }
      }
    })
  },

  // 清除数据
  clearData() {
    wx.showModal({
      title: '确认清除',
      content: '这将清除所有本地数据，包括喝水记录、设置等，无法恢复',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync()
          this.loadSettings()
          wx.showToast({ title: '数据已清除', icon: 'success' })
        }
      }
    })
  },

  // 检查更新
  checkUpdate() {
    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate((res) => {
      if (res.hasUpdate) {
        wx.showModal({
          title: '发现新版本',
          content: '是否立即更新？',
          success: (res) => {
            if (res.confirm) {
              updateManager.applyUpdate()
            }
          }
        })
      } else {
        wx.showToast({ title: '已是最新版本', icon: 'success' })
      }
    })
  },

  // 意见反馈
  feedback() {
    wx.showModal({
      title: '意见反馈',
      content: '如有问题或建议，请通过以下方式联系我们：\n\n邮箱：xytx57@petalmail.com\n网站：http://njxc.xyz',
      showCancel: false
    })
  },

  // 访问网站
  visitWebsite() {
    wx.setClipboardData({
      data: 'http://njxc.xyz',
      success: () => {
        wx.showModal({
          title: '网站链接已复制',
          content: '网站地址已复制到剪贴板，请在浏览器中打开',
          showCancel: false
        })
      }
    })
  },

  // 关于我们
  aboutUs() {
    wx.showModal({
      title: '关于快喝水',
      content: '版本：1.2.0\n\n一款帮助您养成健康喝水习惯的小程序\n\n功能特色：\n• 智能提醒\n• 数据统计\n• 成就系统\n• 小游戏\n• 云同步\n• 数据导入导出\n\n开发者：奈境星辰 - 小宇同学\n\n官方网站：http://njxc.xyz',
      confirmText: '访问网站',
      success: (res) => {
        if (res.confirm) {
          this.visitWebsite()
        }
      }
    })
  },

  // 处理客服消息
  handleContact(e: any) {
    console.log('客服消息回调:', e.detail)
    
    // 如果用户从客服会话返回，并且有指定的页面路径
    if (e.detail.path) {
      console.log('用户点击的消息页面路径:', e.detail.path)
      console.log('消息参数:', e.detail.query)
      
      // 可以根据 path 和 query 进行页面跳转
      // 例如：如果客服发送了特定页面的链接
      if (e.detail.path.startsWith('/pages/')) {
        wx.navigateTo({
          url: e.detail.path + (e.detail.query ? '?' + this.buildQueryString(e.detail.query) : ''),
          fail: () => {
            wx.showToast({
              title: '页面跳转失败',
              icon: 'none'
            })
          }
        })
      }
    }
  },

  // 构建查询字符串
  buildQueryString(query: any): string {
    if (!query || typeof query !== 'object') return ''
    
    const params = []
    for (const key in query) {
      if (query.hasOwnProperty(key)) {
        params.push(`${key}=${encodeURIComponent(query[key])}`)
      }
    }
    return params.join('&')
  }
}) 