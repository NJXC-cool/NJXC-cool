interface FormData {
  name: string;
  age: string;
  gender: 'male' | 'female';
  lostLocation: string;
  lostDate: string;
  lostTime: string;
  description: string;
  photos: string[];
  contactName: string;
  contactPhone: string;
  isUrgent: boolean;
}

Page({
  data: {
    formData: {
      name: '',
      age: '',
      gender: 'male',
      lostLocation: '',
      lostDate: '',
      lostTime: '',
      description: '',
      photos: [],
      contactName: '',
      contactPhone: '',
      isUrgent: false
    } as FormData,
    submitting: false
  },

  // 输入框变化
  onInputChange(e: any) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      [`formData.${field}`]: value
    });
  },

  // 性别选择
  onGenderChange(e: any) {
    this.setData({
      'formData.gender': e.detail.value
    });
  },

  // 日期选择
  onDateChange(e: any) {
    this.setData({
      'formData.lostDate': e.detail.value
    });
  },

  // 时间选择
  onTimeChange(e: any) {
    this.setData({
      'formData.lostTime': e.detail.value
    });
  },

  // 紧急程度切换
  onUrgentChange(e: any) {
    this.setData({
      'formData.isUrgent': e.detail.value
    });
  },

  // 选择图片
  chooseImage() {
    wx.chooseImage({
      count: 3 - this.data.formData.photos.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newPhotos = [...this.data.formData.photos, ...res.tempFilePaths];
        this.setData({
          'formData.photos': newPhotos
        });
      }
    });
  },

  // 删除图片
  deletePhoto(e: any) {
    const index = e.currentTarget.dataset.index;
    const photos = [...this.data.formData.photos];
    photos.splice(index, 1);
    this.setData({
      'formData.photos': photos
    });
  },

  // 预览图片
  previewImage(e: any) {
    const url = e.currentTarget.dataset.url;
    wx.previewImage({
      current: url,
      urls: this.data.formData.photos
    });
  },

  // 表单验证
  validateForm(): boolean {
    const { formData } = this.data;
    
    if (!formData.name.trim()) {
      wx.showToast({ title: '请输入儿童姓名', icon: 'none' });
      return false;
    }
    
    if (!formData.age || parseInt(formData.age) <= 0 || parseInt(formData.age) > 18) {
      wx.showToast({ title: '请输入有效年龄', icon: 'none' });
      return false;
    }
    
    if (!formData.lostLocation.trim()) {
      wx.showToast({ title: '请输入走失地点', icon: 'none' });
      return false;
    }
    
    if (!formData.lostDate || !formData.lostTime) {
      wx.showToast({ title: '请选择走失时间', icon: 'none' });
      return false;
    }
    
    if (!formData.description.trim()) {
      wx.showToast({ title: '请输入详细描述', icon: 'none' });
      return false;
    }
    
    if (!formData.contactName.trim()) {
      wx.showToast({ title: '请输入联系人姓名', icon: 'none' });
      return false;
    }
    
    if (!formData.contactPhone.trim() || !/^1[3-9]\d{9}$/.test(formData.contactPhone)) {
      wx.showToast({ title: '请输入有效手机号', icon: 'none' });
      return false;
    }
    
    return true;
  },

  // 提交表单
  async onSubmit() {
    if (!this.validateForm()) return;
    
    this.setData({ submitting: true });
    
    try {
      // 上传图片到云存储
      const uploadedPhotos = await this.uploadPhotos();
      
      // 准备提交数据
      const submitData = {
        ...this.data.formData,
        photos: uploadedPhotos,
        lostTime: `${this.data.formData.lostDate} ${this.data.formData.lostTime}`,
        status: 'lost',
        createTime: new Date().toISOString()
      };
      
      // 提交到云数据库
      await this.submitToDatabase(submitData);
      
      wx.showToast({
        title: '发布成功',
        icon: 'success'
      });
      
      // 返回上一页
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      
    } catch (error) {
      console.error('发布失败:', error);
      wx.showToast({
        title: '发布失败，请重试',
        icon: 'none'
      });
    } finally {
      this.setData({ submitting: false });
    }
  },

  // 上传图片到云存储
  async uploadPhotos(): Promise<string[]> {
    if (this.data.formData.photos.length === 0) return [];
    
    const uploadTasks = this.data.formData.photos.map(async (filePath, index) => {
      try {
        const result = await wx.cloud.uploadFile({
          cloudPath: `lost-children/${Date.now()}_${index}.jpg`,
          filePath: filePath
        });
        return result.fileID;
      } catch (error) {
        console.error('图片上传失败:', error);
        throw error;
      }
    });
    
    return Promise.all(uploadTasks);
  },

  // 提交到云数据库
  async submitToDatabase(data: any) {
    try {
      const db = wx.cloud.database();
      await db.collection('lostChildren').add({
        data: data
      });
    } catch (error) {
      console.error('数据库提交失败:', error);
      throw error;
    }
  },

  // 分享
  onShareAppMessage() {
    return {
      title: '走失宝贝回家 - 发布寻人启事',
      path: '/pages/publish/publish'
    };
  }
}); 