// pages/api-config/api-config.ts
Page({
  data: {
    apiKey: '',
    showKey: false,
    keyStatus: 'unknown', // unknown, valid, invalid
    keyStatusText: '未配置',
    testResult: null
  },

  onLoad() {
    // 加载已保存的API密钥
    const savedKey = wx.getStorageSync('deepseek_api_key') || '';
    this.setData({ 
      apiKey: savedKey,
      keyStatus: this.validateApiKey(savedKey) ? 'valid' : 'invalid',
      keyStatusText: this.validateApiKey(savedKey) ? '已配置' : '格式错误'
    });
  },

  // API密钥输入
  onApiKeyInput(e: any) {
    const apiKey = e.detail.value.trim();
    this.setData({ 
      apiKey,
      keyStatus: this.validateApiKey(apiKey) ? 'valid' : 'invalid',
      keyStatusText: this.validateApiKey(apiKey) ? '格式正确' : '格式错误'
    });
  },

  // 切换显示/隐藏密钥
  toggleShowKey() {
    this.setData({ showKey: !this.data.showKey });
  },

  // 验证API密钥格式
  validateApiKey(key: string): boolean {
    return key && key.startsWith('sk-') && key.length > 10;
  },

  // 测试API密钥
  testApiKey() {
    if (!this.data.apiKey) {
      wx.showToast({ title: '请输入API密钥', icon: 'none' });
      return;
    }

    if (!this.validateApiKey(this.data.apiKey)) {
      wx.showToast({ title: 'API密钥格式错误', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '测试中...' });

    wx.request({
      url: 'https://api.deepseek.com/chat/completions',
      method: 'POST',
      header: {
        'Authorization': 'Bearer ' + this.data.apiKey,
        'Content-Type': 'application/json'
      },
      data: {
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: '你是一个测试助手' },
          { role: 'user', content: '你好' }
        ],
        stream: false
      },
      success: (res: any) => {
        wx.hideLoading();
        console.log('API测试响应:', res);
        
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message && res.data.choices[0].message.content) {
          this.setData({
            testResult: {
              success: true,
              message: '✅ API密钥测试成功！',
              detail: '水宝助手可以正常使用AI功能了~'
            }
          });
          wx.showToast({ title: '测试成功', icon: 'success' });
        } else {
          this.setData({
            testResult: {
              success: false,
              message: '❌ API响应格式错误',
              detail: `状态码: ${res.statusCode}, 响应: ${JSON.stringify(res.data)}`
            }
          });
          wx.showToast({ title: '测试失败', icon: 'error' });
        }
      },
      fail: (err: any) => {
        wx.hideLoading();
        console.error('API测试失败:', err);
        
        let errorMsg = '网络连接失败';
        let errorDetail = '请检查网络连接';
        
        if (err.statusCode === 401) {
          errorMsg = 'API密钥无效';
          errorDetail = '请检查API密钥是否正确，或访问DeepSeek平台重新生成';
        } else if (err.statusCode === 429) {
          errorMsg = '请求频率过高';
          errorDetail = '请稍后再试，或检查API配额';
        } else if (err.statusCode >= 500) {
          errorMsg = '服务器错误';
          errorDetail = 'DeepSeek服务暂时不可用，请稍后再试';
        }
        
        this.setData({
          testResult: {
            success: false,
            message: `❌ ${errorMsg}`,
            detail: errorDetail
          }
        });
        wx.showToast({ title: errorMsg, icon: 'error' });
      }
    });
  },

  // 保存API密钥
  saveApiKey() {
    if (!this.data.apiKey) {
      wx.showToast({ title: '请输入API密钥', icon: 'none' });
      return;
    }

    if (!this.validateApiKey(this.data.apiKey)) {
      wx.showToast({ title: 'API密钥格式错误', icon: 'none' });
      return;
    }

    // 保存到本地存储
    wx.setStorageSync('deepseek_api_key', this.data.apiKey);
    
    // 更新全局配置
    getApp().globalData.deepseekApiKey = this.data.apiKey;
    
    this.setData({
      keyStatus: 'valid',
      keyStatusText: '已保存'
    });
    
    wx.showToast({ title: '保存成功', icon: 'success' });
    
    // 延迟返回上一页
    setTimeout(() => {
      wx.navigateBack();
    }, 1500);
  },

  // 复制API密钥
  copyApiKey() {
    if (!this.data.apiKey) {
      wx.showToast({ title: '没有可复制的密钥', icon: 'none' });
      return;
    }
    
    wx.setClipboardData({
      data: this.data.apiKey,
      success: () => {
        wx.showToast({ title: '已复制到剪贴板', icon: 'success' });
      }
    });
  }
}); 