const { getCurrentTheme } = require('../../utils/theme.js');

Page({
  data: {
    systemInfo: {},
    storageInfo: {},
    pageStyle: ''
  },

  onLoad: function () {
    this.applyCurrentTheme();
    this.loadSystemInfo();
    this.loadStorageInfo();
  },

  onShow: function () {
    this.applyCurrentTheme();
  },

  // 分享给好友
  onShareAppMessage: function () {
    return {
      title: '快喝水 - 开发者模式',
      desc: '查看应用的开发调试信息',
      path: '/pages/developer/developer'
    };
  },

  // 分享到朋友圈
  onShareTimeline: function () {
    return {
      title: '快喝水 - 开发者模式',
      query: '',
      imageUrl: ''
    };
  },

  applyCurrentTheme: function () {
    var theme = getCurrentTheme();
    this.setData({
      theme: theme,
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  loadSystemInfo: function () {
    // 使用新的API替代已弃用的wx.getSystemInfoSync
    var systemInfo = {};
    
    try {
      // 获取设备信息
      var deviceInfo = wx.getDeviceInfo();
      systemInfo.deviceInfo = deviceInfo;
      
      // 获取窗口信息
      var windowInfo = wx.getWindowInfo();
      systemInfo.windowInfo = windowInfo;
      
      // 获取应用基础信息
      var appBaseInfo = wx.getAppBaseInfo();
      systemInfo.appBaseInfo = appBaseInfo;
      
      // 获取系统设置
      var systemSetting = wx.getSystemSetting();
      systemInfo.systemSetting = systemSetting;
      
      // 获取应用授权设置
      var appAuthorizeSetting = wx.getAppAuthorizeSetting();
      systemInfo.appAuthorizeSetting = appAuthorizeSetting;
      
    } catch (error) {
      console.error('获取系统信息失败:', error);
      // 如果新API不可用，回退到旧API
      try {
        systemInfo = wx.getSystemInfoSync();
      } catch (fallbackError) {
        console.error('回退获取系统信息也失败:', fallbackError);
        systemInfo = { error: '无法获取系统信息' };
      }
    }
    
    this.setData({
      systemInfo: systemInfo
    });
  },

  loadStorageInfo: function () {
    var storageInfo = wx.getStorageInfoSync();
    this.setData({
      storageInfo: storageInfo
    });
  },

  viewData: function () {
    var allData = {};
    var keys = wx.getStorageInfoSync().keys;
    for (var i = 0; i < keys.length; i++) {
      allData[keys[i]] = wx.getStorageSync(keys[i]);
    }
    wx.showModal({
      title: '本地存储数据',
      content: JSON.stringify(allData, null, 2),
      showCancel: false,
      confirmText: '确定'
    });
  },

  resetData: function () {
    var that = this;
    wx.showModal({
      title: '确认重置',
      content: '这将清空所有本地数据，包括喝水记录、设置等，确定要继续吗？',
      success: function (res) {
        if (res.confirm) {
          wx.clearStorageSync();
          wx.showToast({
            title: '数据已重置',
            icon: 'success'
          });
          that.loadStorageInfo();
        }
      }
    });
  },

  generateTestData: function () {
    var that = this;
    wx.showModal({
      title: '生成测试数据',
      content: '这将生成一些模拟的喝水数据用于测试，确定要继续吗？',
      success: function (res) {
        if (res.confirm) {
          // 生成测试数据
          var testData = [];
          var now = new Date();
          
          for (var i = 0; i < 10; i++) {
            var time = new Date(now.getTime() - i * 3600000); // 每小时一条
            testData.push({
              id: 'test_' + i,
              amount: Math.floor(Math.random() * 200) + 100,
              time: time.toISOString(),
              timeStr: time.toLocaleString()
            });
          }
          
          wx.setStorageSync('drinkRecords', testData);
          wx.showToast({
            title: '测试数据已生成',
            icon: 'success'
          });
          that.loadStorageInfo();
        }
      }
    });
  },

  performanceMonitor: function () {
    var performance = wx.getPerformance();
    var observer = performance.createObserver(function (entryList) {
      console.log('性能数据:', entryList);
    });
    
    observer.observe({ entryTypes: ['navigation', 'render', 'script'] });
    
    wx.showModal({
      title: '性能监控',
      content: '性能监控已启动，请查看控制台输出',
      showCancel: false,
      confirmText: '确定'
    });
  },

  exportAllData: function () {
    var allData = {};
    var keys = wx.getStorageInfoSync().keys;
    for (var i = 0; i < keys.length; i++) {
      allData[keys[i]] = wx.getStorageSync(keys[i]);
    }
    
    var dataStr = JSON.stringify(allData, null, 2);
    wx.setClipboardData({
      data: dataStr,
      success: function () {
        wx.showToast({
          title: '数据已复制到剪贴板',
          icon: 'success'
        });
      }
    });
  },

  clearAllData: function () {
    var that = this;
    wx.showModal({
      title: '确认清空',
      content: '这将清空所有数据，包括喝水记录、设置、成就等，此操作不可恢复！',
      success: function (res) {
        if (res.confirm) {
          wx.clearStorageSync();
          wx.showToast({
            title: '所有数据已清空',
            icon: 'success'
          });
          that.loadStorageInfo();
        }
      }
    });
  },

  testNotification: function () {
    wx.showToast({
      title: '测试通知',
      icon: 'success',
      duration: 2000
    });
  },

  testCloudNotification: function () {
    wx.showModal({
      title: '云通知测试',
      content: '云通知功能需要配置云开发环境，请检查云函数是否正确部署',
      showCancel: false,
      confirmText: '确定'
    });
  },

  unlockAllAchievements: function () {
    var achievements = [
      { id: 'first_drink', name: '第一次喝水', unlocked: true },
      { id: 'daily_goal', name: '达成每日目标', unlocked: true },
      { id: 'weekly_streak', name: '连续一周', unlocked: true },
      { id: 'monthly_master', name: '月度大师', unlocked: true },
      { id: 'water_expert', name: '喝水专家', unlocked: true }
    ];
    
    wx.setStorageSync('achievements', achievements);
    wx.showToast({
      title: '所有成就已解锁',
      icon: 'success'
    });
  },

  // ==================== AI功能入口 ====================
  goToChatAssistant: function() {
    wx.navigateTo({
      url: '/pages/chat-assistant/chat-assistant'
    });
  },
  
  goToApiConfig: function() {
    wx.navigateTo({
      url: '/pages/api-config/api-config'
    });
  },
 
//  goToWishWall: function() {
//    wx.navigateTo({
//      url: '/pages/wishwall/wishwall'
//   });
// },

  // ==================== 水宝助手测试功能 ====================

  // API密钥测试
  testApiKey: function () {
    var apiKey = wx.getStorageSync('deepseek_api_key');
    var status = apiKey ? '已配置' : '未配置';
    var keyPreview = apiKey ? (apiKey.substring(0, 10) + '...') : '无';
    
    wx.showModal({
      title: 'API密钥测试',
      content: '🔑 API密钥状态：' + status + '\n\n📝 密钥预览：' + keyPreview + '\n\n' + (apiKey ? '✅ 密钥已配置，可以正常使用AI功能' : '❌ 密钥未配置，请前往API配置页面设置'),
      showCancel: false,
      confirmText: '确定'
    });
  },

  // 网络连接测试
  testNetwork: function () {
    var that = this;
    wx.getNetworkType({
      success: function (res) {
        var networkType = res.networkType;
        var status = networkType === 'none' ? '❌ 无网络连接' : '✅ 网络连接正常';
        
        wx.showModal({
          title: '网络连接测试',
          content: '🌐 网络类型：' + networkType + '\n\n📊 连接状态：' + status + '\n\n' + (networkType === 'none' ? '⚠️ 请检查网络连接后重试' : '✅ 网络连接正常，可以正常使用AI功能'),
          showCancel: false,
          confirmText: '确定'
        });
      },
      fail: function (err) {
        wx.showModal({
          title: '网络连接测试失败',
          content: '❌ 无法获取网络状态\n\n错误信息：' + JSON.stringify(err),
          showCancel: false,
          confirmText: '确定'
        });
      }
    });
  },

  // Canvas测试
  testCanvas: function () {
    var that = this;
    
    // 测试文字模式Canvas
    var textQuery = wx.createSelectorQuery();
    textQuery.select('#text-mode-face').fields({ node: true, size: true }).exec(function (res) {
      var textCanvasStatus = res[0] ? '✅ 找到' : '❌ 未找到';
      
      // 测试通话模式Canvas
      var callQuery = wx.createSelectorQuery();
      callQuery.select('#call-face').fields({ node: true, size: true }).exec(function (callRes) {
        var callCanvasStatus = callRes[0] ? '✅ 找到' : '❌ 未找到';
        
        wx.showModal({
          title: 'Canvas测试',
          content: '🎨 Canvas元素状态：\n\n📝 文字模式Canvas：' + textCanvasStatus + '\n📞 通话模式Canvas：' + callCanvasStatus + '\n\n' + (res[0] && callRes[0] ? '✅ 所有Canvas元素正常' : '⚠️ 部分Canvas元素未找到，可能影响表情显示'),
          showCancel: false,
          confirmText: '确定'
        });
      });
    });
  },

  // 表情绘制测试
  testFaceDrawing: function () {
    var that = this;
    var moods = ['normal', 'happy', 'sad', 'thinking', 'surprised', 'angry', 'shy', 'sleepy'];
    var currentIndex = 0;
    
    wx.showModal({
      title: '表情绘制测试',
      content: '😊 将依次测试所有表情类型\n\n准备开始测试？',
      success: function (res) {
        if (res.confirm) {
          that.startFaceDrawingTest(moods, currentIndex);
        }
      }
    });
  },

  startFaceDrawingTest: function (moods, index) {
    var that = this;
    if (index >= moods.length) {
      wx.showModal({
        title: '表情绘制测试完成',
        content: '✅ 所有表情类型测试完成！\n\n共测试了 ' + moods.length + ' 种表情：\n' + moods.join('、'),
        showCancel: false,
        confirmText: '确定'
      });
      return;
    }
    
    var mood = moods[index];
    wx.showModal({
      title: '测试表情：' + mood,
      content: '当前测试：' + mood + '\n\n请观察表情是否正确显示',
      success: function (res) {
        // 这里可以调用水宝助手的表情绘制方法
        // 由于不在水宝助手页面，我们只能提示用户
        setTimeout(function () {
          that.startFaceDrawingTest(moods, index + 1);
        }, 1000);
      }
    });
  },

  // AI对话测试
  testAIChat: function () {
    var that = this;
    var apiKey = wx.getStorageSync('deepseek_api_key');
    
    if (!apiKey) {
      wx.showModal({
        title: 'AI对话测试失败',
        content: '❌ API密钥未配置\n\n请先前往API配置页面设置DeepSeek API密钥',
        showCancel: false,
        confirmText: '确定'
      });
      return;
    }
    
    wx.showModal({
      title: 'AI对话测试',
      content: '💬 将发送测试消息到AI\n\n消息内容：你好水宝！\n\n准备开始测试？',
      success: function (res) {
        if (res.confirm) {
          that.sendTestMessage();
        }
      }
    });
  },

  sendTestMessage: function () {
    var that = this;
    var apiKey = wx.getStorageSync('deepseek_api_key');
    
    wx.showLoading({
      title: '发送测试消息...'
    });
    
    wx.request({
      url: 'https://api.deepseek.com/chat/completions',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey
      },
      data: {
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: '你是一个可爱的喝水助手"水宝"，性格活泼、关心用户健康。请用简短、温暖、可爱的语气回复，鼓励用户多喝水。'
          },
          {
            role: 'user',
            content: '你好水宝！'
          }
        ],
        max_tokens: 100,
        temperature: 0.7,
        stream: false
      },
      success: function (res) {
        wx.hideLoading();
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message) {
          var aiContent = res.data.choices[0].message.content;
          wx.showModal({
            title: 'AI对话测试成功',
            content: '✅ AI回复正常！\n\n🤖 AI回复：' + aiContent + '\n\n📊 状态码：' + res.statusCode + '\n🔑 API密钥：正常',
            showCancel: false,
            confirmText: '确定'
          });
        } else {
          wx.showModal({
            title: 'AI对话测试失败',
            content: '❌ AI回复异常\n\n状态码：' + res.statusCode + '\n错误信息：' + JSON.stringify(res.data),
            showCancel: false,
            confirmText: '确定'
          });
        }
      },
      fail: function (err) {
        wx.hideLoading();
        wx.showModal({
          title: 'AI对话测试失败',
          content: '❌ 网络请求失败\n\n错误信息：' + JSON.stringify(err),
          showCancel: false,
          confirmText: '确定'
        });
      }
    });
  },

  // 录音功能测试
  testRecording: function () {
    var that = this;
    
    wx.showModal({
      title: '录音功能测试',
      content: '🎤 将测试录音功能\n\n注意：\n1. 需要授权录音权限\n2. 在模拟器中可能无法正常工作\n3. 建议在真机上测试\n\n准备开始测试？',
      success: function (res) {
        if (res.confirm) {
          that.startRecordingTest();
        }
      }
    });
  },

  startRecordingTest: function () {
    var that = this;
    
    // 检查录音权限
    wx.authorize({
      scope: 'scope.record',
      success: function () {
        wx.showModal({
          title: '录音权限已获取',
          content: '✅ 录音权限正常\n\n🎤 可以开始录音测试\n\n请前往水宝助手页面进行完整测试',
          showCancel: false,
          confirmText: '确定'
        });
      },
      fail: function (err) {
        wx.showModal({
          title: '录音权限获取失败',
          content: '❌ 无法获取录音权限\n\n错误信息：' + JSON.stringify(err) + '\n\n请检查：\n1. 是否允许录音权限\n2. 设备是否支持录音\n3. 微信版本是否支持',
          showCancel: false,
          confirmText: '确定'
        });
      }
    });
  },

  // ==================== 公告功能测试 ====================

  // 测试公告弹窗
  testAnnouncement: function () {
    var that = this;
    
    // 创建测试公告
    var testAnnouncement = {
      _id: 'test_' + Date.now(),
      title: '测试公告',
      content: '这是一条来自开发者模式的测试公告，用于测试公告弹窗功能。',
      createTime: new Date().toISOString(),
      createTimeStr: new Date().toLocaleString(),
      publisherOpenid: 'test_publisher',
      readCount: 0,
      isRead: false
    };
    
    wx.showModal({
      title: '测试公告弹窗',
      content: '📢 将显示测试公告弹窗\n\n公告内容：' + testAnnouncement.content + '\n\n准备显示？',
      success: function (res) {
        if (res.confirm) {
          // 触发公告弹窗
          wx.getApp().globalData.testAnnouncement = testAnnouncement;
          wx.showToast({
            title: '测试公告已触发',
            icon: 'success'
          });
        }
      }
    });
  },

  // 测试订阅消息
  testSubscribeMessage: function () {
    var that = this;
    
    wx.showModal({
      title: '测试订阅消息',
      content: '📢 将测试订阅消息功能\n\n注意：\n1. 需要用户授权\n2. 仅用于测试\n3. 不会发送实际消息\n\n准备开始测试？',
      success: function (res) {
        if (res.confirm) {
          that.requestSubscribeMessage();
        }
      }
    });
  },

  requestSubscribeMessage: function () {
    var that = this;
    
    wx.requestSubscribeMessage({
      tmplIds: ['G_pTPVTHRIVYw424X5ER4qX90g0ESYPyyvMV0fzHL8'],
      success: function (res) {
        console.log('订阅消息结果:', res);
        var result = res['G_pTPVTHRIVYw424X5ER4qX90g0ESYPyyvMV0fzHL8'];
        var status = result === 'accept' ? '✅ 已接受' : result === 'reject' ? '❌ 已拒绝' : '❓ 其他';
        
        wx.showModal({
          title: '订阅消息测试结果',
          content: '📢 订阅消息状态：' + status + '\n\n结果代码：' + result + '\n\n' + (result === 'accept' ? '✅ 订阅成功，可以接收通知' : '⚠️ 订阅失败，无法接收通知'),
          showCancel: false,
          confirmText: '确定'
        });
      },
      fail: function (err) {
        wx.showModal({
          title: '订阅消息测试失败',
          content: '❌ 订阅消息请求失败\n\n错误信息：' + JSON.stringify(err),
          showCancel: false,
          confirmText: '确定'
        });
      }
    });
  },

  // 测试云函数
  testCloudFunction: function () {
    var that = this;
    
    wx.showModal({
      title: '测试云函数',
      content: '☁️ 将测试公告相关云函数\n\n测试内容：\n1. 获取公告列表\n2. 测试云函数连接\n\n准备开始测试？',
      success: function (res) {
        if (res.confirm) {
          that.testAnnouncementCloudFunction();
        }
      }
    });
  },

  testAnnouncementCloudFunction: function () {
    var that = this;
    
    wx.showLoading({
      title: '测试云函数中...'
    });
    
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'getAll'
      },
      success: function (res) {
        wx.hideLoading();
        if (res.result && res.result.success) {
          var announcements = res.result.data || [];
          wx.showModal({
            title: '云函数测试成功',
            content: '✅ 云函数连接正常！\n\n📊 公告数量：' + announcements.length + ' 条\n\n🔗 数据库连接：正常\n\n返回数据：' + JSON.stringify(res.result, null, 2),
            showCancel: false,
            confirmText: '确定'
          });
        } else {
          wx.showModal({
            title: '云函数测试失败',
            content: '❌ 云函数返回异常\n\n错误信息：' + JSON.stringify(res.result),
            showCancel: false,
            confirmText: '确定'
          });
        }
      },
      fail: function (err) {
        wx.hideLoading();
        wx.showModal({
          title: '云函数测试失败',
          content: '❌ 云函数调用失败\n\n错误信息：' + JSON.stringify(err) + '\n\n请检查：\n1. 云开发环境是否正确配置\n2. 云函数是否已部署\n3. 网络连接是否正常',
          showCancel: false,
          confirmText: '确定'
        });
      }
    });
  },

  // 测试原设置页面
  testOriginalSettings: function () {
    wx.navigateTo({
      url: '/pages/settings/settings',
      success: function () {
        wx.showToast({
          title: '已导航到原设置页面',
          icon: 'success'
        });
      },
      fail: function (err) {
        wx.showToast({
          title: '导航失败: ' + err.errMsg,
          icon: 'error'
        });
      }
    });
  }
}); 