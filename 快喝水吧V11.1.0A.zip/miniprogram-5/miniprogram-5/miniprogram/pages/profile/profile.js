const { getCurrentTheme, switchTheme } = require('../../utils/theme.js');

Page({
  data: {
    // 用户资料
    userInfo: {
      nickName: '',
      avatarUrl: '',
      gender: '',
      age: '',
      height: '',
      weight: ''
    },
    showEditModal: false,
    editForm: {
      nickName: '',
      genderIndex: 0,
      age: '',
      height: '',
      weight: ''
    },
    genderOptions: ['男', '女', '其他'],
    
    // 统计数据
    totalDrinks: 0,
    totalWater: 0,
    streakDays: 0,
    
    // 主题相关
    pageStyle: '',
    themeOptions: [
      { label: '默认', value: 'default' },
      { label: '深色', value: 'dark' },
      { label: '蓝色', value: 'blue' },
      { label: '粉色', value: 'pink' },
      { label: '紫色', value: 'purple' }
    ],
    themeIndex: 0,
    currentThemeName: 'default',
    
    // 提醒设置
    reminderEnabled: false,
    reminderTime: '09:00',
    reminderIntervals: [30, 60, 90, 120, 180],
    reminderIntervalIndex: 1,
    startTime: '08:00',
    endTime: '22:00',
    
    // 云提醒设置
    cloudReminderEnabled: false,
    

    
    // 喝水设置
    dailyTarget: 2000,
    targetOptions: [
      { label: '1500ml', value: 1500 },
      { label: '2000ml', value: 2000 },
      { label: '2500ml', value: 2500 },
      { label: '3000ml', value: 3000 }
    ],
    targetIndex: 1,
    cupOptions: [
      { label: '小杯', value: 200 },
      { label: '中杯', value: 300 },
      { label: '大杯', value: 500 },
      { label: '超大杯', value: 750 }
    ],
    defaultCupIndex: 1,
    
    // 通知设置
    soundEnabled: true,
    vibrationEnabled: true
  },

  onLoad: function () {
    this.applyCurrentTheme();
    this.loadUserProfile();
    this.loadSettings();
    this.calculateStats();
    this.initPrivacyAuth();
    
    // 首次进入检查隐私授权
    this.checkPrivacyOnFirstLaunch();
  },

  onShow: function () {
    console.log('个人中心页面显示，开始刷新数据');
    this.applyCurrentTheme();
    this.calculateStats();
    this.loadUserProfile(); // 同时刷新用户资料
  },
  
  onPullDownRefresh: function() {
    console.log('下拉刷新');
    this.calculateStats();
    this.loadUserProfile();
    setTimeout(() => {
      wx.stopPullDownRefresh();
    }, 1000);
  },

  // 分享给好友
  onShareAppMessage: function () {
    return {
      title: '快喝水 - 我的个人中心',
      desc: '一起来养成健康的喝水习惯吧！',
      path: '/pages/profile/profile'
    };
  },

  // 分享到朋友圈
  onShareTimeline: function () {
    return {
      title: '快喝水 - 养成健康喝水习惯',
      query: '',
      imageUrl: ''
    };
  },

  // 应用当前主题
  applyCurrentTheme: function () {
    var theme = getCurrentTheme();
    this.setData({
      pageStyle: 'background: ' + theme.backgroundColor + ';'
    });
  },

  // 加载用户资料
  loadUserProfile: function () {
    var userInfo = wx.getStorageSync('userInfo') || {};
    var editForm = {
      nickName: userInfo.nickName || '',
      genderIndex: this.getGenderIndex(userInfo.gender),
      age: userInfo.age || '',
      height: userInfo.height || '',
      weight: userInfo.weight || ''
    };
    
    this.setData({
      userInfo: userInfo,
      editForm: editForm
    });
  },

  // 获取性别索引
  getGenderIndex: function (gender) {
    var index = this.data.genderOptions.indexOf(gender);
    return index >= 0 ? index : 0;
  },

  // 加载设置
  loadSettings: function () {
    var settings = wx.getStorageSync('settings') || {};
    
    this.setData({
      reminderEnabled: settings.reminderEnabled || false,
      reminderTime: settings.reminderTime || '09:00',
      reminderIntervalIndex: settings.reminderIntervalIndex || 1,
      startTime: settings.startTime || '08:00',
      endTime: settings.endTime || '22:00',
      cloudReminderEnabled: settings.cloudReminderEnabled || false,
      dailyTarget: settings.dailyTarget || 2000,
      targetIndex: this.getTargetIndex(settings.dailyTarget),
      defaultCupIndex: settings.defaultCupIndex || 1,
      soundEnabled: settings.soundEnabled !== false,
      vibrationEnabled: settings.vibrationEnabled !== false,
      themeIndex: this.getThemeIndex(settings.theme || 'default'),
      currentThemeName: settings.theme || 'default'
    });
  },

  // 获取目标索引
  getTargetIndex: function (target) {
    for (var i = 0; i < this.data.targetOptions.length; i++) {
      if (this.data.targetOptions[i].value === target) {
        return i;
      }
    }
    return 1;
  },

  // 获取主题索引
  getThemeIndex: function (theme) {
    for (var i = 0; i < this.data.themeOptions.length; i++) {
      if (this.data.themeOptions[i].value === theme) {
        return i;
      }
    }
    return 0;
  },

  // 主题选择
  onThemeSelect: function(e) {
    var index = e.currentTarget.dataset.index;
    var theme = this.data.themeOptions[index];
    
    this.setData({
      themeIndex: index
    });
    
    // 应用主题
    this.applyTheme(theme.value);
    
    // 保存主题设置
    var settings = wx.getStorageSync('settings') || {};
    settings.theme = theme.value;
    wx.setStorageSync('settings', settings);
    
    // 显示切换成功提示
    wx.showToast({
      title: '主题已切换',
      icon: 'success',
      duration: 1000
    });
  },

  // 应用主题
  applyTheme: function(themeValue) {
    // 使用统一的主题切换函数
    switchTheme(themeValue, this);
    
    // 同步到全局数据
    if (typeof getApp().globalData !== 'undefined') {
      getApp().globalData.currentTheme = themeValue;
    }
  },

  // 计算统计数据
  calculateStats: function () {
    console.log('开始计算统计数据...');
    
    // 获取按日期分组的水记录
    var waterRecords = wx.getStorageSync('waterRecords') || {};
    console.log('获取到的waterRecords:', waterRecords);
    
    var allRecords = [];
    var totalDrinks = 0;
    var totalWater = 0;
    
    // 将所有日期的记录合并到一个数组
    Object.keys(waterRecords).forEach(function(date) {
      var dayRecords = waterRecords[date] || [];
      console.log('日期', date, '的记录:', dayRecords);
      allRecords = allRecords.concat(dayRecords);
      totalDrinks += dayRecords.length;
      dayRecords.forEach(function(record) {
        totalWater += record.amount || 0;
      });
    });
    
    // 计算连续天数
    var streakDays = this.calculateStreakDays(waterRecords);
    
    console.log('统计数据计算完成:', {
      totalDrinks: totalDrinks,
      totalWater: totalWater,
      streakDays: streakDays,
      recordDates: Object.keys(waterRecords).length,
      allRecordsCount: allRecords.length
    });
    
    this.setData({
      totalDrinks: totalDrinks,
      totalWater: totalWater,
      streakDays: streakDays
    });
    
    // 显示刷新成功提示
    if (totalDrinks > 0) {
      wx.showToast({
        title: '数据已更新',
        icon: 'success',
        duration: 1000
      });
    }
  },

  // 初始化隐私授权 (使用微信官方弹窗)
  initPrivacyAuth: function() {
    // 微信会自动处理隐私授权弹窗
    // 无需自定义弹窗，只需在app.json中配置 "__usePrivacyCheck__": true
    console.log('隐私授权已启用，将使用微信官方弹窗');
  },

  // 首次进入检查隐私授权
  checkPrivacyOnFirstLaunch: function() {
    console.log('检查首次进入隐私授权');
    this.requirePrivacyAuth('首次进入个人中心');
  },

  // 主动触发隐私授权检查
  requirePrivacyAuth: function(scene) {
    if (wx.requirePrivacyAuthorize) {
      wx.requirePrivacyAuthorize({
        success: () => {
          console.log(`${scene} - 隐私授权成功`);
        },
        fail: (res) => {
          console.log(`${scene} - 隐私授权失败:`, res);
          wx.showToast({
            title: '需要授权后才能使用',
            icon: 'none'
          });
        }
      });
    }
  },

  // 计算连续天数
  calculateStreakDays: function (waterRecords) {
    var recordDates = Object.keys(waterRecords);
    if (recordDates.length === 0) return 0;
    
    // 过滤出有记录的日期
    var validDates = recordDates.filter(function(date) {
      return waterRecords[date] && waterRecords[date].length > 0;
    });
    
    if (validDates.length === 0) return 0;
    
    // 转换为时间戳并排序（最新的在前）
    var dateTimes = validDates.map(function(dateStr) {
      return new Date(dateStr).getTime();
    }).sort(function(a, b) {
      return b - a;
    });
    
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var todayTime = today.getTime();
    
    var streak = 0;
    var expectedDate = todayTime;
    
    // 从今天开始往前计算连续天数
    for (var i = 0; i < dateTimes.length; i++) {
      var diffDays = Math.floor((expectedDate - dateTimes[i]) / (1000 * 60 * 60 * 24));
      
      if (diffDays === 0) {
        // 找到连续的日期
        streak++;
        expectedDate -= 24 * 60 * 60 * 1000; // 往前推一天
      } else if (diffDays > 0) {
        // 有间隔，结束连续计数
        break;
      }
      // diffDays < 0 说明这个日期在未来，跳过
    }
    
    return streak;
  },

  // 选择头像
  chooseAvatar: function () {
    var that = this;
    
    // 触发隐私授权检查
    this.requirePrivacyAuth('选择头像');
    
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePath = res.tempFilePaths[0];
        
        // 上传到云存储
        wx.cloud.uploadFile({
          cloudPath: 'avatars/' + Date.now() + '.jpg',
          filePath: tempFilePath,
          success: function (uploadRes) {
            if (uploadRes.fileID) {
              var userInfo = that.data.userInfo;
              userInfo.avatarUrl = uploadRes.fileID;
              
              that.setData({
                userInfo: userInfo
              });
              
              wx.setStorageSync('userInfo', userInfo);
              wx.showToast({
                title: '头像更新成功',
                icon: 'success'
              });
            } else {
              wx.showToast({
                title: '上传失败: 无文件ID',
                icon: 'error'
              });
            }
          },
          fail: function (err) {
            console.error('上传头像失败:', err);
            let errorMsg = '上传失败';
            if (err.errMsg.includes('permission')) {
              errorMsg = '缺少云存储权限，请检查配置';
            } else if (err.errMsg.includes('network')) {
              errorMsg = '网络问题，请检查连接';
            }
            wx.showToast({
              title: errorMsg,
              icon: 'error'
            });
          }
        });
      },
      fail: function (err) {
        if (err.errMsg.indexOf('cancel') === -1) {
          wx.showToast({
            title: '选择图片失败',
            icon: 'error'
          });
        }
      }
    });
  },

  // 编辑昵称
  editName: function () {
    console.log('点击编辑昵称');
    
    // 触发隐私授权检查
    this.requirePrivacyAuth('编辑个人资料');
    
    this.setData({
      showEditModal: true
    });
  },

  // 关闭编辑弹窗
  closeEditModal: function () {
    this.setData({
      showEditModal: false
    });
  },

  // 昵称输入
  onNickNameInput: function (e) {
    this.setData({
      'editForm.nickName': e.detail.value
    });
  },

  // 性别选择
  onGenderChange: function (e) {
    this.setData({
      'editForm.genderIndex': e.detail.value
    });
  },

  // 年龄输入
  onAgeInput: function (e) {
    this.setData({
      'editForm.age': e.detail.value
    });
  },

  // 身高输入
  onHeightInput: function (e) {
    this.setData({
      'editForm.height': e.detail.value
    });
  },

  // 体重输入
  onWeightInput: function (e) {
    this.setData({
      'editForm.weight': e.detail.value
    });
  },

  // 保存资料
  saveProfile: function () {
    var editForm = this.data.editForm;
    var userInfo = this.data.userInfo;
    
    // 验证数据
    if (!editForm.nickName.trim()) {
      wx.showToast({
        title: '请输入昵称',
        icon: 'none'
      });
      return;
    }
    
    // 更新用户信息
    userInfo.nickName = editForm.nickName.trim();
    userInfo.gender = this.data.genderOptions[editForm.genderIndex];
    userInfo.age = editForm.age;
    userInfo.height = editForm.height;
    userInfo.weight = editForm.weight;
    
    this.setData({
      userInfo: userInfo,
      showEditModal: false
    });
    
    // 保存到本地存储
    wx.setStorageSync('userInfo', userInfo);
    
    wx.showToast({
      title: '保存成功',
      icon: 'success'
    });
  },

  // ==================== 设置功能 ====================

  // 本地提醒开关
  onReminderSwitchChange: function (e) {
    this.setData({
      reminderEnabled: e.detail.value
    });
    this.saveSettings();
  },

  // 提醒时间选择
  onTimeChange: function (e) {
    this.setData({
      reminderTime: e.detail.value
    });
    this.saveSettings();
  },

  // 提醒间隔选择
  onIntervalChange: function (e) {
    this.setData({
      reminderIntervalIndex: e.detail.value
    });
    this.saveSettings();
  },

  // 开始时间选择
  onStartTimeChange: function (e) {
    this.setData({
      startTime: e.detail.value
    });
    this.saveSettings();
  },

  // 结束时间选择
  onEndTimeChange: function (e) {
    this.setData({
      endTime: e.detail.value
    });
    this.saveSettings();
  },

  // 云提醒开关
  onCloudReminderChange: function (e) {
    this.setData({
      cloudReminderEnabled: e.detail.value
    });
    this.saveSettings();
  },

  // 订阅云提醒
  subscribeCloudReminder: function () {
    var that = this;
    wx.requestSubscribeMessage({
      tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
      success: function (res) {
        console.log('订阅结果:', res);
        wx.showToast({
          title: '订阅成功',
          icon: 'success'
        });
      },
      fail: function (err) {
        console.error('订阅失败:', err);
        wx.showToast({
          title: '订阅失败',
          icon: 'error'
        });
      }
    });
  },

  // 每日目标选择
  onDailyTargetChange: function (e) {
    var index = e.detail.value;
    var target = this.data.targetOptions[index].value;
    
    this.setData({
      targetIndex: index,
      dailyTarget: target
    });
    this.saveSettings();
  },

  // 默认杯子选择
  onDefaultCupChange: function (e) {
    this.setData({
      defaultCupIndex: e.detail.value
    });
    this.saveSettings();
  },

  // 声音开关
  onSoundChange: function (e) {
    this.setData({
      soundEnabled: e.detail.value
    });
    this.saveSettings();
  },

  // 震动开关
  onVibrationChange: function (e) {
    this.setData({
      vibrationEnabled: e.detail.value
    });
    this.saveSettings();
  },

  // 主题选择处理 (由 theme-selector 组件触发)
  onThemeChange: function (e) {
    console.log('主题切换事件:', e.detail);
    
    if (!e || !e.detail) {
      console.error('Invalid theme change event:', e);
      wx.showToast({
        title: '主题切换失败',
        icon: 'error'
      });
      return;
    }
    
    var theme = e.detail.theme;
    if (!theme) {
      console.error('Theme name is missing from event:', e.detail);
      wx.showToast({
        title: '主题参数错误',
        icon: 'error'
      });
      return;
    }
    
    var index = this.getThemeIndex(theme);
    console.log('主题索引:', index, '主题名称:', theme);
    
    this.setData({
      themeIndex: index,
      currentThemeName: theme
    });
    
    // 保存主题设置
    var settings = wx.getStorageSync('settings') || {};
    settings.theme = theme;
    wx.setStorageSync('settings', settings);
    
    // 应用主题到当前页面和全局
    this.applyTheme(theme);
    
    wx.showToast({
      title: '主题已切换',
      icon: 'success'
    });
  },

  // 预览主题
  previewTheme: function () {
    wx.navigateTo({
      url: '/pages/theme-preview/theme-preview'
    });
  },

  // 主题演示
  demoTheme: function () {
    wx.navigateTo({
      url: '/pages/theme-demo/theme-demo'
    });
  },

  // 导出数据
  exportData: function () {
    wx.showLoading({ title: '正在导出数据...' });
    
    try {
      // 收集所有数据
      var allData = {
        exportTime: new Date().toISOString(),
        version: '1.2.0',
        profile: this.data.userInfo, // Explicitly include user profile
        userInfo: this.data.userInfo,
        allSettings: this.getSettingsData(), // Explicitly include all settings
        settings: this.getSettingsData(),
        waterRecords: wx.getStorageSync('waterRecords') || {},
        drinkRecords: wx.getStorageSync('drinkRecords') || [],
        achievements: wx.getStorageSync('achievements') || [],
        userData: wx.getStorageSync('userData') || {},
        reminderSettings: wx.getStorageSync('reminderSettings') || {}
      };
      
      // 计算数据统计
      var recordCount = Object.keys(allData.waterRecords).length;
      var totalRecords = 0;
      Object.values(allData.waterRecords).forEach(function(dayRecords) {
        totalRecords += dayRecords.length;
      });
      
      var dataStr = JSON.stringify(allData, null, 2);
      var dataSize = (dataStr.length / 1024).toFixed(2);
      
      wx.hideLoading();
      
      wx.showModal({
        title: '数据导出',
        content: `导出数据统计：\n• 记录天数：${recordCount} 天\n• 喝水记录：${totalRecords} 条\n• 数据大小：${dataSize} KB\n\n数据将复制到剪贴板`,
        confirmText: '复制数据',
        cancelText: '取消',
        success: function (res) {
          if (res.confirm) {
            wx.setClipboardData({
              data: dataStr,
              success: function () {
                wx.showToast({
                  title: '数据已复制到剪贴板',
                  icon: 'success',
                  duration: 2000
                });
              },
              fail: function () {
                wx.showToast({
                  title: '复制失败，请重试',
                  icon: 'error'
                });
              }
            });
          }
        }
      });
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '导出失败：' + error.message,
        icon: 'error'
      });
    }
  },

  // 导入数据
  importData: function () {
    var that = this;
    
    wx.showModal({
      title: '数据导入',
      content: '导入将覆盖现有数据，建议先导出备份当前数据。\n\n请确保要导入的数据是从本应用导出的。',
      confirmText: '开始导入',
      cancelText: '取消',
      confirmColor: '#ff9800',
      success: function (res) {
        if (res.confirm) {
          that.showImportDataModal();
        }
      }
    });
  },

  // 显示导入数据弹窗
  showImportDataModal: function() {
    var that = this;
    
    // 先获取剪贴板数据
    wx.getClipboardData({
      success: function (res) {
        var clipboardData = res.data;
        
        // 尝试解析JSON数据
        try {
          var importData = JSON.parse(clipboardData);
          that.validateAndImportData(importData);
        } catch (error) {
          wx.showModal({
            title: '数据格式错误',
            content: '剪贴板中的数据格式不正确，请确保导入正确的数据格式。\n\n错误信息：' + error.message,
            showCancel: false,
            confirmText: '确定'
          });
        }
      },
      fail: function () {
        wx.showToast({
          title: '获取剪贴板数据失败',
          icon: 'error'
        });
      }
    });
  },

  // 验证并导入数据
  validateAndImportData: function(importData) {
    var that = this;
    
    try {
      // 验证数据结构
      if (!importData || typeof importData !== 'object') {
        throw new Error('数据格式不正确');
      }
      
      if (!importData.version) {
        throw new Error('数据版本信息缺失');
      }
      
      var recordCount = importData.waterRecords ? Object.keys(importData.waterRecords).length : 0;
      var totalRecords = 0;
      if (importData.waterRecords) {
        Object.values(importData.waterRecords).forEach(function(dayRecords) {
          if (Array.isArray(dayRecords)) {
            totalRecords += dayRecords.length;
          }
        });
      }
      
      wx.showModal({
        title: '确认导入数据',
        content: `检测到数据：\n• 版本：${importData.version}\n• 导出时间：${importData.exportTime ? new Date(importData.exportTime).toLocaleString() : '未知'}\n• 记录天数：${recordCount} 天\n• 喝水记录：${totalRecords} 条\n\n确认导入？`,
        confirmText: '确认导入',
        cancelText: '取消',
        confirmColor: '#4CAF50',
        success: function (res) {
          if (res.confirm) {
            that.performDataImport(importData);
          }
        }
      });
    } catch (error) {
      wx.showModal({
        title: '数据验证失败',
        content: '导入的数据验证失败：' + error.message,
        showCancel: false,
        confirmText: '确定'
      });
    }
  },

  // 执行数据导入
  performDataImport: function(importData) {
    var that = this;
    
    wx.showLoading({ title: '正在导入数据...' });
    
    try {
      // 导入各种数据
      if (importData.userInfo) {
        wx.setStorageSync('userInfo', importData.userInfo);
      }
      
      if (importData.waterRecords) {
        wx.setStorageSync('waterRecords', importData.waterRecords);
      }
      
      if (importData.drinkRecords) {
        wx.setStorageSync('drinkRecords', importData.drinkRecords);
      }
      
      if (importData.achievements) {
        wx.setStorageSync('achievements', importData.achievements);
      }
      
      if (importData.userData) {
        wx.setStorageSync('userData', importData.userData);
      }
      
      if (importData.reminderSettings) {
        wx.setStorageSync('reminderSettings', importData.reminderSettings);
      }
      
      // 导入设置
      if (importData.settings) {
        wx.setStorageSync('settings', importData.settings);
      }
      
      wx.hideLoading();
      
      // 重新加载数据
      that.loadUserProfile();
      that.loadSettings();
      that.calculateStats();
      
      wx.showToast({
        title: '数据导入成功',
        icon: 'success',
        duration: 2000
      });
      
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '导入失败：' + error.message,
        icon: 'error'
      });
    }
  },

  // 清除数据
  clearData: function () {
    var that = this;
    
    // 先计算要清除的数据量
    var waterRecords = wx.getStorageSync('waterRecords') || {};
    var recordCount = Object.keys(waterRecords).length;
    var totalRecords = 0;
    Object.values(waterRecords).forEach(function(dayRecords) {
      totalRecords += dayRecords.length;
    });
    
    wx.showModal({
      title: '⚠️ 危险操作',
      content: `即将清除以下数据：\n• 喝水记录：${totalRecords} 条\n• 记录天数：${recordCount} 天\n• 用户设置和资料\n• 成就数据\n\n此操作不可恢复！建议先导出备份。`,
      confirmText: '确定清除',
      cancelText: '取消',
      confirmColor: '#f44336',
      success: function (res) {
        if (res.confirm) {
          // 二次确认
          wx.showModal({
            title: '最后确认',
            content: '真的要清除所有数据吗？\n\n这是最后一次确认机会！',
            confirmText: '清除所有数据',
            cancelText: '我再想想',
            confirmColor: '#f44336',
            success: function (res2) {
              if (res2.confirm) {
                that.performDataClear();
              }
            }
          });
        }
      }
    });
  },

  // 执行数据清除
  performDataClear: function() {
    var that = this;
    
    wx.showLoading({ title: '正在清除数据...' });
    
    try {
      // 清除所有存储数据
      wx.clearStorageSync();
      
      wx.hideLoading();
      
      // 重新初始化数据
      that.setData({
        userInfo: {
          nickName: '',
          avatarUrl: '',
          gender: '',
          age: '',
          height: '',
          weight: ''
        },
        totalDrinks: 0,
        totalWater: 0,
        streakDays: 0,
        reminderEnabled: false,
        cloudReminderEnabled: false,
        dailyTarget: 2000,
        themeIndex: 0
      });
      
      // 重新加载数据
      that.loadUserProfile();
      that.loadSettings();
      that.calculateStats();
      
      wx.showToast({
        title: '所有数据已清除',
        icon: 'success',
        duration: 2000
      });
      
      // 延迟提示用户重新设置，并触发隐私授权
      setTimeout(function() {
        wx.showModal({
          title: '数据清除完成',
          content: '所有数据已清除完毕。\n\n建议您重新设置个人信息和喝水目标。',
          showCancel: false,
          confirmText: '知道了',
          success: function() {
            // 数据清除后触发隐私授权检查
            that.requirePrivacyAuth('数据清除后重新授权');
          }
        });
      }, 2500);
      
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '清除失败：' + error.message,
        icon: 'error'
      });
    }
  },

  // 检查更新
  checkUpdate: function () {
    wx.showToast({
      title: '当前已是最新版本',
      icon: 'success'
    });
  },

  // 意见反馈
  feedback: function () {
    wx.showModal({
      title: '意见反馈',
      content: '如有问题或建议，请通过以下方式联系我们：\n\n邮箱：xytx57@petalmail.com\n网站：http://njxc.xyz',
      showCancel: false
    });
  },

  // 访问官网
  visitWebsite: function () {
    wx.setClipboardData({
      data: 'http://njxc.xyz',
      success: () => {
        wx.showModal({
          title: '网站链接已复制',
          content: '网站地址已复制到剪贴板，请在浏览器中打开',
          showCancel: false
        })
      }
    })
  },

  // 关于我们
  aboutUs: function () {
    wx.showModal({
      title: '关于快喝水',
      content: '版本：1.2.0\n\n一款帮助您养成健康喝水习惯的小程序\n\n功能特色：\n• 智能提醒\n• 数据统计\n• 成就系统\n• 小游戏\n• 云同步\n• 数据导入导出\n\n开发者：奈境星辰 - 小宇同学\n\n官方网站：http://njxc.xyz',
      confirmText: '访问网站',
      success: (res) => {
        if (res.confirm) {
          this.visitWebsite()
        }
      }
    });
  },

  // 联系客服
  handleContact: function (e) {
    console.log('联系客服:', e.detail);
  },



  // 预览主题
  previewTheme: function() {
    wx.navigateTo({
      url: '/pages/theme-preview/theme-preview'
    });
  },

  // 主题演示
  demoTheme: function() {
    wx.navigateTo({
      url: '/pages/theme-demo/theme-demo'
    });
  },

  // 保存设置
  saveSettings: function () {
    var settings = this.getSettingsData();
    wx.setStorageSync('settings', settings);
  },

  // 获取设置数据
  getSettingsData: function () {
    return {
      reminderEnabled: this.data.reminderEnabled,
      reminderTime: this.data.reminderTime,
      reminderIntervalIndex: this.data.reminderIntervalIndex,
      startTime: this.data.startTime,
      endTime: this.data.endTime,
      cloudReminderEnabled: this.data.cloudReminderEnabled,
      dailyTarget: this.data.dailyTarget,
      defaultCupIndex: this.data.defaultCupIndex,
      soundEnabled: this.data.soundEnabled,
      vibrationEnabled: this.data.vibrationEnabled,
      theme: this.data.themeOptions[this.data.themeIndex].value
    };
  }
}); 