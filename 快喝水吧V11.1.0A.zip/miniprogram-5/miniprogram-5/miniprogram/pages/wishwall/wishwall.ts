Page({
  data: {
    wishList: []
  },

  onLoad() {
    this.loadWishes();
  },

  // 加载心愿列表
  loadWishes() {
    const db = wx.cloud.database();
    db.collection('wishes')
      .orderBy('createdAt', 'desc')
      .limit(50)
      .get()
      .then(res => {
        res.data.forEach(item => {
          item.createdAt = this.formatTime(item.createdAt);
        });
        this.setData({ wishList: res.data });
      });
  },

  // 提交心愿
  onWishSubmit(e: any) {
    const content = e.detail.value.wishContent.trim();
    if (!content) {
      wx.showToast({ title: '内容不能为空', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '发布中...' });
    wx.getUserProfile({
      desc: '用于心愿墙昵称头像',
      success: userRes => {
        wx.cloud.callFunction({
          name: 'addWish',
          data: {
            content,
            nickname: userRes.userInfo.nickName,
            avatarUrl: userRes.userInfo.avatarUrl
          },
          success: res => {
            wx.hideLoading();
            wx.showToast({ title: '发布成功', icon: 'success' });
            this.loadWishes();
          },
          fail: err => {
            wx.hideLoading();
            wx.showToast({ title: '发布失败', icon: 'none' });
          }
        });
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '需要授权昵称头像', icon: 'none' });
      }
    });
  },

  formatTime(date: any) {
    const d = new Date(date);
    const y = d.getFullYear();
    const m = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    const h = d.getHours().toString().padStart(2, '0');
    const min = d.getMinutes().toString().padStart(2, '0');
    return `${y}-${m}-${day} ${h}:${min}`;
  },

  onShareAppMessage() {
    return {
      title: '快来心愿墙许下你的心愿吧！',
      path: '/pages/wishwall/wishwall'
    }
  },

  onShareTimeline() {
    return {
      title: '快来心愿墙许下你的心愿吧！',
      path: '/pages/wishwall/wishwall'
    }
  }
}); 