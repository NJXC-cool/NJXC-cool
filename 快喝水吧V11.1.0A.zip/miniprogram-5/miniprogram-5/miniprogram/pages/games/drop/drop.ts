Page({
  data: {
    drops: [] as any[],
    playerX: 300,
    score: 0,
    level: 1,
    gameTime: 0,
    gameTimer: null as any,
    dropTimer: null as any,
    isPaused: false,
    showResult: false,
    gameWon: false,
    showInstructions: true,
    dropId: 0,
    screenWidth: 750
  },

  onLoad() {
    this.applyCurrentTheme();
    this.initGame();
    this.getScreenWidth();
  },

  onShow() {
    this.applyCurrentTheme();
  },

  onUnload() {
    this.clearAllTimers();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 获取屏幕宽度
  getScreenWidth() {
    const systemInfo = wx.getSystemInfoSync();
    this.setData({
      screenWidth: systemInfo.windowWidth * 2 // 转换为rpx
    });
  },

  // 初始化游戏
  initGame() {
    this.setData({
      drops: [],
      playerX: 300,
      score: 0,
      level: 1,
      gameTime: 0,
      dropId: 0,
      showResult: false,
      gameWon: false
    });
  },

  // 开始游戏
  startGame() {
    this.setData({ showInstructions: false });
    this.startTimers();
  },

  // 隐藏说明
  hideInstructions() {
    this.setData({ showInstructions: false });
    this.startTimers();
  },

  // 开始计时器
  startTimers() {
    // 游戏时间计时器
    const gameTimer = setInterval(() => {
      if (!this.data.isPaused) {
        this.setData({
          gameTime: this.data.gameTime + 1
        });
        
        // 每30秒升级一次
        if (this.data.gameTime % 30 === 0) {
          this.levelUp();
        }
      }
    }, 1000);
    
    // 水滴生成计时器
    const dropTimer = setInterval(() => {
      if (!this.data.isPaused) {
        this.generateDrop();
      }
    }, 2000 - this.data.level * 100); // 随等级加快
    
    this.setData({ gameTimer, dropTimer });
  },

  // 生成水滴
  generateDrop() {
    const dropTypes = [
      { type: 'normal', emoji: '💧', points: 10 },
      { type: 'golden', emoji: '🌟', points: 50 },
      { type: 'dangerous', emoji: '💥', points: -20 }
    ];
    
    // 根据等级调整水滴类型概率
    const random = Math.random();
    let dropType;
    
    if (random < 0.7) {
      dropType = dropTypes[0]; // 普通水滴 70%
    } else if (random < 0.85) {
      dropType = dropTypes[1]; // 金色水滴 15%
    } else {
      dropType = dropTypes[2]; // 危险水滴 15%
    }
    
    const newDrop = {
      id: this.data.dropId,
      x: Math.random() * (this.data.screenWidth - 120),
      y: -60,
      type: dropType.type,
      emoji: dropType.emoji,
      points: dropType.points
    };
    
    this.setData({
      drops: [...this.data.drops, newDrop],
      dropId: this.data.dropId + 1
    });
    
    // 3秒后移除水滴
    setTimeout(() => {
      this.removeDrop(newDrop.id);
    }, 3000);
  },

  // 移除水滴
  removeDrop(dropId: number) {
    const updatedDrops = this.data.drops.filter(drop => drop.id !== dropId);
    this.setData({ drops: updatedDrops });
  },

  // 升级
  levelUp() {
    this.setData({
      level: this.data.level + 1
    });
    
    wx.showToast({
      title: `升级到 ${this.data.level} 级！`,
      icon: 'success',
      duration: 1500
    });
  },

  // 触摸开始
  onTouchStart(e: any) {
    this.touchStartX = e.touches[0].clientX;
  },

  // 触摸移动
  onTouchMove(e: any) {
    if (!this.touchStartX) return;
    
    const touchX = e.touches[0].clientX;
    const deltaX = touchX - this.touchStartX;
    
    let newX = this.data.playerX + deltaX * 2; // 转换为rpx
    
    // 限制在屏幕范围内
    newX = Math.max(40, Math.min(newX, this.data.screenWidth - 120));
    
    this.setData({ playerX: newX });
    this.touchStartX = touchX;
    
    // 检查碰撞
    this.checkCollisions();
  },

  // 检查碰撞
  checkCollisions() {
    const playerLeft = this.data.playerX;
    const playerRight = this.data.playerX + 80;
    const playerTop = 720; // 杯子底部位置
    const playerBottom = 800;
    
    const updatedDrops = this.data.drops.filter(drop => {
      const dropLeft = drop.x;
      const dropRight = drop.x + 60;
      const dropTop = drop.y;
      const dropBottom = drop.y + 60;
      
      // 检查碰撞
      if (dropLeft < playerRight && dropRight > playerLeft &&
          dropTop < playerBottom && dropBottom > playerTop) {
        
        // 碰撞发生，处理得分
        this.handleDropCollision(drop);
        return false; // 移除水滴
      }
      
      return true;
    });
    
    this.setData({ drops: updatedDrops });
  },

  // 处理水滴碰撞
  handleDropCollision(drop: any) {
    const newScore = this.data.score + drop.points;
    
    this.setData({ score: Math.max(0, newScore) });
    
    // 显示得分提示
    wx.showToast({
      title: drop.points > 0 ? `+${drop.points}` : `${drop.points}`,
      icon: 'none',
      duration: 500
    });
    
    // 如果分数降到0，游戏结束
    if (newScore <= 0) {
      this.gameOver();
    }
  },

  // 游戏结束
  gameOver() {
    this.clearAllTimers();
    
    this.setData({
      showResult: true,
      gameWon: false
    });
    
    this.saveGameRecord();
  },

  // 清除所有计时器
  clearAllTimers() {
    if (this.data.gameTimer) {
      clearInterval(this.data.gameTimer);
    }
    if (this.data.dropTimer) {
      clearInterval(this.data.dropTimer);
    }
  },

  // 保存游戏记录
  saveGameRecord() {
    try {
      const gameRecords = wx.getStorageSync('dropGameRecords') || [];
      const newRecord = {
        date: new Date().toISOString(),
        time: this.data.gameTime,
        score: this.data.score,
        level: this.data.level
      };
      
      gameRecords.push(newRecord);
      gameRecords.sort((a: any, b: any) => b.score - a.score);
      
      // 只保留前10条记录
      const topRecords = gameRecords.slice(0, 10);
      wx.setStorageSync('dropGameRecords', topRecords);
    } catch (error) {
      console.error('保存游戏记录失败:', error);
    }
  },

  // 重新开始游戏
  restartGame() {
    this.clearAllTimers();
    this.setData({ showResult: false });
    this.initGame();
    this.startTimers();
  },

  // 暂停/继续游戏
  togglePause() {
    this.setData({ isPaused: !this.data.isPaused });
  },

  // 分享结果
  shareResult() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 格式化时间
  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: `我在接住水滴游戏中获得了${this.data.score}分！`,
      path: '/pages/games/drop/drop'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: `我在接住水滴游戏中获得了${this.data.score}分！`,
      path: '/pages/games/drop/drop'
    }
  }
}); 