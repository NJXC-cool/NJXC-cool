Page({
  data: {
    score: 0,
    timeLeft: 30,
    dropX: 0,
    dropY: 0,
    bucketX: 0,
    gameStarted: false,
    gameOver: false,
    dropInterval: null,
    timerInterval: null
  },

  onLoad() {
    // 初始化桶的位置
    this.setData({
      bucketX: 300
    });
  },

  onUnload() {
    this.clearIntervals();
  },

  startGame() {
    this.setData({
      gameStarted: true,
      score: 0,
      timeLeft: 30,
      gameOver: false
    });
    
    this.startDrop();
    this.startTimer();
  },

  startDrop() {
    const dropInterval = setInterval(() => {
      if (this.data.gameOver) {
        clearInterval(dropInterval);
        return;
      }
      
      // 随机生成水滴位置
      const dropX = Math.random() * 600;
      this.setData({
        dropX,
        dropY: 0
      });
      
      // 水滴下落动画
      const fallInterval = setInterval(() => {
        if (this.data.gameOver) {
          clearInterval(fallInterval);
          return;
        }
        
        const newY = this.data.dropY + 20;
        this.setData({ dropY: newY });
        
        // 检查是否落地
        if (newY >= 500) {
          clearInterval(fallInterval);
          this.gameOver();
        }
      }, 100);
    }, 2000);
    
    this.setData({ dropInterval });
  },

  startTimer() {
    const timerInterval = setInterval(() => {
      if (this.data.gameOver) {
        clearInterval(timerInterval);
        return;
      }
      
      const newTime = this.data.timeLeft - 1;
      this.setData({ timeLeft: newTime });
      
      if (newTime <= 0) {
        clearInterval(timerInterval);
        this.gameOver();
      }
    }, 1000);
    
    this.setData({ timerInterval });
  },

  catchDrop(e) {
    if (this.data.gameOver || !this.data.gameStarted) return;
    
    const touchX = e.detail.x;
    const bucketLeft = this.data.bucketX;
    const bucketRight = bucketLeft + 60;
    
    // 检查是否接住水滴
    if (this.data.dropY >= 450 && this.data.dropY <= 500) {
      if (touchX >= bucketLeft && touchX <= bucketRight) {
        this.setData({
          score: this.data.score + 10,
          dropY: 600 // 隐藏水滴
        });
        
        wx.vibrateShort({ type: 'light' });
        wx.showToast({
          title: '+10分',
          icon: 'success',
          duration: 500
        });
      }
    }
  },

  gameOver() {
    this.clearIntervals();
    this.setData({ gameOver: true });
    
    wx.showModal({
      title: '游戏结束',
      content: `你的得分是: ${this.data.score}分`,
      showCancel: false,
      confirmText: '确定'
    });
  },

  restartGame() {
    this.startGame();
  },

  clearIntervals() {
    if (this.data.dropInterval) {
      clearInterval(this.data.dropInterval);
    }
    if (this.data.timerInterval) {
      clearInterval(this.data.timerInterval);
    }
  }
}); 