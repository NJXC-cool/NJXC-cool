Page({
  data: {},
  
  goToQuiz() {
    wx.navigateTo({
      url: '/pages/games/quiz/quiz'
    });
  },
  
  goToDrop() {
    wx.navigateTo({
      url: '/pages/games/drop/drop'
    });
  },
  
  goToMemory() {
    wx.navigateTo({
      url: '/pages/games/memory/memory'
    });
  }
}); 