Page({
  data: {
    score: 0,
    currentQuestionIndex: 0,
    currentQuestion: null,
    selectedAnswer: null,
    showResult: false,
    isCorrect: false,
    gameOver: false,
    questions: [
      {
        question: "每天应该喝多少水？",
        options: ["500ml", "1000ml", "1500-2000ml", "3000ml"],
        correct: 2,
        explanation: "成年人每天建议喝1500-2000ml水，具体根据体重、运动量、气候等调整。"
      },
      {
        question: "什么时候喝水最好？",
        options: ["口渴时", "少量多次", "一次性大量", "睡前大量"],
        correct: 1,
        explanation: "喝水要少量多次，避免一次性大量饮水，养成主动饮水习惯。"
      },
      {
        question: "运动后应该怎么喝水？",
        options: ["立即大量喝水", "等口渴再喝", "少量多次补充", "不喝水"],
        correct: 2,
        explanation: "运动后要及时补充水分，但要少量多次，避免脱水。"
      },
      {
        question: "什么水最适合日常饮用？",
        options: ["含糖饮料", "白开水", "咖啡", "酒"],
        correct: 1,
        explanation: "多喝白开水，少喝含糖饮料，白开水是最健康的饮品。"
      },
      {
        question: "早晨起床后应该做什么？",
        options: ["立即吃饭", "先喝一杯温水", "直接运动", "继续睡觉"],
        correct: 1,
        explanation: "每天早晨起床后先喝一杯温水，有助于激活身体代谢。"
      }
    ]
  },

  onLoad() {
    this.startGame();
  },

  startGame() {
    this.setData({
      score: 0,
      currentQuestionIndex: 0,
      selectedAnswer: null,
      showResult: false,
      gameOver: false
    });
    this.loadQuestion();
  },

  loadQuestion() {
    const { questions, currentQuestionIndex } = this.data;
    if (currentQuestionIndex < questions.length) {
      this.setData({
        currentQuestion: questions[currentQuestionIndex],
        selectedAnswer: null,
        showResult: false
      });
    } else {
      this.setData({ gameOver: true });
    }
  },

  selectAnswer(e) {
    if (this.data.showResult) return;
    const index = e.currentTarget.dataset.index;
    this.setData({ selectedAnswer: index });
  },

  submitAnswer() {
    if (this.data.selectedAnswer === null) return;
    
    const { currentQuestion, selectedAnswer } = this.data;
    const isCorrect = selectedAnswer === currentQuestion.correct;
    
    this.setData({
      showResult: true,
      isCorrect,
      score: this.data.score + (isCorrect ? 10 : 0)
    });
  },

  nextQuestion() {
    this.setData({
      currentQuestionIndex: this.data.currentQuestionIndex + 1
    });
    this.loadQuestion();
  },

  restartGame() {
    this.startGame();
  }
}); 