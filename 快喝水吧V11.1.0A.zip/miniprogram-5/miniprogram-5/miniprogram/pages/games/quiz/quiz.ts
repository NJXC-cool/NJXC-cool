Page({
  data: {
    questions: [
      { q: '成年人每天建议喝多少水？', a: ['500ml', '1500ml', '2000ml'], correct: 2 },
      { q: '喝水最好的时间是？', a: ['饭前', '饭后', '渴了再喝'], correct: 0 },
      { q: '人体含水量约占体重的？', a: ['30%', '50%', '60%'], correct: 2 }
    ],
    current: 0,
    score: 0,
    finished: false,
    selected: null
  },

  onLoad() {},

  selectAnswer(e: any) {
    const idx = e.currentTarget.dataset.idx;
    const { current, questions, score, finished } = this.data;
    if (finished) return;
    this.setData({ selected: idx });
    setTimeout(() => {
      let newScore = score;
      if (idx === questions[current].correct) newScore++;
      if (current + 1 < questions.length) {
        this.setData({
          current: current + 1,
          score: newScore,
          selected: null
        });
      } else {
        this.setData({
          score: newScore,
          finished: true
        });
      }
    }, 500);
  },

  restart() {
    this.setData({
      current: 0,
      score: 0,
      finished: false,
      selected: null
    });
  },

  onShareAppMessage() {
    return {
      title: '健康知识问答挑战，快来测试你的健康常识！',
      path: '/pages/games/quiz/quiz'
    }
  },
  onShareTimeline() {
    return {
      title: '健康知识问答挑战，快来测试你的健康常识！',
      path: '/pages/games/quiz/quiz'
    }
  }
}); 