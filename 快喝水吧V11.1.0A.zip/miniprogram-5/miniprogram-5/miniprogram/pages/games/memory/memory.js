Page({
  data: {
    score: 0,
    level: 1,
    cups: [
      { icon: '🥤', show: false, clicked: false },
      { icon: '☕', show: false, clicked: false },
      { icon: '🥛', show: false, clicked: false },
      { icon: '🍶', show: false, clicked: false },
      { icon: '🥃', show: false, clicked: false },
      { icon: '🧃', show: false, clicked: false }
    ],
    sequence: [],
    currentIndex: 0,
    gamePhase: 'show', // 'show' 或 'play'
    gameStarted: false,
    gameOver: false
  },

  onLoad() {
    this.initCups();
  },

  initCups() {
    const cups = this.data.cups.map(cup => ({
      ...cup,
      show: false,
      clicked: false
    }));
    this.setData({ cups });
  },

  startGame() {
    this.setData({
      gameStarted: true,
      score: 0,
      level: 1,
      gameOver: false
    });
    this.nextLevel();
  },

  nextLevel() {
    this.setData({
      currentIndex: 0,
      gamePhase: 'show'
    });
    
    // 生成新的序列
    const sequence = [];
    for (let i = 0; i < this.data.level + 2; i++) {
      sequence.push(Math.floor(Math.random() * 6));
    }
    
    this.setData({ sequence });
    this.showSequence();
  },

  showSequence() {
    let index = 0;
    const showNext = () => {
      if (index >= this.data.sequence.length) {
        this.setData({ gamePhase: 'play' });
        this.resetCups();
        return;
      }
      
      const cupIndex = this.data.sequence[index];
      const cups = [...this.data.cups];
      cups[cupIndex].show = true;
      
      this.setData({ cups });
      
      setTimeout(() => {
        cups[cupIndex].show = false;
        this.setData({ cups });
        index++;
        showNext();
      }, 800);
    };
    
    showNext();
  },

  resetCups() {
    const cups = this.data.cups.map(cup => ({
      ...cup,
      show: false,
      clicked: false
    }));
    this.setData({ cups });
  },

  clickCup(e) {
    if (this.data.gamePhase !== 'play' || this.data.gameOver) return;
    
    const clickedIndex = e.currentTarget.dataset.index;
    const expectedIndex = this.data.sequence[this.data.currentIndex];
    
    if (clickedIndex === expectedIndex) {
      // 正确点击
      const cups = [...this.data.cups];
      cups[clickedIndex].clicked = true;
      this.setData({ cups });
      
      this.setData({
        currentIndex: this.data.currentIndex + 1
      });
      
      wx.vibrateShort({ type: 'light' });
      
      // 检查是否完成当前关卡
      if (this.data.currentIndex >= this.data.sequence.length) {
        this.setData({
          score: this.data.score + this.data.level * 10
        });
        
        wx.showToast({
          title: `+${this.data.level * 10}分`,
          icon: 'success'
        });
        
        setTimeout(() => {
          this.setData({ level: this.data.level + 1 });
          this.nextLevel();
        }, 1000);
      }
    } else {
      // 错误点击
      this.gameOver();
    }
  },

  gameOver() {
    this.setData({ gameOver: true });
    
    wx.showModal({
      title: '游戏结束',
      content: `你的得分是: ${this.data.score}分`,
      showCancel: false,
      confirmText: '确定'
    });
  },

  restartGame() {
    this.initCups();
    this.setData({
      gameStarted: false,
      gameOver: false,
      score: 0,
      level: 1,
      sequence: [],
      currentIndex: 0,
      gamePhase: 'show'
    });
  }
}); 