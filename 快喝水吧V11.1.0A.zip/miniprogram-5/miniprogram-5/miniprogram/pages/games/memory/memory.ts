Page({
  data: {
    cards: [] as any[],
    flippedCards: [] as any[],
    matchedPairs: 0,
    totalPairs: 8,
    moves: 0,
    score: 0,
    gameTime: 0,
    gameTimer: null as any,
    isPaused: false,
    showResult: false,
    gameWon: false,
    showInstructions: true
  },

  onLoad() {
    this.applyCurrentTheme();
    this.initGame();
  },

  onShow() {
    this.applyCurrentTheme();
  },

  onUnload() {
    if (this.data.gameTimer) {
      clearInterval(this.data.gameTimer);
    }
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 初始化游戏
  initGame() {
    const emojis = ['💧', '🌊', '💦', '🚰', '🥤', '☕', '🍵', '🥛'];
    const cards = [];
    
    // 创建卡片对
    for (let i = 0; i < this.data.totalPairs; i++) {
      const emoji = emojis[i];
      cards.push(
        { id: i * 2, emoji, isFlipped: false, isMatched: false },
        { id: i * 2 + 1, emoji, isFlipped: false, isMatched: false }
      );
    }
    
    // 随机打乱卡片
    for (let i = cards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    
    this.setData({
      cards,
      flippedCards: [],
      matchedPairs: 0,
      moves: 0,
      score: 0,
      gameTime: 0,
      showResult: false,
      gameWon: false
    });
  },

  // 开始游戏
  startGame() {
    this.setData({ showInstructions: false });
    this.startTimer();
  },

  // 隐藏说明
  hideInstructions() {
    this.setData({ showInstructions: false });
    this.startTimer();
  },

  // 开始计时器
  startTimer() {
    const timer = setInterval(() => {
      if (!this.data.isPaused) {
        this.setData({
          gameTime: this.data.gameTime + 1
        });
      }
    }, 1000);
    
    this.setData({ gameTimer: timer });
  },

  // 点击卡片
  onCardTap(e: any) {
    const { id } = e.currentTarget.dataset;
    const card = this.data.cards.find(c => c.id === id);
    
    if (!card || card.isFlipped || card.isMatched || this.data.isPaused) {
      return;
    }
    
    // 翻卡片
    const updatedCards = this.data.cards.map(c => 
      c.id === id ? { ...c, isFlipped: true } : c
    );
    
    this.setData({
      cards: updatedCards,
      flippedCards: [...this.data.flippedCards, card]
    });
    
    // 检查是否配对
    if (this.data.flippedCards.length === 1) {
      // 等待第二张卡片
      return;
    }
    
    // 检查配对
    this.checkMatch();
  },

  // 检查配对
  checkMatch() {
    const [card1, card2] = this.data.flippedCards;
    const isMatch = card1.emoji === card2.emoji;
    
    this.setData({ moves: this.data.moves + 1 });
    
    if (isMatch) {
      // 配对成功
      const updatedCards = this.data.cards.map(c => 
        c.id === card1.id || c.id === card2.id 
          ? { ...c, isMatched: true } 
          : c
      );
      
      this.setData({
        cards: updatedCards,
        flippedCards: [],
        matchedPairs: this.data.matchedPairs + 1,
        score: this.data.score + 100
      });
      
      // 检查游戏是否完成
      if (this.data.matchedPairs + 1 >= this.data.totalPairs) {
        this.gameComplete();
      }
    } else {
      // 配对失败
      setTimeout(() => {
        const updatedCards = this.data.cards.map(c => 
          c.id === card1.id || c.id === card2.id 
            ? { ...c, isFlipped: false } 
            : c
        );
        
        this.setData({
          cards: updatedCards,
          flippedCards: [],
          score: Math.max(0, this.data.score - 10)
        });
      }, 1000);
    }
  },

  // 游戏完成
  gameComplete() {
    if (this.data.gameTimer) {
      clearInterval(this.data.gameTimer);
    }
    
    this.setData({
      showResult: true,
      gameWon: true
    });
    
    // 保存游戏记录
    this.saveGameRecord();
  },

  // 保存游戏记录
  saveGameRecord() {
    try {
      const gameRecords = wx.getStorageSync('memoryGameRecords') || [];
      const newRecord = {
        date: new Date().toISOString(),
        time: this.data.gameTime,
        moves: this.data.moves,
        score: this.data.score
      };
      
      gameRecords.push(newRecord);
      gameRecords.sort((a: any, b: any) => b.score - a.score);
      
      // 只保留前10条记录
      const topRecords = gameRecords.slice(0, 10);
      wx.setStorageSync('memoryGameRecords', topRecords);
    } catch (error) {
      console.error('保存游戏记录失败:', error);
    }
  },

  // 重新开始游戏
  restartGame() {
    if (this.data.gameTimer) {
      clearInterval(this.data.gameTimer);
    }
    
    this.setData({ showResult: false });
    this.initGame();
    this.startTimer();
  },

  // 暂停/继续游戏
  togglePause() {
    this.setData({ isPaused: !this.data.isPaused });
  },

  // 分享结果
  shareResult() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 格式化时间
  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: `我在喝水记忆游戏中获得了${this.data.score}分！`,
      path: '/pages/games/memory/memory'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: `我在喝水记忆游戏中获得了${this.data.score}分！`,
      path: '/pages/games/memory/memory'
    }
  }
}); 