// pages/announcement/announcement.ts
interface Announcement {
  _id: string;
  title: string;
  content: string;
  createTime: Date;
  createTimeStr: string;
  isRead: boolean;
}

interface NewAnnouncement {
  title: string;
  content: string;
  password: string;
}

Page({
  data: {
    announcements: [] as Announcement[],
    showAddModal: false,
    showDetailModal: false,
    showDeleteModal: false,
    currentAnnouncement: {} as Announcement,
    deleteAnnouncement: {} as Announcement,
    deletePassword: '',
    newAnnouncement: {
      title: '',
      content: '',
      password: ''
    } as NewAnnouncement
  },

  onLoad() {
    console.log('公告页面加载');
    this.loadAnnouncements();
    this.applyCurrentTheme();
  },

  onShow() {
    console.log('公告页面显示');
    this.loadAnnouncements();
    this.applyCurrentTheme();
  },

  // 应用当前主题
  applyCurrentTheme() {
    const { getCurrentTheme } = require('../../utils/theme.js');
    const theme = getCurrentTheme();
    this.setData({
      pageStyle: `background: ${theme.backgroundColor}; min-height: 100vh;`
    });
  },

  // 分享给好友
  onShareAppMessage() {
    return {
      title: '快喝水 - 公告中心',
      desc: '查看最新的应用公告和通知',
      path: '/pages/announcement/announcement'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '快喝水 - 公告中心',
      query: '',
      imageUrl: ''
    };
  },

  // 加载公告列表
  loadAnnouncements() {
    console.log('开始加载公告列表');
    wx.showLoading({ title: '加载中...' });
    
    // 先检查云开发是否初始化
    if (!wx.cloud) {
      console.error('云开发未初始化');
      wx.hideLoading();
      wx.showToast({ title: '云开发未初始化', icon: 'error' });
      return;
    }
    
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'getAll'
      },
      success: (res: any) => {
        console.log('云函数调用成功:', res);
        wx.hideLoading();
        if (res.result && res.result.success) {
          const announcements = res.result.data.map((item: any) => ({
            ...item,
            createTimeStr: this.formatTime(item.createTime)
          }));
          console.log('处理后的公告数据:', announcements);
          this.setData({ announcements });
        } else {
          console.error('云函数返回错误:', res.result);
          wx.showToast({ title: res.result?.error || '加载失败', icon: 'error' });
        }
      },
      fail: (err: any) => {
        console.error('云函数调用失败:', err);
        wx.hideLoading();
        wx.showToast({ title: '网络错误，请检查云函数是否部署', icon: 'error' });
      }
    });
  },

  // 格式化时间
  formatTime(date: Date): string {
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    
    if (diff < 60000) { // 1分钟内
      return '刚刚';
    } else if (diff < 3600000) { // 1小时内
      return Math.floor(diff / 60000) + '分钟前';
    } else if (diff < 86400000) { // 1天内
      return Math.floor(diff / 3600000) + '小时前';
    } else {
      return d.toLocaleDateString();
    }
  },

  // 显示发布弹窗
  showAddModal() {
    this.setData({ 
      showAddModal: true,
      newAnnouncement: { title: '', content: '', password: '' }
    });
  },

  // 隐藏发布弹窗
  hideAddModal() {
    this.setData({ showAddModal: false });
  },

  // 显示详情弹窗
  showDetailModal(announcement: Announcement) {
    this.setData({ 
      showDetailModal: true,
      currentAnnouncement: announcement
    });
  },

  // 隐藏详情弹窗
  hideDetailModal() {
    this.setData({ showDetailModal: false });
  },

  // 显示删除弹窗
  showDeleteModal(e: any) {
    const { id, title } = e.currentTarget.dataset;
    this.setData({ 
      showDeleteModal: true,
      deleteAnnouncement: { _id: id, title } as any,
      deletePassword: ''
    });
  },

  // 隐藏删除弹窗
  hideDeleteModal() {
    this.setData({ showDeleteModal: false });
  },

  // 阻止事件冒泡
  stopPropagation() {
    // 阻止事件冒泡
  },

  // 输入处理
  onTitleInput(e: any) {
    this.setData({
      'newAnnouncement.title': e.detail.value
    });
  },

  onContentInput(e: any) {
    this.setData({
      'newAnnouncement.content': e.detail.value
    });
  },

  onPasswordInput(e: any) {
    this.setData({
      'newAnnouncement.password': e.detail.value
    });
  },

  // 发布公告
  publishAnnouncement() {
    const { title, content, password } = this.data.newAnnouncement;
    
    if (!title.trim()) {
      wx.showToast({ title: '请输入标题', icon: 'none' });
      return;
    }
    
    if (!content.trim()) {
      wx.showToast({ title: '请输入内容', icon: 'none' });
      return;
    }
    
    if (!password.trim()) {
      wx.showToast({ title: '请输入密码', icon: 'none' });
      return;
    }

    console.log('开始发布公告:', { title, content, password: '***' });
    wx.showLoading({ title: '发布中...' });
    
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'add',
        data: { title, content, password }
      },
      success: (res: any) => {
        console.log('发布公告响应:', res);
        wx.hideLoading();
        if (res.result && res.result.success) {
          wx.showToast({ title: '发布成功', icon: 'success' });
          this.hideAddModal();
          this.loadAnnouncements();
          
          // 发布成功后，提醒用户订阅消息
          this.requestSubscribeMessage();
        } else {
          wx.showToast({ title: res.result?.error || '发布失败', icon: 'error' });
        }
      },
      fail: (err: any) => {
        console.error('发布公告失败:', err);
        wx.hideLoading();
        wx.showToast({ title: '发布失败，请检查网络', icon: 'error' });
      }
    });
  },



  // 请求订阅消息权限
  requestSubscribeMessage() {
    console.log('开始请求订阅消息权限');
    
    // 延迟一下再请求，确保页面完全加载
    setTimeout(() => {
      wx.requestSubscribeMessage({
        tmplIds: ['-G_pTPVTHRIVYw424X5ER4qX90g0ESYPyyvMV0fzHL8'],
        success: (res: any) => {
          console.log('订阅消息结果:', res);
          const templateId = '-G_pTPVTHRIVYw424X5ER4qX90g0ESYPyyvMV0fzHL8';
          
          if (res[templateId] === 'accept') {
            wx.showToast({ 
              title: '订阅成功！您将收到已读提醒', 
              icon: 'success',
              duration: 2000
            });
            console.log('用户接受了订阅消息');
          } else if (res[templateId] === 'reject') {
            wx.showToast({ 
              title: '您拒绝了订阅，将无法收到已读提醒', 
              icon: 'none',
              duration: 2000
            });
            console.log('用户拒绝了订阅消息');
          } else if (res[templateId] === 'ban') {
            wx.showToast({ 
              title: '订阅消息被禁用，将无法收到已读提醒', 
              icon: 'none',
              duration: 2000
            });
            console.log('订阅消息被禁用');
          } else {
            wx.showToast({ 
              title: '订阅失败，将无法收到已读提醒', 
              icon: 'none',
              duration: 2000
            });
            console.log('订阅消息失败，状态:', res[templateId]);
          }
        },
        fail: (err: any) => {
          console.error('订阅消息请求失败:', err);
          wx.showToast({ 
            title: '订阅失败，将无法收到已读提醒', 
            icon: 'none',
            duration: 2000
          });
        }
      });
    }, 500);
  },

  // 查看公告详情
  viewAnnouncement(e: any) {
    const { id, item } = e.currentTarget.dataset;
    const announcement = { ...item };
    
    console.log('查看公告:', announcement);
    
    // 标记为已读
    if (!announcement.isRead) {
      wx.cloud.callFunction({
        name: 'announcement',
        data: {
          action: 'markAsRead',
          data: { id }
        },
        success: (res: any) => {
          console.log('标记已读响应:', res);
          if (res.result && res.result.success) {
            // 更新本地数据
            const announcements = this.data.announcements.map(item => 
              item._id === id ? { ...item, isRead: true } : item
            );
            this.setData({ announcements });
            
            // 显示已读提示
            wx.showToast({
              title: '已读+1！',
              icon: 'success',
              duration: 1500
            });
          }
        },
        fail: (err: any) => {
          console.error('标记已读失败:', err);
        }
      });
    }
    
    this.showDetailModal(announcement);
  },

  // 删除密码输入处理
  onDeletePasswordInput(e: any) {
    this.setData({
      deletePassword: e.detail.value
    });
  },

  // 确认删除
  confirmDelete() {
    const { deletePassword, deleteAnnouncement } = this.data;
    
    if (!deletePassword.trim()) {
      wx.showToast({ title: '请输入删除密码', icon: 'none' });
      return;
    }

    console.log('开始删除公告:', { id: deleteAnnouncement._id, password: '***' });
    wx.showLoading({ title: '删除中...' });
    
    wx.cloud.callFunction({
      name: 'announcement',
      data: {
        action: 'delete',
        data: { 
          id: deleteAnnouncement._id, 
          password: deletePassword 
        }
      },
      success: (res: any) => {
        console.log('删除公告响应:', res);
        wx.hideLoading();
        if (res.result && res.result.success) {
          wx.showToast({ title: '删除成功', icon: 'success' });
          this.hideDeleteModal();
          this.loadAnnouncements();
        } else {
          wx.showToast({ title: res.result?.error || '删除失败', icon: 'error' });
        }
      },
      fail: (err: any) => {
        console.error('删除公告失败:', err);
        wx.hideLoading();
        wx.showToast({ title: '删除失败，请检查网络', icon: 'error' });
      }
    });
  }
}); 