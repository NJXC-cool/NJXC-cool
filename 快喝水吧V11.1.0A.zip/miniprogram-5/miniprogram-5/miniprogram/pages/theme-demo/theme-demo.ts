import { themes, getCurrentTheme, switchTheme } from '../../utils/theme'

Page({
  data: {
    themes: themes,
    currentTheme: 'default',
    pageStyle: ''
  },

  onLoad() {
    const currentTheme = getCurrentTheme();
    this.setData({
      currentTheme: currentTheme.name,
      pageStyle: `background: ${currentTheme.backgroundColor};`
    });
  },

  switchTheme(e: any) {
    const themeName = e.currentTarget.dataset.theme;
    const themeIndex = themes.findIndex(t => t.name === themeName);
    
    if (themeIndex >= 0) {
      this.setData({ currentTheme: themeName });
      switchTheme(themeIndex, this);
    }
  }
}) 