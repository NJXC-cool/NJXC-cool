import { apiService, type LostPerson } from '../../utils/api';

Page({
  data: {
    searchKeyword: '',
    activeFilter: 'all',
    childList: [] as LostPerson[],
    loading: false,
    hasMore: true,
    page: 1,
    pageSize: 10,
    total: 0,
    url: 'https://www.baobeihuijia.com/',
    platforms: [
      {
        name: '宝贝回家网',
        url: 'https://www.baobeihuijia.com/',
        api: 'https://www.baobeihuijia.com/api/search',
        count: null,
        countText: ''
      },
      {
        name: '中国寻亲网',
        url: 'https://www.chinaxunqin.com/',
        api: 'https://www.chinaxunqin.com/api/list',
        count: null,
        countText: ''
      },
      {
        name: '公安部儿童失踪信息平台',
        url: 'https://et.anxin.mps.gov.cn/',
        api: 'https://et.anxin.mps.gov.cn/api/list',
        count: null,
        countText: ''
      }
    ]
  },

  onLoad() {
    this.loadChildList();
    this.fetchCounts();
  },

  onPullDownRefresh() {
    this.setData({
      page: 1,
      hasMore: true,
      childList: []
    });
    this.loadChildList().then(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 搜索输入
  onSearchInput(e: any) {
    this.setData({
      searchKeyword: e.detail.value
    });
  },

  // 搜索
  onSearch() {
    this.setData({
      page: 1,
      hasMore: true,
      childList: []
    });
    this.loadChildList();
  },

  // 筛选切换
  onFilterChange(e: any) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      activeFilter: type,
      page: 1,
      hasMore: true,
      childList: []
    });
    this.loadChildList();
  },

  // 加载走失儿童列表
  async loadChildList() {
    if (this.data.loading || !this.data.hasMore) return;

    this.setData({ loading: true });

    try {
      // 构建API参数
      const params: any = {
        page: this.data.page,
        pageSize: this.data.pageSize
      };

      // 添加搜索关键词
      if (this.data.searchKeyword) {
        params.keyword = this.data.searchKeyword;
      }

      // 添加筛选条件
      if (this.data.activeFilter === 'urgent') {
        params.urgent = true;
      } else if (this.data.activeFilter === 'found') {
        params.status = 'found';
      } else if (this.data.activeFilter === 'recent') {
        // 最近24小时的数据，这里通过API参数处理
        params.recent = true;
      }

      // 调用API服务
      const response = await apiService.getLostPersons(params);

      if (response.success && response.data) {
        const newList = this.data.page === 1 ? response.data : [...this.data.childList, ...response.data];
        
        this.setData({
          childList: newList,
          hasMore: response.total ? (this.data.page * this.data.pageSize) < response.total : false,
          loading: false,
          total: response.total || 0
        });
      } else {
        wx.showToast({
          title: response.message || '加载失败',
          icon: 'none'
        });
        this.setData({ loading: false });
      }

    } catch (error) {
      console.error('加载数据失败:', error);
      this.setData({ loading: false });
      wx.showToast({
        title: '网络请求失败',
        icon: 'none'
      });
    }
  },

  // 加载更多
  loadMore() {
    if (!this.data.loading && this.data.hasMore) {
      this.setData({
        page: this.data.page + 1
      });
      this.loadChildList();
    }
  },

  // 查看详情
  onChildDetail(e: any) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/child-detail/child-detail?id=${id}`
    });
  },

  // 分享
  onShareAppMessage() {
    return {
      title: '公益寻人，帮助更多家庭团圆！',
      path: '/pages/lost-child/lost-child'
    }
  },
  onShareTimeline() {
    return {
      title: '公益寻人，帮助更多家庭团圆！',
      path: '/pages/lost-child/lost-child'
    }
  },
  fetchCounts() {
    const that = this;
    this.data.platforms.forEach((platform, idx) => {
      wx.request({
        url: platform.api,
        method: 'GET',
        data: { page: 1, pageSize: 1 },
        success(res) {
          let total = null;
          // 只在res.data为普通对象（非ArrayBuffer）时读取属性
          if (res.data && typeof res.data === 'object' && !(res.data instanceof ArrayBuffer)) {
            total = res.data.total || res.data.count || (res.data.data && res.data.data.total) || null;
          }
          let countText = total ? `已收录走失人员约${total}人` : '';
          const key = `platforms[${idx}].count`;
          const key2 = `platforms[${idx}].countText`;
          that.setData({ [key]: total, [key2]: countText });
        },
        fail() {
          // 失败时用默认文案
          const key2 = `platforms[${idx}].countText`;
          let defaultText = '';
          if (platform.name === '宝贝回家网') defaultText = '已收录走失儿童约5万+';
          if (platform.name === '中国寻亲网') defaultText = '已收录走失人员约3万+';
          if (platform.name === '公安部儿童失踪信息平台') defaultText = '权威发布，实时更新';
          that.setData({ [key2]: defaultText });
        }
      });
    });
  },
  copyUrl(e: any) {
    const url = e.currentTarget.dataset.url;
    wx.setClipboardData({
      data: url,
      success: () => {
        wx.showToast({ title: '已复制', icon: 'success' });
      }
    });
  },
  openInBrowser(e: any) {
    const url = e.currentTarget.dataset.url;
    wx.showModal({
      title: '提示',
      content: '请复制链接到手机浏览器打开：' + url,
      showCancel: false
    });
  }
}); 