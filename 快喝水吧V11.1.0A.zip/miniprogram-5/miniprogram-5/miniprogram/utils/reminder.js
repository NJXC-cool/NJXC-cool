// 由 reminder.ts 直接转换，兼容微信小程序 require

/**
 * 云提醒相关工具函数
 */

// 获取当前时间戳（毫秒）
function getNow() {
  return Date.now ? Date.now() : new Date().getTime();
}

// 计算下次提醒时间（示例：每隔 interval 分钟）
function getNextReminderTime(lastTime, interval) {
  return lastTime + interval * 60 * 1000;
}

// 占位函数，防止 require 报错
function updateReminderSettings() {
  // TODO: 实现提醒设置的保存逻辑
}

// 导出
module.exports = {
  getNow: getNow,
  getNextReminderTime: getNextReminderTime,
  updateReminderSettings: updateReminderSettings
}; 