// 主题管理器
export interface ThemeConfig {
  name: string;
  label: string;
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  cardBackground: string;
  textColor: string;
  textSecondary: string;
  accentColor: string;
  gradient: string;
}

export const themes: ThemeConfig[] = [
  {
    name: 'default',
    label: '默认主题',
    primaryColor: '#4CAF50',
    secondaryColor: '#45a049',
    backgroundColor: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #cbd5e1 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.85)',
    textColor: '#333',
    textSecondary: '#666',
    accentColor: '#4CAF50',
    gradient: 'linear-gradient(135deg, rgba(76, 175, 80, 0.85) 0%, rgba(69, 160, 73, 0.85) 100%)'
  },
  {
    name: 'green',
    label: '清新绿',
    primaryColor: '#2E7D32',
    secondaryColor: '#1B5E20',
    backgroundColor: 'linear-gradient(135deg, #f1f8e9 0%, #c8e6c9 50%, #a5d6a7 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.9)',
    textColor: '#1b5e20',
    textSecondary: '#388e3c',
    accentColor: '#4caf50',
    gradient: 'linear-gradient(135deg, rgba(46, 125, 50, 0.85) 0%, rgba(27, 94, 32, 0.85) 100%)'
  },
  {
    name: 'blue',
    label: '海洋蓝',
    primaryColor: '#1976D2',
    secondaryColor: '#1565C0',
    backgroundColor: 'linear-gradient(135deg, #e3f2fd 0%, #bbdefb 50%, #90caf9 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.9)',
    textColor: '#0d47a1',
    textSecondary: '#1565c0',
    accentColor: '#2196f3',
    gradient: 'linear-gradient(135deg, rgba(25, 118, 210, 0.85) 0%, rgba(21, 101, 192, 0.85) 100%)'
  },
  {
    name: 'orange',
    label: '温暖橙',
    primaryColor: '#F57C00',
    secondaryColor: '#E65100',
    backgroundColor: 'linear-gradient(135deg, #fff3e0 0%, #ffe0b2 50%, #ffcc80 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.9)',
    textColor: '#e65100',
    textSecondary: '#f57c00',
    accentColor: '#ff9800',
    gradient: 'linear-gradient(135deg, rgba(245, 124, 0, 0.85) 0%, rgba(230, 81, 0, 0.85) 100%)'
  },
  {
    name: 'purple',
    label: '梦幻紫',
    primaryColor: '#7B1FA2',
    secondaryColor: '#6A1B9A',
    backgroundColor: 'linear-gradient(135deg, #f3e5f5 0%, #e1bee7 50%, #ce93d8 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.9)',
    textColor: '#4a148c',
    textSecondary: '#7b1fa2',
    accentColor: '#9c27b0',
    gradient: 'linear-gradient(135deg, rgba(123, 31, 162, 0.85) 0%, rgba(106, 27, 154, 0.85) 100%)'
  },
  {
    name: 'pink',
    label: '浪漫粉',
    primaryColor: '#E91E63',
    secondaryColor: '#C2185B',
    backgroundColor: 'linear-gradient(135deg, #fce4ec 0%, #f8bbd9 50%, #f48fb1 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.9)',
    textColor: '#880e4f',
    textSecondary: '#c2185b',
    accentColor: '#e91e63',
    gradient: 'linear-gradient(135deg, rgba(233, 30, 99, 0.85) 0%, rgba(194, 24, 91, 0.85) 100%)'
  }
];



// 获取当前主题
export function getCurrentTheme(): ThemeConfig {
  const themeIndex = wx.getStorageSync('themeIndex') || 0;
  return themes[themeIndex] || themes[0];
}

// 应用主题到页面
export function applyTheme(page: any) {
  const theme = getCurrentTheme();
  
  // 设置页面背景
  page.setData({
    theme: theme,
    pageStyle: `background: ${theme.backgroundColor};`
  });
  
  // 动态设置导航栏颜色
  wx.setNavigationBarColor({
    frontColor: theme.textColor === '#333' ? '#000000' : '#ffffff',
    backgroundColor: theme.primaryColor
  });
}

// 获取主题CSS变量
export function getThemeCSSVariables(): string {
  const theme = getCurrentTheme();
  return `
    --primary-color: ${theme.primaryColor};
    --secondary-color: ${theme.secondaryColor};
    --background-color: ${theme.backgroundColor};
    --card-background: ${theme.cardBackground};
    --text-color: ${theme.textColor};
    --text-secondary: ${theme.textSecondary};
    --accent-color: ${theme.accentColor};
    --gradient: ${theme.gradient};
  `;
}

// 切换主题（带动画）
export function switchTheme(themeIndex: number, page: any) {
  const theme = themes[themeIndex] || themes[0];
  
  // 保存主题索引
  wx.setStorageSync('themeIndex', themeIndex);
  
  // 应用主题动画
  page.setData({
    theme: theme,
    pageStyle: `background: ${theme.backgroundColor}; transition: all 0.5s ease;`
  });
  
  // 设置导航栏颜色
  wx.setNavigationBarColor({
    frontColor: theme.textColor === '#333' ? '#000000' : '#ffffff',
    backgroundColor: theme.primaryColor,
    animation: {
      duration: 500,
      timingFunc: 'easeInOut'
    }
  });
  

  
  // 显示切换成功提示
  wx.showToast({
    title: `已切换到${theme.label}`,
    icon: 'success',
    duration: 1500
  });
}

// 主题切换动画效果
export function animateThemeTransition(page: any, newTheme: ThemeConfig, duration: number = 500) {
  // 创建动画实例
  const animation = wx.createAnimation({
    duration: duration,
    timingFunction: 'ease-in-out',
    delay: 0
  });
  
  // 淡出效果
  animation.opacity(0).step();
  page.setData({
    animationData: animation.export()
  });
  
  // 延迟后切换主题并淡入
  setTimeout(() => {
    page.setData({
      theme: newTheme,
      pageStyle: `background: ${newTheme.backgroundColor};`
    });
    
    animation.opacity(1).step();
    page.setData({
      animationData: animation.export()
    });
  }, duration / 2);
}

// 获取主题预览数据
export function getThemePreviewData() {
  return themes.map(theme => ({
    ...theme,
    preview: {
      title: '快喝水',
      subtitle: '健康生活每一天',
      progress: 60,
      current: 1200,
      target: 2000
    }
  }));
}

 