// 兼容微信小程序的 API 工具

function request(options) {
  return new Promise(function(resolve, reject) {
    wx.request({
      url: options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: options.header || {},
      success: function(res) {
        resolve(res.data);
      },
      fail: function(err) {
        reject(err);
      }
    });
  });
}

function get(url, data, header) {
  return request({ url: url, method: 'GET', data: data, header: header });
}

function post(url, data, header) {
  return request({ url: url, method: 'POST', data: data, header: header });
}

module.exports = {
  request: request,
  get: get,
  post: post
};
