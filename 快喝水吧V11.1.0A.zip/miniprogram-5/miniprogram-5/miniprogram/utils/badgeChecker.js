// 徽章检查工具函数
const BadgeChecker = {
  // 检查并解锁徽章
  checkAndUnlockBadges: function() {
    const { streakDays, todayWater, totalWater, totalDays } = this.calculateUserStats();
    const waterRecords = wx.getStorageSync('waterRecords') || [];
    
    // 徽章解锁条件映射
    const badgeConditions = {
      'first_drink': () => {
        return waterRecords.length > 0;
      },
      'daily_goal': () => {
        const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
        return todayWater >= dailyTarget;
      },
      'early_bird': () => {
        const today = new Date().toDateString();
        const todayRecords = waterRecords.filter(record => 
          new Date(record.timestamp).toDateString() === today
        );
        return todayRecords.some(record => {
          const recordHour = new Date(record.timestamp).getHours();
          return recordHour < 8;
        });
      },
      'week_streak': () => streakDays >= 7,
      'month_master': () => streakDays >= 30,
      'hydration_hero': () => todayWater >= 3000,
      'water_master': () => totalWater >= 100000,
      'persistence_king': () => totalDays >= 100,
      'perfect_day': () => {
        const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
        return todayWater >= dailyTarget * 1.2;
      }
    };

    // 检查所有徽章解锁条件
    Object.keys(badgeConditions).forEach(badgeId => {
      this.checkBadgeUnlock(badgeId, badgeConditions[badgeId]);
    });

    // 检查节日徽章
    this.checkHolidayBadges();
    
    // 检查特殊徽章
    this.checkSpecialBadges();
  },

  // 检查徽章解锁
  checkBadgeUnlock: function(badgeId, condition) {
    const ownedBadgeIds = wx.getStorageSync('ownedBadges') || [];
    
    if (!ownedBadgeIds.includes(badgeId) && condition()) {
      this.unlockBadge(badgeId);
    }
  },

  // 解锁徽章
  unlockBadge: function(badgeId) {
    const ownedBadgeIds = wx.getStorageSync('ownedBadges') || [];
    
    if (!ownedBadgeIds.includes(badgeId)) {
      ownedBadgeIds.push(badgeId);
      wx.setStorageSync('ownedBadges', ownedBadgeIds);
      
      const badgeData = {
        obtainDate: new Date().toLocaleDateString(),
        isNew: true,
        unlockTime: new Date().toISOString()
      };
      wx.setStorageSync(`badge_${badgeId}`, badgeData);
      
      // 获取徽章信息
      const badgeInfo = this.getBadgeInfo(badgeId);
      
      if (badgeInfo) {
        // 显示解锁提示
        wx.showModal({
          title: '🎉 新徽章解锁！',
          content: `恭喜获得"${badgeInfo.name}"徽章！\n\n${badgeInfo.description}\n\n稀有度：${badgeInfo.rarityText}`,
          showCancel: false,
          confirmText: '太棒了！'
        });
        
        // 同步到云端
        this.syncBadgeToCloud(badgeId, badgeData);
      }
    }
  },

  // 获取徽章信息
  getBadgeInfo: function(badgeId) {
    const allBadges = [
      {
        id: 'first_drink',
        name: '初次品尝',
        icon: '💧',
        rarity: 'common',
        rarityText: '普通',
        category: 'daily',
        description: '完成第一次喝水记录'
      },
      {
        id: 'daily_goal',
        name: '今日达标',
        icon: '🎯',
        rarity: 'common',
        rarityText: '普通',
        category: 'daily',
        description: '完成今日饮水目标'
      },
      {
        id: 'early_bird',
        name: '早起鸟儿',
        icon: '🌅',
        rarity: 'rare',
        rarityText: '稀有',
        category: 'daily',
        description: '早上8点前喝水'
      },
      {
        id: 'week_streak',
        name: '七日连击',
        icon: '🔥',
        rarity: 'rare',
        rarityText: '稀有',
        category: 'achievement',
        description: '连续7天达成饮水目标'
      },
      {
        id: 'month_master',
        name: '月度大师',
        icon: '👑',
        rarity: 'epic',
        rarityText: '史诗',
        category: 'achievement',
        description: '连续30天达成饮水目标'
      },
      {
        id: 'hydration_hero',
        name: '补水英雄',
        icon: '🦸',
        rarity: 'epic',
        rarityText: '史诗',
        category: 'achievement',
        description: '单日饮水超过3000ml'
      },
      {
        id: 'water_master',
        name: '饮水大师',
        icon: '🌊',
        rarity: 'epic',
        rarityText: '史诗',
        category: 'achievement',
        description: '累计饮水超过10万ml'
      },
      {
        id: 'persistence_king',
        name: '坚持之王',
        icon: '👑',
        rarity: 'legendary',
        rarityText: '传说',
        category: 'achievement',
        description: '坚持喝水100天'
      },
      {
        id: 'perfect_day',
        name: '完美一天',
        icon: '⭐',
        rarity: 'rare',
        rarityText: '稀有',
        category: 'daily',
        description: '超额完成今日目标20%'
      }
    ];
    
    return allBadges.find(badge => badge.id === badgeId);
  },

  // 同步徽章到云端
  syncBadgeToCloud: function(badgeId, badgeData) {
    wx.cloud.callFunction({
      name: 'badgeSystem',
      data: {
        action: 'unlockBadge',
        userOpenid: wx.getStorageSync('openid') || '',
        badgeId: badgeId,
        badgeData: badgeData
      },
      success: (res) => {
        console.log('徽章同步成功:', res);
      },
      fail: (err) => {
        console.log('徽章同步失败:', err);
      }
    });
  },

  // 计算用户统计
  calculateUserStats: function() {
    const today = new Date().toDateString();
    const waterRecords = wx.getStorageSync('waterRecords') || [];
    const dailyTarget = wx.getStorageSync('dailyTarget') || 2000;
    
    // 计算今日饮水量
    const todayRecords = waterRecords.filter(record => 
      new Date(record.timestamp).toDateString() === today
    );
    const todayWater = todayRecords.reduce((sum, record) => sum + record.amount, 0);
    
    // 计算总饮水量
    const totalWater = waterRecords.reduce((sum, record) => sum + record.amount, 0);
    
    // 计算总天数
    const dates = {};
    waterRecords.forEach(record => {
      const date = new Date(record.timestamp).toDateString();
      dates[date] = (dates[date] || 0) + record.amount;
    });
    const totalDays = Object.keys(dates).length;
    
    // 计算连续天数
    let streakDays = 0;
    let currentDate = new Date();
    
    while (streakDays < 365) {
      const dateStr = currentDate.toDateString();
      if (dates[dateStr] && dates[dateStr] >= dailyTarget) {
        streakDays++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    return { todayWater, streakDays, totalWater, totalDays };
  },

  // 检查节日徽章
  checkHolidayBadges: function() {
    const now = new Date();
    const month = now.getMonth() + 1;
    const date = now.getDate();
    const waterRecords = wx.getStorageSync('waterRecords') || [];
    const today = new Date().toDateString();
    
    // 检查今日是否有饮水记录
    const hasTodayRecord = waterRecords.some(record => 
      new Date(record.timestamp).toDateString() === today
    );
    
    if (!hasTodayRecord) return;
    
    let holidayBadge = null;
    
    // 检查各种节日
    if (month === 1 && date === 1) {
      holidayBadge = { id: 'new_year', name: '新年第一杯', icon: '🎊' };
    } else if (month === 2 && date === 14) {
      holidayBadge = { id: 'valentine', name: '爱心水杯', icon: '💝' };
    } else if (month === 3 && date === 8) {
      holidayBadge = { id: 'women_day', name: '女神节', icon: '👸' };
    } else if (month === 5 && date === 1) {
      holidayBadge = { id: 'labor_day', name: '劳动节', icon: '🛠️' };
    } else if (month === 6 && date === 1) {
      holidayBadge = { id: 'children_day', name: '儿童节', icon: '🎈' };
    } else if (month === 10 && date === 1) {
      holidayBadge = { id: 'national_day', name: '国庆节', icon: '🇨🇳' };
    } else if (month === 12 && date === 25) {
      holidayBadge = { id: 'christmas', name: '圣诞水晶', icon: '🎄' };
    }
    
    if (holidayBadge) {
      const ownedBadgeIds = wx.getStorageSync('ownedBadges') || [];
      if (!ownedBadgeIds.includes(holidayBadge.id)) {
        this.unlockBadge(holidayBadge.id);
      }
    }
  },

  // 检查特殊徽章
  checkSpecialBadges: function() {
    const joinTime = wx.getStorageSync('joinTime') || new Date().toISOString();
    const joinDate = new Date(joinTime);
    const now = new Date();
    const daysSinceJoin = Math.floor((now - joinDate) / (1000 * 60 * 60 * 24));
    
    // 创始用户徽章（注册时间早于某个日期）
    const founderDate = new Date('2025-10-01');
    if (joinDate < founderDate) {
      this.checkBadgeUnlock('founder', () => true);
    }
    
    // 老用户徽章（注册超过10天）
    if (daysSinceJoin >= 10) {
      this.checkBadgeUnlock('veteran', () => true);
    }
  }
};

module.exports = BadgeChecker; 