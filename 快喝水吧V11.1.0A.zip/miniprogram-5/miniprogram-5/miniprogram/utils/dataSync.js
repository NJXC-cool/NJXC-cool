// 数据同步工具类
const DataSync = {
  // 同步所有数据到云端
  syncAllDataToCloud: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      console.log('没有openid，无法同步数据');
      return Promise.reject('没有openid');
    }

    // 收集所有本地数据
    const allData = {
      waterRecords: wx.getStorageSync('waterRecords') || {},
      userData: wx.getStorageSync('userData') || {},
      userInfo: wx.getStorageSync('userInfo') || {},
      badges: this.getOwnedBadges(),
      settings: wx.getStorageSync('settings') || {},
      reminderSettings: wx.getStorageSync('reminderSettings') || {}
    };

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'syncAllData',
          userOpenid: openid,
          data: allData
        },
        success: (res) => {
          console.log('数据同步成功:', res);
          if (res.result && res.result.success) {
            // 更新本地同步时间
            wx.setStorageSync('lastSyncTime', new Date().toISOString());
            resolve(res.result);
          } else {
            reject(res.result.message || '同步失败');
          }
        },
        fail: (err) => {
          console.error('数据同步失败:', err);
          reject(err);
        }
      });
    });
  },

  // 同步喝水记录
  syncWaterRecords: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    const waterRecords = wx.getStorageSync('waterRecords') || {};

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'syncWaterRecords',
          userOpenid: openid,
          data: waterRecords
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result);
          } else {
            reject(res.result.message || '同步失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 同步用户数据
  syncUserData: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    const userData = {
      ...wx.getStorageSync('userData') || {},
      ...wx.getStorageSync('userInfo') || {}
    };

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'syncUserData',
          userOpenid: openid,
          data: userData
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result);
          } else {
            reject(res.result.message || '同步失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 同步徽章数据
  syncBadges: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    const badges = this.getOwnedBadges();

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'syncBadges',
          userOpenid: openid,
          data: badges
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result);
          } else {
            reject(res.result.message || '同步失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 从云端获取数据
  getDataFromCloud: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'getUserData',
          userOpenid: openid
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result.data);
          } else {
            reject(res.result.message || '获取失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 获取喝水记录
  getWaterRecordsFromCloud: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'getWaterRecords',
          userOpenid: openid
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result.data);
          } else {
            reject(res.result.message || '获取失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 获取徽章数据
  getBadgesFromCloud: function() {
    const openid = wx.getStorageSync('openid') || '';
    if (!openid) {
      return Promise.reject('没有openid');
    }

    return new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'dataSync',
        data: {
          action: 'getUserBadges',
          userOpenid: openid
        },
        success: (res) => {
          if (res.result && res.result.success) {
            resolve(res.result.data);
          } else {
            reject(res.result.message || '获取失败');
          }
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  // 获取已拥有的徽章
  getOwnedBadges: function() {
    const ownedBadgeIds = wx.getStorageSync('ownedBadges') || [];
    const badges = [];
    
    ownedBadgeIds.forEach(badgeId => {
      const badgeData = wx.getStorageSync(`badge_${badgeId}`);
      if (badgeData) {
        badges.push({
          id: badgeId,
          ...badgeData
        });
      }
    });
    
    return badges;
  },

  // 自动同步（在添加喝水记录后调用）
  autoSyncAfterWaterRecord: function() {
    // 延迟同步，避免频繁调用
    setTimeout(() => {
      this.syncWaterRecords().then(() => {
        console.log('喝水记录自动同步成功');
      }).catch(err => {
        console.log('喝水记录自动同步失败:', err);
      });
    }, 1000);
  },

  // 检查同步状态
  checkSyncStatus: function() {
    const lastSyncTime = wx.getStorageSync('lastSyncTime');
    if (!lastSyncTime) {
      return { needsSync: true, reason: '从未同步过' };
    }

    const lastSync = new Date(lastSyncTime);
    const now = new Date();
    const hoursSinceSync = (now - lastSync) / (1000 * 60 * 60);

    if (hoursSinceSync > 24) {
      return { needsSync: true, reason: '超过24小时未同步' };
    }

    return { needsSync: false, lastSync: lastSyncTime };
  },

  // 显示同步状态
  showSyncStatus: function() {
    const status = this.checkSyncStatus();
    if (status.needsSync) {
      wx.showToast({
        title: '数据需要同步',
        icon: 'none',
        duration: 2000
      });
    }
  }
};

module.exports = DataSync; 