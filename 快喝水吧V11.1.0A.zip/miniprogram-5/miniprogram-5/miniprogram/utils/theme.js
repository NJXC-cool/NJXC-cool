// 主题管理器
const themes = {
  default: {
    name: 'default',
    label: '默认主题',
    primaryColor: '#667eea',
    secondaryColor: '#764ba2',
    backgroundColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.95)',
    textColor: '#333',
    textSecondary: '#666',
    accentColor: '#667eea'
  },
  dark: {
    name: 'dark',
    label: '深色主题',
    primaryColor: '#2c3e50',
    secondaryColor: '#34495e',
    backgroundColor: 'linear-gradient(135deg, #2c3e50 0%, #34495e 100%)',
    cardBackground: 'rgba(44, 62, 80, 0.95)',
    textColor: '#ecf0f1',
    textSecondary: '#bdc3c7',
    accentColor: '#3498db'
  },
  blue: {
    name: 'blue',
    label: '海洋蓝',
    primaryColor: '#667db6',
    secondaryColor: '#0082c8',
    backgroundColor: 'linear-gradient(135deg, #667db6 0%, #0082c8 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.95)',
    textColor: '#2c3e50',
    textSecondary: '#34495e',
    accentColor: '#0082c8'
  },
  pink: {
    name: 'pink',
    label: '浪漫粉',
    primaryColor: '#fa709a',
    secondaryColor: '#fee140',
    backgroundColor: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.95)',
    textColor: '#2c3e50',
    textSecondary: '#34495e',
    accentColor: '#fa709a'
  },
  purple: {
    name: 'purple',
    label: '梦幻紫',
    primaryColor: '#a8edea',
    secondaryColor: '#fed6e3',
    backgroundColor: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
    cardBackground: 'rgba(255, 255, 255, 0.95)',
    textColor: '#2c3e50',
    textSecondary: '#34495e',
    accentColor: '#9b59b6'
  }
};

function getCurrentTheme() {
  // 从设置或者全局存储中获取当前主题
  var settings = wx.getStorageSync('settings') || {};
  var currentTheme = settings.theme || wx.getStorageSync('currentTheme') || 'default';
  return themes[currentTheme] || themes.default;
}

function applyThemeToPage(page, themeName) {
  var theme = themes[themeName] || themes.default;
  if (page && page.setData) {
    page.setData({
      pageStyle: 'background: ' + theme.backgroundColor + '; min-height: 100vh;'
    });
  }
}

function switchTheme(themeName, page) {
  var theme = themes[themeName] || themes.default;
  
  // 保存主题到设置和全局存储
  var settings = wx.getStorageSync('settings') || {};
  settings.theme = themeName;
  wx.setStorageSync('settings', settings);
  wx.setStorageSync('currentTheme', themeName);
  
  // 应用到当前页面
  if (page && page.setData) {
    page.setData({
      pageStyle: 'background: ' + theme.backgroundColor + '; min-height: 100vh; transition: all 0.5s ease;'
    });
  }
  
  // 更新导航栏颜色
  wx.setNavigationBarColor({
    frontColor: theme.textColor === '#ecf0f1' ? '#ffffff' : '#000000',
    backgroundColor: theme.primaryColor,
    animation: {
      duration: 500,
      timingFunc: 'easeIn'
    }
  });
  
  return theme;
}

function getAllThemes() {
  return Object.values(themes);
}

function getThemeNames() {
  return Object.keys(themes);
}

module.exports = {
  themes: themes,
  getCurrentTheme: getCurrentTheme,
  applyThemeToPage: applyThemeToPage,
  switchTheme: switchTheme,
  getAllThemes: getAllThemes,
  getThemeNames: getThemeNames
}; 