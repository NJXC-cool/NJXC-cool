Component({
  properties: {
    selectedTheme: {
      type: String,
      value: 'default'
    }
  },

  data: {
    themes: [] as any[]
  },

  methods: {
    onThemeSelect(e: any) {
      const themeName = e.currentTarget.dataset.theme;
      console.log('主题选择器点击:', themeName);
      this.triggerEvent('themechange', { theme: themeName });
    },

    loadThemes() {
      try {
        const { getAllThemes } = require('../../utils/theme');
        const themes = getAllThemes();
        console.log('加载主题列表:', themes);
        this.setData({
          themes: themes
        });
      } catch (error) {
        console.error('加载主题失败:', error);
        // 降级处理：使用硬编码的主题列表
        this.setData({
          themes: [
            { name: 'default', label: '默认主题', backgroundColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', primaryColor: '#667eea', cardBackground: 'rgba(255, 255, 255, 0.95)' },
            { name: 'dark', label: '深色主题', backgroundColor: 'linear-gradient(135deg, #2c3e50 0%, #34495e 100%)', primaryColor: '#2c3e50', cardBackground: 'rgba(44, 62, 80, 0.95)' },
            { name: 'blue', label: '海洋蓝', backgroundColor: 'linear-gradient(135deg, #667db6 0%, #0082c8 100%)', primaryColor: '#667db6', cardBackground: 'rgba(255, 255, 255, 0.95)' },
            { name: 'pink', label: '浪漫粉', backgroundColor: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', primaryColor: '#fa709a', cardBackground: 'rgba(255, 255, 255, 0.95)' },
            { name: 'purple', label: '梦幻紫', backgroundColor: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)', primaryColor: '#a8edea', cardBackground: 'rgba(255, 255, 255, 0.95)' }
          ]
        });
      }
    }
  },

  lifetimes: {
    attached() {
      console.log('主题选择器组件加载');
      this.loadThemes();
      console.log('当前选中主题:', this.properties.selectedTheme);
    }
  }
}) 