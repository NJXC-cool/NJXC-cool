// components/announcement-popup/announcement-popup.ts
Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    announcement: {
      type: Object,
      value: {}
    }
  },

  methods: {
    onOverlayTap() {
      this.triggerEvent('close');
    },

    onPopupTap() {
      // 阻止事件冒泡
    },

    onClose() {
      this.triggerEvent('close');
    },

    onMarkAsRead() {
      // 先触发标记已读事件
      this.triggerEvent('markAsRead', { id: this.data.announcement._id });
      
      // 显示已读提示
      wx.showToast({
        title: '已读+1！',
        icon: 'success',
        duration: 1500
      });
    },

    onViewMore() {
      this.triggerEvent('viewMore');
    }
  }
}); 