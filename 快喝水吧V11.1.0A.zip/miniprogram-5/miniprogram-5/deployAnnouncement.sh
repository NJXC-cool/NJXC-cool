#!/bin/bash
# 部署公告云函数
echo "正在部署公告云函数..."
# 进入云函数目录
cd cloudfunctions/announcement
# 安装依赖
npm install
# 返回根目录
cd ../..
# 使用微信开发者工具部署云函数
echo "请在微信开发者工具中右键点击 cloudfunctions/announcement 文件夹，选择'上传并部署：云端安装依赖'"
echo "部署完成！" 