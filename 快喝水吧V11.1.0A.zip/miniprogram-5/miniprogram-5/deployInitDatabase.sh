#!/bin/bash

# 部署数据库初始化云函数
echo "🚀 开始部署数据库初始化云函数..."

# 进入云函数目录
cd cloudfunctions/initDatabase

# 安装依赖
echo "📦 安装依赖..."
npm install

# 部署云函数
echo "☁️ 部署云函数..."
wx cloud functions deploy initDatabase --env $(wx cloud env list | grep -o '[a-zA-Z0-9-]*' | head -1)

echo "✅ 数据库初始化云函数部署完成！"
echo "💡 提示：小程序启动时会自动初始化数据库集合" 