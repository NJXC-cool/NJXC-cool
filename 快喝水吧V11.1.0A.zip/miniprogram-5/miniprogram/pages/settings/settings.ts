// pages/settings/settings.ts
Page({
  data: {
    reminderEnabled: false,
    reminderTime: '09:00',
    reminderIntervalIndex: 0,
    reminderIntervals: [30, 60, 90, 120, 180],
    startTime: '08:00',
    endTime: '22:00',
    cloudReminderEnabled: false,
    hasSubscribed: false,
    defaultCupIndex: 0,
    cupOptions: [
      { label: '小杯', value: 200 },
      { label: '中杯', value: 350 },
      { label: '大杯', value: 500 },
      { label: '超大杯', value: 750 }
    ]
  },

  onLoad() {
    this.loadReminderSettings()
  },

  // 加载提醒设置
  loadReminderSettings() {
    const reminderEnabled = wx.getStorageSync('reminderEnabled') || false
    const reminderTime = wx.getStorageSync('reminderTime') || '09:00'
    const reminderIntervalIndex = wx.getStorageSync('reminderIntervalIndex') || 0
    const startTime = wx.getStorageSync('startTime') || '08:00'
    const endTime = wx.getStorageSync('endTime') || '22:00'
    const cloudReminderEnabled = wx.getStorageSync('cloudReminderEnabled') || false
    const defaultCupIndex = wx.getStorageSync('defaultCupIndex') || 0
    
    this.setData({ 
      reminderEnabled, 
      reminderTime, 
      reminderIntervalIndex,
      startTime,
      endTime,
      cloudReminderEnabled,
      defaultCupIndex
    })
  },

  // 提醒开关变化
  onReminderSwitchChange(e) {
    const enabled = e.detail.value
    this.setData({ reminderEnabled: enabled })
    this.saveSettings()
  },

  // 时间选择变化
  onTimeChange(e) {
    this.setData({ reminderTime: e.detail.value })
    this.saveSettings()
  },

  // 提醒间隔变化
  onIntervalChange(e) {
    this.setData({ reminderIntervalIndex: e.detail.value })
    this.saveSettings()
  },

  // 开始时间变化
  onStartTimeChange(e) {
    this.setData({ startTime: e.detail.value })
    this.saveSettings()
  },

  // 结束时间变化
  onEndTimeChange(e) {
    this.setData({ endTime: e.detail.value })
    this.saveSettings()
  },

  // 云提醒开关变化
  onCloudReminderChange(e) {
    this.setData({ cloudReminderEnabled: e.detail.value });
    this.saveSettings();
    
    if (e.detail.value) {
      // 请求订阅消息权限
      wx.requestSubscribeMessage({
        tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
        success: (res) => {
          if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
            wx.showToast({ title: '云提醒已开启', icon: 'success' });
            // 调用云函数保存提醒设置
            this.saveCloudSettings();
          } else {
            this.setData({ cloudReminderEnabled: false });
            wx.showToast({ title: '未授权订阅', icon: 'none' });
          }
        },
        fail: (err) => {
          this.setData({ cloudReminderEnabled: false });
          wx.showToast({ title: '请在设置中开启订阅消息权限', icon: 'none' });
        }
      });
    }
  },

  // 默认杯子变化
  onDefaultCupChange(e) {
    this.setData({ defaultCupIndex: e.detail.value })
    wx.setStorageSync('defaultCupIndex', e.detail.value)
    wx.showToast({ title: '设置已保存', icon: 'success' })
  },

  // 保存本地设置
  saveSettings() {
    wx.setStorageSync('reminderEnabled', this.data.reminderEnabled)
    wx.setStorageSync('reminderTime', this.data.reminderTime)
    wx.setStorageSync('reminderIntervalIndex', this.data.reminderIntervalIndex)
    wx.setStorageSync('startTime', this.data.startTime)
    wx.setStorageSync('endTime', this.data.endTime)
    wx.setStorageSync('cloudReminderEnabled', this.data.cloudReminderEnabled)
  },

  // 保存云设置
  saveCloudSettings() {
    wx.cloud.callFunction({
      name: 'sendReminder',
      data: {
        time: this.data.reminderTime,
        enabled: this.data.reminderEnabled,
        reminderInterval: this.data.reminderIntervals[this.data.reminderIntervalIndex],
        startTime: this.data.startTime,
        endTime: this.data.endTime,
        remindTitle: '喝水提醒',
        remindContent: '该喝水啦，保持健康！'
      },
      success: (res) => {
        if (res.result.code === 0) {
          wx.showToast({ title: '云端设置已保存', icon: 'success' })
        } else {
          wx.showToast({ title: '云端保存失败', icon: 'none' })
        }
      },
      fail: (err) => {
        console.error('云函数调用失败:', err)
        wx.showToast({ title: '网络错误', icon: 'none' })
      }
    })
  },

  // 订阅云提醒
  subscribeCloudReminder() {
    wx.requestSubscribeMessage({
      tmplIds: ['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'],
      success(res) {
        if (res['gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'] === 'accept') {
          wx.showToast({ title: '订阅成功', icon: 'success' });
        } else {
          wx.showToast({ title: '订阅失败', icon: 'none' });
        }
      },
      fail(err) {
        wx.showToast({ title: '订阅失败', icon: 'none' });
      }
    });
  },

  // 清除数据
  clearData() {
    wx.showModal({
      title: '确认清除',
      content: '这将清除所有本地数据，包括喝水记录、设置等，无法恢复',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync()
          this.loadReminderSettings()
          wx.showToast({ title: '数据已清除', icon: 'success' })
        }
      }
    })
  },

  // 关于我们
  aboutUs() {
    wx.showModal({
      title: '💧 关于快喝水',
      content: '版本：1.0.0\n\n🌟 一款帮助您养成健康喝水习惯的小程序\n\n✨ 功能特色：\n• 💧 智能提醒 - 科学安排喝水时间\n• 📊 数据统计 - 记录您的喝水习惯\n• 🏆 成就系统 - 激励持续坚持\n• 🎮 小游戏 - 让喝水变得有趣\n\n💪 让我们一起养成健康的生活习惯！\n\n感谢您的使用！❤️',
      showCancel: false
    })
  }
}) 