// 网页版快喝水应用
class WaterDrinkingApp {
    constructor() {
        this.data = {
            today: '',
            dailyTarget: 2000,
            todayDrunk: 0,
            remaining: 2000,
            todayCups: 0,
            progressPercent: 0,
            progressAngle: 0,
            selectedCup: 250,
            manualInput: '',
            encouragement: '',
            todayRecords: [],
            nickname: '',
            avatarUrl: '',
            defaultAvatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0',
            cupOptions: [
                { value: 200, label: '小杯' },
                { value: 250, label: '标准' },
                { value: 300, label: '大杯' },
                { value: 350, label: '超大' },
                { value: 500, label: '水瓶' }
            ],
            encouragements: [
                '保持水分，保持健康！',
                '喝水是身体最好的朋友',
                '每一滴水都是对身体的关爱',
                '保持水分，皮肤更水润',
                '喝水有助于新陈代谢',
                '健康生活从喝水开始',
                '保持水分，头脑更清醒',
                '喝水是减肥的好帮手'
            ]
        };

        this.init();
    }

    // 初始化
    init() {
        this.initData();
        this.loadTodayData();
        this.loadUserInfo();
        this.bindEvents();
        this.renderCupOptions();
        this.updateDisplay();
    }
    // 初始化数据
    initData() {
        const dailyTarget = this.getStorage('dailyTarget') || 2000;
        const defaultCupIndex = this.getStorage('defaultCupIndex') || 1; // 默认选择标准杯
        const cupOptions = this.data.cupOptions;
        const selectedCup = cupOptions[defaultCupIndex] ? cupOptions[defaultCupIndex].value : 250;

        this.data.dailyTarget = dailyTarget;
        this.data.selectedCup = selectedCup;
    }

    // 绑定所有按钮和交互事件
    bindEvents() {
        // 获取用户信息
        document.getElementById('getUserProfileBtn').addEventListener('click', () => {
            this.getUserProfile();
        });

        // 喝水按钮
        document.getElementById('drinkButton').addEventListener('click', () => {
            this.recordDrink();
        });

        // 手动添加
        document.getElementById('addManualBtn').addEventListener('click', () => {
            this.addManualDrink();
        });

        // 设置按钮
        document.getElementById('settingsBtn').addEventListener('click', () => {
            this.openSettings();
        });

        // 小程序按钮
        document.getElementById('miniprogramBtn').addEventListener('click', () => {
            this.openMiniprogram();
        });

        // 设置弹窗关闭
        document.getElementById('closeSettings').addEventListener('click', () => {
            this.closeSettings();
        });

        document.getElementById('saveSettings').addEventListener('click', () => {
            this.saveSettings();
        });

        document.getElementById('openMiniprogramBtn').addEventListener('click', () => {
            this.openMiniprogramSettings();
        });

        // 点击模态框外部关闭
        document.getElementById('settingsModal').addEventListener('click', (e) => {
            if (e.target.id === 'settingsModal') {
                this.closeSettings();
            }
        });
    }

    // 渲染所有杯子选项
    renderCupOptions() {
        const cupOptionsContainer = document.getElementById('cupOptions');
        cupOptionsContainer.innerHTML = '';

        this.data.cupOptions.forEach(cup => {
            const cupElement = document.createElement('div');
            cupElement.className = `cup-option ${this.data.selectedCup === cup.value ? 'selected' : ''}`;
            cupElement.innerHTML = `
                <span class="cup-value">${cup.value}ml</span>
                <span class="cup-label">${cup.label}</span>
            `;
            cupElement.addEventListener('click', () => {
                this.selectCup(cup.value);
            });
            cupOptionsContainer.appendChild(cupElement);
        });
    }

    // 选择杯子容量
    selectCup(value) {
        this.data.selectedCup = value;
        this.setStorage('defaultCupIndex', this.data.cupOptions.findIndex(cup => cup.value === value));
        this.renderCupOptions();
    }
    // 记录喝水
    recordDrink() {
        this.addWaterRecord(this.data.selectedCup);
    }

    // 手动添加喝水
    addManualDrink() {
        const input = document.getElementById('manualInput');
        const amount = parseInt(input.value);

        if (amount && amount > 0) {
            this.addWaterRecord(amount);
            input.value = '';
        } else {
            this.showToast('请输入有效的水量');
        }
    }

    // 添加喝水记录
    addWaterRecord(amount) {
        const now = new Date();
        const today = this.formatDate(now);
        const record = {
            id: Date.now().toString(),
            amount,
            timestamp: now.getTime(),
            time: this.formatTime(now)
        };

        // 获取现有记录
        const records = this.getStorage('waterRecords') || {};
        const todayRecords = records[today] || [];
        todayRecords.push(record);
        records[today] = todayRecords;

        // 保存记录
        this.setStorage('waterRecords', records);

        // 更新显示
        this.loadTodayData();

        // 显示鼓励语句
        this.showEncouragement();

        // 显示成功提示
        this.showToast(`已记录 ${amount}ml`);

        // 更新用户数据
        this.updateUserData(amount, today);
    }

    // 更新用户数据
    updateUserData(amount, today) {
        const userData = this.getStorage('userData') || {};
        let days = userData.days || 0;
        let lastCheckDate = userData.lastCheckDate || '';
        let totalVolume = userData.totalVolume || 0;
        let checkTimes = userData.checkTimes || [];

        // 连续打卡天数逻辑
        if (lastCheckDate !== today) {
            days += 1;
            lastCheckDate = today;
        }

        // 添加当前日期到打卡记录中
        if (!checkTimes.includes(today)) {
            checkTimes.push(today);
        }

        userData.days = days;
        userData.lastCheckDate = lastCheckDate;
        userData.totalVolume = totalVolume + amount;
        userData.checkTimes = checkTimes;
        this.setStorage('userData', userData);
    }

    // 显示鼓励语句
    showEncouragement() {
        const encouragements = this.data.encouragements;
        const randomIndex = Math.floor(Math.random() * encouragements.length);
        const encouragement = encouragements[randomIndex];

        const encouragementElement = document.getElementById('encouragement');
        const encouragementText = document.getElementById('encouragementText');

        encouragementText.textContent = encouragement;
        encouragementElement.style.display = 'block';

        // 3秒后隐藏
        setTimeout(() => {
            encouragementElement.style.display = 'none';
        }, 3000);
    }
    // 加载今日数据
    loadTodayData() {
        const today = this.formatDate(new Date());
        const records = this.getStorage('waterRecords') || {};
        const todayRecords = records[today] || [];

        const todayDrunk = todayRecords.reduce((sum, record) => sum + record.amount, 0);
        const remaining = Math.max(0, this.data.dailyTarget - todayDrunk);
        const progressPercent = Math.min(100, Math.round((todayDrunk / this.data.dailyTarget) * 100));
        const progressAngle = (progressPercent / 100) * 360;

        this.data.today = today;
        this.data.todayDrunk = todayDrunk;
        this.data.remaining = remaining;
        this.data.todayCups = todayRecords.length;
        this.data.progressPercent = progressPercent;
        this.data.progressAngle = progressAngle;
        this.data.todayRecords = todayRecords.slice(-10).reverse(); // 显示最近10条记录

        this.updateDisplay();
    }

    // 加载用户信息
    loadUserInfo() {
        const nickname = this.getStorage('nickname') || '';
        const avatarUrl = this.getStorage('avatarUrl') || '';

        this.data.nickname = nickname;
        this.data.avatarUrl = avatarUrl;

        if (nickname) {
            this.showUserInfo();
        }
    }

    // 显示用户信息
    showUserInfo() {
        document.getElementById('getUserProfileBtn').style.display = 'none';
        document.getElementById('userinfoDisplay').style.display = 'flex';
        document.getElementById('userNickname').textContent = this.data.nickname;
        document.getElementById('userAvatar').src = this.data.avatarUrl || this.data.defaultAvatarUrl;
    }

    // 获取用户信息（模拟）
    getUserProfile() {
        // 实际应用可对接微信API，这里用模拟数据
        const mockUserInfo = {
            nickName: '用户' + Math.floor(Math.random() * 1000),
            avatarUrl: this.data.defaultAvatarUrl
        };

        this.data.nickname = mockUserInfo.nickName;
        this.data.avatarUrl = mockUserInfo.avatarUrl;

        this.setStorage('nickname', mockUserInfo.nickName);
        this.setStorage('avatarUrl', mockUserInfo.avatarUrl);

        this.showUserInfo();
        this.showToast('用户信息获取成功');
    }

    // 更新主界面显示
    updateDisplay() {
        // 更新日期
        document.getElementById('todayDate').textContent = this.data.today;
        document.getElementById('dailyTarget').textContent = `目标: ${this.data.dailyTarget}ml`;

        // 更新进度圆环
        const progressRing = document.getElementById('progressRing');
        progressRing.style.background = `conic-gradient(#4CAF50 0deg, #4CAF50 ${this.data.progressAngle}deg, #e0e0e0 ${this.data.progressAngle}deg, #e0e0e0 360deg)`;

        // 更新进度文字
        document.getElementById('todayDrunk').textContent = `${this.data.todayDrunk}ml`;
        document.getElementById('progressPercent').textContent = `${this.data.progressPercent}%`;

        // 更新统计信息
        document.getElementById('drunkAmount').textContent = `${this.data.todayDrunk}ml`;
        document.getElementById('remainingAmount').textContent = `${this.data.remaining}ml`;
        document.getElementById('todayCups').textContent = `${this.data.todayCups}杯`;

        // 更新今日记录
        this.renderTodayRecords();
    }

    // 渲染今日记录
    renderTodayRecords() {
        const recordsList = document.getElementById('recordsList');
        const todayRecords = document.getElementById('todayRecords');

        if (this.data.todayRecords.length > 0) {
            recordsList.innerHTML = '';
            this.data.todayRecords.forEach(record => {
                const recordElement = document.createElement('div');
                recordElement.className = 'record-item';
                recordElement.innerHTML = `
                    <span class="record-time">${record.time}</span>
                    <span class="record-amount">+${record.amount}ml</span>
                `;
                recordsList.appendChild(recordElement);
            });
            todayRecords.style.display = 'block';
        } else {
            todayRecords.style.display = 'none';
        }
    }

    // 打开设置
    openSettings() {
        this.loadSettingsToModal();
        document.getElementById('settingsModal').style.display = 'block';
    }

    // 关闭设置
    closeSettings() {
        document.getElementById('settingsModal').style.display = 'none';
    }

    // 加载设置到模态框
    loadSettingsToModal() {
        const reminderEnabled = this.getStorage('reminderEnabled') || false;
        const reminderTime = this.getStorage('reminderTime') || '09:00';
        const reminderInterval = this.getStorage('reminderInterval') || '60';
        const dailyTarget = this.getStorage('dailyTarget') || 2000;
        const defaultCupIndex = this.getStorage('defaultCupIndex') || 1;

        document.getElementById('reminderEnabled').checked = reminderEnabled;
        document.getElementById('reminderTime').value = reminderTime;
        document.getElementById('reminderInterval').value = reminderInterval;
        document.getElementById('dailyTargetSelect').value = dailyTarget;
        document.getElementById('defaultCupSelect').value = this.data.cupOptions[defaultCupIndex]?.value || 250;
    }

    // 保存设置
    saveSettings() {
        const reminderEnabled = document.getElementById('reminderEnabled').checked;
        const reminderTime = document.getElementById('reminderTime').value;
        const reminderInterval = document.getElementById('reminderInterval').value;
        const dailyTarget = parseInt(document.getElementById('dailyTargetSelect').value);
        const defaultCupValue = parseInt(document.getElementById('defaultCupSelect').value);

        this.setStorage('reminderEnabled', reminderEnabled);
        this.setStorage('reminderTime', reminderTime);
        this.setStorage('reminderInterval', reminderInterval);
        this.setStorage('dailyTarget', dailyTarget);
        this.setStorage('defaultCupIndex', this.data.cupOptions.findIndex(cup => cup.value === defaultCupValue));

        // 更新应用数据
        this.data.dailyTarget = dailyTarget;
        this.data.selectedCup = defaultCupValue;

        this.renderCupOptions();
        this.loadTodayData();
        this.closeSettings();
        this.showToast('设置已保存');
    }

    // 打开小程序设置
    openMiniprogramSettings() {
        this.showToast('正在跳转到小程序设置页面...');
        this.openMiniprogram();
    }

    // 打开小程序
    openMiniprogram() {
        // 尝试打开微信小程序
        if (this.isWeChat()) {
            // 在微信环境中，跳转到小程序设置页面
            this.showToast('正在打开小程序设置页面...');
            
            // 使用微信小程序的跳转API
            if (typeof wx !== 'undefined' && wx.miniProgram) {
                wx.miniProgram.navigateTo({
                    url: '/pages/web-settings/web-settings?fromWeb=true'
                });
            } else {
                // 如果不在微信环境中，显示二维码
                this.showMiniprogramQRCode();
            }
        } else {
            // 在非微信环境中，显示二维码或提示
            this.showMiniprogramQRCode();
        }
    }

    // 显示小程序二维码
    showMiniprogramQRCode() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>打开小程序设置</h2>
                    <span class="close" onclick="this.parentElement.parentElement.parentElement.remove()">&times;</span>
                </div>
                <div class="modal-body" style="text-align: center;">
                    <p style="font-size: 28px; margin-bottom: 24px;">请使用微信扫描二维码打开小程序设置页面</p>
                    <div style="background: #f0f0f0; padding: 40px; border-radius: 16px; display: inline-block;">
                        <p style="font-size: 24px; color: #666;">小程序设置页面</p>
                        <p style="font-size: 20px; color: #999; margin-top: 16px;">请在微信中打开小程序进行设置</p>
                    </div>
                    <div style="margin-top: 24px;">
                        <p style="font-size: 20px; color: #666;">设置完成后返回网页版继续使用</p>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    // 检查是否在微信环境中
    isWeChat() {
        return /MicroMessenger/i.test(navigator.userAgent);
    }

    // 显示提示
    showToast(message) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px 40px;
            border-radius: 12px;
            font-size: 28px;
            z-index: 10000;
            animation: toastFadeIn 0.3s ease-out;
        `;
        toast.textContent = message;

        const style = document.createElement('style');
        style.textContent = `
            @keyframes toastFadeIn {
                from { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
            style.remove();
        }, 3000);
    }

    // 格式化日期
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // 格式化时间
    formatTime(date) {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    // 本地存储
    setStorage(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('存储失败:', e);
        }
    }

    getStorage(key) {
        try {
            const value = localStorage.getItem(key);
            return value ? JSON.parse(value) : null;
        } catch (e) {
            console.error('读取存储失败:', e);
            return null;
        }
    }

    // 清除存储
    clearStorage() {
        try {
            localStorage.clear();
        } catch (e) {
            console.error('清除存储失败:', e);
        }
    }
}

// 页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', () => {
    window.waterApp = new WaterDrinkingApp();
});