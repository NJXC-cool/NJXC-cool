// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

// 订阅消息模板ID
const TEMPLATE_ID = 'gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    // 获取当前时间
    const now = new Date()
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
    
    // 查询需要发送提醒的用户
    const reminders = await db.collection('reminderSettings')
      .where({
        cloudReminderEnabled: true,
        enabled: true
      })
      .get()

    if (reminders.data.length === 0) {
      return { code: 0, msg: '当前没有需要发送提醒的用户' }
    }

    // 批量发送订阅消息
    const sendPromises = reminders.data.map(async (reminder) => {
      try {
        // 检查是否在活跃时间段内
        const [startHour, startMinute] = reminder.startTime.split(':').map(Number)
        const [endHour, endMinute] = reminder.endTime.split(':').map(Number)
        const currentHour = now.getHours()
        const currentMinute = now.getMinutes()
        
        const inActiveTime = 
          (currentHour > startHour || (currentHour === startHour && currentMinute >= startMinute)) &&
          (currentHour < endHour || (currentHour === endHour && currentMinute <= endMinute))

        if (!inActiveTime) {
          return { openid: reminder.openid, success: false, reason: '不在活跃时间段' }
        }

        // 检查提醒间隔
        const lastRemind = reminder.lastRemindTime ? new Date(reminder.lastRemindTime) : null
        const interval = reminder.reminderInterval || 60
        let needRemind = false
        
        if (!lastRemind) {
          needRemind = true
        } else {
          const diff = (now - lastRemind) / 60000 // 转换为分钟
          if (diff >= interval) needRemind = true
        }
        
        if (!needRemind) {
          return { openid: reminder.openid, success: false, reason: '未到提醒间隔' }
        }

        // 发送订阅消息
        const result = await cloud.openapi.subscribeMessage.send({
          touser: reminder.openid,
          templateId: TEMPLATE_ID,
          page: 'pages/index/index',
          data: {
            thing4: { value: reminder.remindTitle || '喝水提醒' },
            thing5: { value: reminder.remindContent || '该喝水啦，保持健康！' }
          }
        })

        // 更新最后提醒时间
        await db.collection('reminderSettings').doc(reminder._id).update({
          data: { lastRemindTime: now }
        })

        return { openid: reminder.openid, success: true, result }
      } catch (error) {
        return { openid: reminder.openid, success: false, error: error.message }
      }
    })

    const results = await Promise.all(sendPromises)
    const successCount = results.filter(r => r.success).length
    const failCount = results.length - successCount

    return {
      code: 0,
      msg: `推送完成：成功${successCount}个，失败${failCount}个`,
      results
    }
  } catch (error) {
    return { code: 1, msg: '推送失败', error: error.message }
  }
} 