// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

// 订阅消息模板ID
const TEMPLATE_ID = 'gr_FWtKWnoT3WgrG8PwVxSNjuI2o0zTxQPg8OKPytA8'

// 云函数入口函数
exports.main = async (event, context) => {
  const { openid } = event.userInfo || cloud.getWXContext()
  const { time, enabled, reminderInterval, startTime, endTime, remindTitle, remindContent } = event

  if (!openid) {
    return { code: 1, msg: '未获取到openid' }
  }

  try {
    const res = await db.collection('reminderSettings').where({ openid }).get()
    if (res.data.length > 0) {
      // 更新记录
      await db.collection('reminderSettings').where({ openid }).update({
        data: { 
          time, 
          enabled,
          reminderInterval: reminderInterval || 60,
          startTime: startTime || '08:00',
          endTime: endTime || '22:00',
          remindTitle: remindTitle || '喝水提醒',
          remindContent: remindContent || '该喝水啦，保持健康！',
          cloudReminderEnabled: enabled,
          updatedAt: new Date()
        }
      })
    } else {
      // 新建记录
      await db.collection('reminderSettings').add({
        data: { 
          openid, 
          time, 
          enabled,
          reminderInterval: reminderInterval || 60,
          startTime: startTime || '08:00',
          endTime: endTime || '22:00',
          remindTitle: remindTitle || '喝水提醒',
          remindContent: remindContent || '该喝水啦，保持健康！',
          cloudReminderEnabled: enabled,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      })
    }
    return { code: 0, msg: '设置成功' }
  } catch (e) {
    return { code: 2, msg: '数据库操作失败', error: e }
  }
} 